/* LearnHub — German pack.
   Contains the interface strings and every lesson, written in German. */
window.PACKS = window.PACKS || {};
window.PACKS.de = {
  code: "de",
  name: "Deutsch",
  dir: "ltr",

  ui: {
    appName: "LearnHub",
    taglineShort: "Alles lernen",
    welcomeTitle: "Willkommen bei LearnHub",
    welcomeSub: "Lerne Mathematik, Naturwissenschaften, Sprachen und mehr. Jede Lektion erklärt zuerst die Idee, danach übst du mit Fragen.",
    pickLanguage: "Wähle deine Sprache",
    yourName: "Wie sollen wir dich nennen?",
    namePlaceholder: "Gib deinen Namen ein",
    pickAnimal: "Wähle dein Tier",
    startLearning: "Los geht's",
    needName: "Bitte gib zuerst einen Namen ein.",
    soundPreview: "Tippe auf ein Tier und dann auf Start.",
    yourProfile: "Dein Profil",
    yourNameLabel: "Name",
    yourAnimal: "Dein Tier",
    saveProfile: "Speichern",
    profileSaved: "Gespeichert!",
    yourProgress: "Dein Fortschritt",
    lessonsDone: "Lektionen geschafft",
    starsEarned: "Sterne gesammelt",
    avgScore: "Durchschnittliche Punktzahl",
    soundOn: "Soundeffekte: an",
    soundOff: "Soundeffekte: aus",
    heroTitle: "Lerne alles – Schritt für Schritt",
    heroLead: "Jede Lektion beginnt mit einer kurzen, klaren Erklärung – danach übst du mit Fragen. Bei einer richtigen Antwort hörst du ein Ting; bei einer falschen erklingt die traurige Posaune.",
    welcomeBack: "Willkommen zurück, {name}!",
    continueLearning: "Weiterlernen",
    startLesson: "Lektion starten",
    allCaughtUp: "Du hast jede Lektion abgeschlossen",
    allCaughtUpBody: "Wiederhole unten ein beliebiges Fach, um deine Bestleistung zu übertreffen.",
    chooseSubject: "Wähle ein Fach",
    subjectsCount: "{n} Fächer",
    lessonsCount: "{n} Lektionen",
    ofComplete: "{done} von {total} geschafft",
    progressLabel: "Fortschritt",
    allSubjects: "Alle Fächer",
    notStarted: "Nicht begonnen",
    minRead: "{n} Min. Lesezeit",
    questionsCount: "{n} Fragen",
    stepExplain: "Erklärung",
    stepPractice: "Übung",
    readyButton: "Ich bin bereit – Quiz starten",
    readyHint: "Ein Ting bedeutet richtig. Ein Womp womp womp bedeutet: versuch es noch einmal.",
    rememberThese: "Merke dir das",
    questionOf: "Frage {i} von {n}",
    scoreLabel: "Punkte {n}",
    streakLabel: "Serie {n} hintereinander",
    correctFeedback: "Richtig!",
    wrongFeedback: "Nicht ganz",
    inARow: "{n} hintereinander!",
    quizTip: "Tipp: Drücke 1–4 zum Auswählen, Enter zum Weiter.",
    nextQuestion: "Nächste Frage",
    seeResults: "Ergebnisse ansehen",
    msgPerfect: "Eine perfekte Punktzahl. Du beherrschst diese Lektion vollständig.",
    msgExcellent: "Ausgezeichnete Arbeit – fast perfekt.",
    msgGood: "Gut gemacht. Du hast ein solides Verständnis.",
    msgOk: "Ein guter Anfang. Lies die Erklärung noch einmal und versuche es dann erneut.",
    msgKeepGoing: "Bleib dran. Geh die Erklärung noch einmal durch und versuche es erneut – du schaffst das.",
    pctCorrect: "{p} % richtig",
    bestStreakLabel: "beste Serie {n} hintereinander",
    prevBest: "bisher beste {b}/{t}",
    reviewTitle: "Sieh dir deine {n} Fehler an",
    reviewTitleOne: "Sieh dir deinen Fehler an",
    correctIs: "Richtig:",
    youAnswered: "Deine Antwort:",
    noMistakes: "Jede Frage richtig – keine Fehler zum Nachschauen.",
    tryAgain: "Noch einmal versuchen",
    backTo: "Zurück zu {subject}",
    nextLessonLabel: "Nächste Lektion: {title}",
    soundToggle: "Soundeffekte",
    backHome: "Start",
    langLabel: "Sprache",
    closeLabel: "Schließen",
    editProfile: "Profil bearbeiten",
    switchHint: "Alles – die Menüs und jede Lektion – wechselt in die Sprache, die du wählst."
  },

  avatars: {
    cat: "Katze",
    dog: "Hund",
    fox: "Fuchs",
    panda: "Panda",
    owl: "Eule",
    lion: "Löwe",
    frog: "Frosch",
    penguin: "Pinguin"
  },

  subjects: [
    {
      id: "math",
      name: "Mathematik",
      tagline: "Brüche, Algebra und Geometrie – Schritt für Schritt erklärt.",
      color: "#4f46e5",
      icon: "calculator",
      lessons: [
        {
          id: "fractions",
          title: "Brüche",
          summary: "Brüche lesen, vergleichen, kürzen und sicher addieren.",
          minutes: 8,
          explain: {
            intro: "Ein Bruch zeigt **einen Teil eines Ganzen**. Jeder Bruch hat zwei Teile: den **Zähler** (obere Zahl) und den **Nenner** (untere Zahl).",
            sections: [
              { h: "Zähler und Nenner", p: "Der Nenner sagt dir, in wie viele gleiche Stücke das Ganze geteilt wird. Der Zähler sagt dir, wie viele dieser Stücke du nimmst. In 3/4 wird das Ganze in 4 Stücke geteilt und du nimmst 3 davon." },
              { h: "Gleichwertige Brüche", p: "Wenn du die obere und die untere Zahl mit derselben Zahl multiplizierst oder dividierst, erhältst du einen **gleichwertigen Bruch** mit genau demselben Wert.", list: ["1/2 = 2/4 = 4/8 = 50/100", "6/8 = 3/4  (beide Teile durch 2 teilen)", "10/15 = 2/3  (beide Teile durch 5 teilen)"] },
              { h: "Brüche addieren", p: "Wenn die Nenner schon gleich sind, addiere die Zähler und behalte den Nenner. Wenn sie verschieden sind, schreibe zuerst beide Brüche mit einem **gemeinsamen Nenner**.", list: ["1/4 + 2/4 = 3/4", "1/2 + 1/3 = 3/6 + 2/6 = 5/6"] },
              { h: "Brüche vergleichen", p: "Schreibe beide Brüche mit einem gemeinsamen Nenner und vergleiche dann die Zähler. 2/3 und 3/5 werden zu 10/15 und 9/15, also ist **2/3 größer**." }
            ],
            keyPoints: [
              "Nenner = Größe der Stücke, Zähler = Anzahl der Stücke, die du hast",
              "Kürze, indem du beide Teile durch ihren größten gemeinsamen Teiler teilst",
              "Addiere niemals die Nenner – nur die Zähler, nachdem sie gleich sind"
            ],
            example: {
              title: "Rechenbeispiel: 2/3 + 1/4",
              steps: ["Finde einen gemeinsamen Nenner: 12", "Schreibe um: 2/3 = 8/12 und 1/4 = 3/12", "Addiere die Zähler: 8 + 3 = 11", "Antwort: 11/12"]
            }
          },
          questions: [
            { q: "Welche Zahl ist im Bruch 3/4 der Nenner?", options: ["4", "3", "7", "12"], answer: 0, explain: "Der Nenner ist die untere Zahl, 4. Er sagt dir, dass das Ganze in 4 gleiche Teile geteilt ist." },
            { q: "Welcher Bruch ist gleichwertig zu 1/2?", options: ["2/4", "2/3", "1/3", "3/5"], answer: 0, explain: "Multipliziere die obere und die untere Zahl von 1/2 mit 2: 1/2 = 2/4. Gleicher Wert, andere Zahlen." },
            { q: "Wie viel ist 1/4 + 2/4?", options: ["3/4", "3/8", "2/8", "1/2"], answer: 0, explain: "Die Nenner sind gleich, also addiere die Zähler (1 + 2 = 3) und behalte 4. Die Antwort ist 3/4, nicht 3/8." },
            { q: "Wie viel ist 1/2 + 1/3?", options: ["5/6", "2/5", "1/5", "2/6"], answer: 0, explain: "Ein gemeinsamer Nenner ist 6: 1/2 = 3/6 und 1/3 = 2/6. Dann 3/6 + 2/6 = 5/6." },
            { q: "Kürze 6/8.", options: ["3/4", "2/3", "1/2", "6/8"], answer: 0, explain: "Teile beide Teile durch ihren größten gemeinsamen Teiler 2: 6 ÷ 2 = 3 und 8 ÷ 2 = 4, das ergibt 3/4." },
            { q: "Welcher Bruch ist größer: 2/3 oder 3/5?", options: ["2/3", "3/5", "Sie sind gleich", "Sie lassen sich nicht vergleichen"], answer: 0, explain: "Mit dem gemeinsamen Nenner 15: 2/3 = 10/15 und 3/5 = 9/15. Also ist 2/3 größer." },
            { q: "Wie viel sind 3/5 von 20?", options: ["12", "15", "8", "5"], answer: 0, explain: "Teile durch den Nenner (20 ÷ 5 = 4) und multipliziere dann mit dem Zähler (4 × 3 = 12)." }
          ]
        },
        {
          id: "equations",
          title: "Lineare Gleichungen lösen",
          summary: "Nutze Umkehroperationen, um den Wert von x zu finden – und prüfe deine Antwort.",
          minutes: 9,
          explain: {
            intro: "Eine Gleichung ist eine **Waage**. Die beiden Seiten sind gleich, und deine Aufgabe ist es, den Wert der Unbekannten (meist x) zu finden, bei dem sie gleich bleiben.",
            sections: [
              { h: "Halte die Waage im Gleichgewicht", p: "Was immer du mit einer Seite machst, musst du auch mit der anderen Seite machen. Wenn du links 3 abziehst, ziehe auch rechts 3 ab." },
              { h: "Umkehroperationen", p: "Um x allein dastehen zu lassen, mache das rückgängig, was mit ihm gemacht wird, indem du die entgegengesetzte Operation verwendest.", list: ["+ macht − rückgängig  und  − macht + rückgängig", "× macht ÷ rückgängig  und  ÷ macht × rückgängig"] },
              { h: "Die Reihenfolge zählt", p: "Mache zuerst **Addition und Subtraktion** rückgängig, dann Multiplikation und Division. Das ist die Umkehrung der Rechenreihenfolge (Punkt vor Strich)." },
              { h: "Immer prüfen", p: "Setze deine Antwort wieder in die ursprüngliche Gleichung ein. Wenn auf beiden Seiten dasselbe herauskommt, ist deine Antwort richtig." }
            ],
            keyPoints: [
              "Mach auf beiden Seiten des Gleichheitszeichens dasselbe",
              "Mache + und − vor × und ÷ rückgängig",
              "Setze immer in die ursprüngliche Gleichung ein, um zu prüfen"
            ],
            example: {
              title: "Rechenbeispiel: 2x + 3 = 11",
              steps: ["Ziehe auf beiden Seiten 3 ab: 2x = 8", "Teile beide Seiten durch 2: x = 4", "Prüfe: 2(4) + 3 = 11 ✓"]
            }
          },
          questions: [
            { q: "Löse x + 5 = 12", options: ["7", "17", "−7", "5"], answer: 0, explain: "Ziehe auf beiden Seiten 5 ab: x = 12 − 5 = 7." },
            { q: "Löse 3x = 18", options: ["6", "15", "21", "3"], answer: 0, explain: "Teile beide Seiten durch 3: x = 18 ÷ 3 = 6." },
            { q: "Löse 2x − 4 = 10", options: ["7", "3", "14", "6"], answer: 0, explain: "Addiere auf beiden Seiten 4: 2x = 14. Teile dann durch 2: x = 7." },
            { q: "Löse x / 4 = 3", options: ["12", "7", "0.75", "4"], answer: 0, explain: "Multipliziere beide Seiten mit 4: x = 3 × 4 = 12." },
            { q: "Löse 5x + 3 = 2x + 12", options: ["3", "5", "1", "9"], answer: 0, explain: "Ziehe auf beiden Seiten 2x ab: 3x + 3 = 12. Ziehe 3 ab: 3x = 9. Teile durch 3: x = 3." },
            { q: "Welche Operation macht eine Multiplikation rückgängig?", options: ["Division", "Addition", "Subtraktion", "Quadrieren"], answer: 0, explain: "Die Division ist die Umkehrung der Multiplikation, daher macht das Teilen das Multiplizieren rückgängig." },
            { q: "Wenn 4x = 2x + 10, wie groß ist x?", options: ["5", "10", "2", "4"], answer: 0, explain: "Ziehe auf beiden Seiten 2x ab: 2x = 10, also x = 5." }
          ]
        },
        {
          id: "area-perimeter",
          title: "Fläche und Umfang",
          summary: "Miss den Weg um eine Form herum und den Raum in ihrem Inneren.",
          minutes: 7,
          explain: {
            intro: "Der **Umfang** ist die Strecke um eine Form herum, gemessen in gewöhnlichen Einheiten (cm, m). Die **Fläche** ist die Menge an Raum im Inneren, gemessen in Quadrateinheiten (cm², m²).",
            sections: [
              { h: "Rechteck", p: "Fläche = Länge × Breite.  Umfang = 2 × (Länge + Breite)." },
              { h: "Quadrat", p: "Fläche = Seite².  Umfang = 4 × Seite, weil alle vier Seiten gleich lang sind." },
              { h: "Dreieck", p: "Fläche = ½ × Grundseite × Höhe. Die Höhe muss im rechten Winkel zur Grundseite gemessen werden." },
              { h: "Kreis", p: "Umfang (der Rand) = 2πr.  Fläche = πr², wobei r der Radius ist – die Hälfte des Durchmessers." }
            ],
            keyPoints: [
              "Der Umfang ist eine Länge (cm); die Fläche wird in Quadrateinheiten (cm²) angegeben",
              "Die Kreisformeln verwenden den Radius, nicht den Durchmesser",
              "Beim Dreieck immer die senkrechte Höhe verwenden"
            ],
            example: {
              title: "Ein Rechteck ist 8 cm lang und 3 cm breit",
              steps: ["Fläche = 8 × 3 = 24 cm²", "Umfang = 2 × (8 + 3) = 22 cm"]
            }
          },
          questions: [
            { q: "Wie groß ist die Fläche eines Rechtecks von 5 cm mal 3 cm?", options: ["15 cm²", "8 cm²", "16 cm²", "10 cm²"], answer: 0, explain: "Fläche = Länge × Breite = 5 × 3 = 15 cm²." },
            { q: "Wie groß ist der Umfang eines Quadrats mit 6 cm langen Seiten?", options: ["24 cm", "36 cm", "12 cm", "30 cm"], answer: 0, explain: "Umfang = 4 × Seite = 4 × 6 = 24 cm." },
            { q: "Ein Dreieck hat eine Grundseite von 10 cm und eine Höhe von 6 cm. Wie groß ist seine Fläche?", options: ["30 cm²", "60 cm²", "16 cm²", "20 cm²"], answer: 0, explain: "Fläche = ½ × Grundseite × Höhe = ½ × 10 × 6 = 30 cm²." },
            { q: "Welche Formel ergibt den Umfang eines Kreises?", options: ["2πr", "πr²", "πr", "r²"], answer: 0, explain: "Umfang = 2πr. Die Formel πr² ergibt stattdessen die Fläche." },
            { q: "Wie groß ist die Fläche eines Kreises mit Radius 3 cm, ausgedrückt mit π?", options: ["9π cm²", "6π cm²", "3π cm²", "36π cm²"], answer: 0, explain: "Fläche = πr² = π × 3² = 9π cm²." },
            { q: "Wie groß ist der Umfang eines Rechtecks von 7 cm mal 4 cm?", options: ["22 cm", "28 cm", "11 cm", "24 cm"], answer: 0, explain: "Umfang = 2 × (7 + 4) = 2 × 11 = 22 cm. (28 cm² wäre die Fläche.)" }
          ]
        }
      ]
    },

    {
      id: "science",
      name: "Naturwissenschaften",
      tagline: "Der Wasserkreislauf, die Fotosynthese und das Sonnensystem.",
      color: "#0d9488",
      icon: "flask",
      lessons: [
        {
          id: "water-cycle",
          title: "Der Wasserkreislauf",
          summary: "Wie das Wasser zwischen den Ozeanen, dem Himmel und dem Land unterwegs ist.",
          minutes: 7,
          explain: {
            intro: "Das Wasser auf der Erde bewegt sich ständig zwischen dem Boden, der Luft und den Wolken in einem Kreislauf, den man **Wasserkreislauf** nennt. Dasselbe Wasser kreist seit Milliarden von Jahren.",
            sections: [
              { h: "1. Verdunstung", p: "Die Sonne erwärmt flüssiges Wasser in Ozeanen, Seen und Flüssen. Es wird zu einem unsichtbaren Gas namens **Wasserdampf** und steigt in die Luft auf." },
              { h: "2. Kondensation", p: "Hoch in der Atmosphäre ist die Luft kalt. Der Wasserdampf kühlt ab und wird wieder zu winzigen Tröpfchen, die sich zu **Wolken** zusammenballen." },
              { h: "3. Niederschlag", p: "Wenn die Tröpfchen schwer genug werden, fallen sie als **Regen, Schnee, Schneeregen oder Hagel** herab." },
              { h: "4. Ansammlung", p: "Das gefallene Wasser sammelt sich in Flüssen, Seen und Ozeanen oder sickert in den Boden, und der Kreislauf beginnt von vorn." },
              { h: "Transpiration", p: "Auch Pflanzen geben Wasserdampf über ihre Blätter ab. Das nennt man **Transpiration**, und sie bringt zusätzliches Wasser in die Luft." }
            ],
            keyPoints: [
              "Die Sonne ist die Energiequelle, die den gesamten Kreislauf antreibt",
              "Verdunstung = flüssig zu gasförmig; Kondensation = gasförmig zu flüssig",
              "Niederschlag ist jedes Wasser, das aus Wolken fällt",
              "Reihenfolge: Verdunstung → Kondensation → Niederschlag → Ansammlung"
            ],
            example: {
              title: "Warum schwitzt ein kaltes Glas?",
              steps: ["Die warme Luft um das Glas enthält Wasserdampf", "Die kalte Oberfläche kühlt diesen Dampf ab", "Der Dampf kondensiert zu flüssigen Tröpfchen am Glas", "Das ist Kondensation – derselbe Vorgang, der Wolken bildet"]
            }
          },
          questions: [
            { q: "Welcher Vorgang verwandelt flüssiges Wasser in Wasserdampf?", options: ["Verdunstung", "Kondensation", "Niederschlag", "Ansammlung"], answer: 0, explain: "Die Verdunstung verwandelt flüssiges Wasser beim Erwärmen in das Gas Wasserdampf." },
            { q: "Wolken entstehen, wenn Wasserdampf …", options: ["zu winzigen Tröpfchen kondensiert", "in die Luft verdunstet", "im Ozean gefriert", "in den Boden sickert"], answer: 0, explain: "Abkühlender Dampf kondensiert an Staubteilchen und bildet die winzigen Tröpfchen, aus denen Wolken bestehen." },
            { q: "Regen, Schnee und Hagel sind alles Beispiele für …", options: ["Niederschlag", "Kondensation", "Verdunstung", "Transpiration"], answer: 0, explain: "Niederschlag ist jedes Wasser, das aus Wolken auf den Boden fällt." },
            { q: "Was ist die wichtigste Energiequelle, die den Wasserkreislauf antreibt?", options: ["Die Sonne", "Der Mond", "Der Wind", "Vulkane"], answer: 0, explain: "Die Sonnenenergie erwärmt das Wasser und bewirkt die Verdunstung, die den gesamten Kreislauf antreibt." },
            { q: "Wasserdampf, den Pflanzenblätter abgeben, heißt …", options: ["Transpiration", "Verdunstung", "Niederschlag", "Versickerung"], answer: 0, explain: "Transpiration ist die Abgabe von Wasserdampf durch Pflanzen, vor allem über ihre Blätter." },
            { q: "Welche Reihenfolge des Wasserkreislaufs ist richtig?", options: ["Verdunstung → Kondensation → Niederschlag → Ansammlung", "Kondensation → Verdunstung → Ansammlung → Niederschlag", "Niederschlag → Ansammlung → Kondensation → Verdunstung", "Ansammlung → Niederschlag → Verdunstung → Kondensation"], answer: 0, explain: "Wasser verdunstet, kondensiert zu Wolken, fällt als Niederschlag und wird wieder gesammelt." }
          ]
        },
        {
          id: "photosynthesis",
          title: "Die Fotosynthese",
          summary: "Wie grüne Pflanzen Sonnenlicht in Nahrung verwandeln.",
          minutes: 8,
          explain: {
            intro: "Die **Fotosynthese** ist der Vorgang, mit dem grüne Pflanzen aus Sonnenlicht ihre eigene Nahrung herstellen. Ihr verdanken wir den Sauerstoff, den wir atmen.",
            sections: [
              { h: "Die Zutaten", p: "Pflanzen nehmen **Kohlenstoffdioxid** aus der Luft über winzige Öffnungen in ihren Blättern auf, die Spaltöffnungen heißen, und **Wasser** aus dem Boden über ihre Wurzeln." },
              { h: "Die Energie", p: "**Chlorophyll** ist der grüne Farbstoff in den Chloroplasten. Er fängt die Lichtenergie ein und treibt die Reaktion an." },
              { h: "Die Produkte", p: "Die Pflanze stellt **Glucose** her, einen Zucker, den sie für Energie und Wachstum nutzt, und gibt **Sauerstoff** als Nebenprodukt an die Luft ab." },
              { h: "Die Wortgleichung", p: "Kohlenstoffdioxid + Wasser + Lichtenergie → Glucose + Sauerstoff. In Symbolen: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂." }
            ],
            keyPoints: [
              "Benötigt: Kohlenstoffdioxid, Wasser, Sonnenlicht und Chlorophyll",
              "Erzeugt: Glucose und Sauerstoff",
              "Findet in den Chloroplasten statt, überwiegend in den Blättern",
              "Pflanzen und Algen tun es – Tiere können es nicht"
            ],
            example: {
              title: "Die Fotosynthese nachweisen",
              steps: ["Bedecke einen Teil eines Blattes, sodass kein Licht ihn erreicht", "Lass die Pflanze einen Tag im Sonnenlicht stehen", "Teste das Blatt mit Iod – dort, wo Stärke vorhanden ist, wird es blau-schwarz", "Nur der unbedeckte Teil wird dunkel, was beweist, dass Licht nötig ist"]
            }
          },
          questions: [
            { q: "Welches Gas nehmen Pflanzen für die Fotosynthese auf?", options: ["Kohlenstoffdioxid", "Sauerstoff", "Stickstoff", "Wasserstoff"], answer: 0, explain: "Pflanzen nehmen Kohlenstoffdioxid über die Spaltöffnungen in ihren Blättern auf." },
            { q: "Welches Gas wird als Nebenprodukt der Fotosynthese freigesetzt?", options: ["Sauerstoff", "Kohlenstoffdioxid", "Methan", "Helium"], answer: 0, explain: "Sauerstoff wird als Abfallprodukt freigesetzt – zu unserem Glück." },
            { q: "Der grüne Farbstoff, der Lichtenergie einfängt, ist …", options: ["Chlorophyll", "Carotin", "Melanin", "Hämoglobin"], answer: 0, explain: "Chlorophyll absorbiert rotes und blaues Licht und reflektiert Grün – deshalb sehen Blätter grün aus." },
            { q: "In welchem Teil einer Pflanzenzelle findet die Fotosynthese statt?", options: ["Chloroplast", "Zellkern", "Zellwand", "Vakuole"], answer: 0, explain: "Die Chloroplasten enthalten das Chlorophyll, das nötig ist, um Lichtenergie einzufangen." },
            { q: "Welcher Zucker entsteht direkt bei der Fotosynthese?", options: ["Glucose", "Lactose", "Sucralose", "Maltose"], answer: 0, explain: "Glucose ist der Zucker, der bei der Fotosynthese entsteht; er wird als Stärke gespeichert." },
            { q: "In welchem Teil der Pflanze findet die Fotosynthese hauptsächlich statt?", options: ["Blätter", "Wurzeln", "Blüten", "Samen"], answer: 0, explain: "Blätter haben die größte Oberfläche und die meisten Chloroplasten, deshalb findet dort der größte Teil der Fotosynthese statt." }
          ]
        },
        {
          id: "solar-system",
          title: "Das Sonnensystem",
          summary: "Acht Planeten und die Objekte, die unsere Sonne umkreisen.",
          minutes: 6,
          explain: {
            intro: "Unser Sonnensystem hat **8 Planeten**, die die Sonne umkreisen und durch die Schwerkraft in ihrer Bahn gehalten werden. Die Sonne enthält mehr als 99 % der gesamten Masse des Systems.",
            sections: [
              { h: "Die inneren Planeten", p: "Merkur, Venus, Erde und Mars sind **felsige (terrestrische) Planeten** und liegen der Sonne am nächsten." },
              { h: "Die äußeren Planeten", p: "Jupiter, Saturn, Uranus und Neptun sind riesige **Gas- und Eisriesen**, die überwiegend aus Wasserstoff, Helium und Eis bestehen." },
              { h: "Andere Objekte", p: "Der Asteroidengürtel zwischen Mars und Jupiter, Hunderte Monde, Kometen und Zwergplaneten wie Pluto umkreisen ebenfalls die Sonne." },
              { h: "Reihenfolge von der Sonne", p: "Merkur, Venus, Erde, Mars, Jupiter, Saturn, Uranus, Neptun. Ein Merkspruch: **Mein Vater erklärt mir jeden Sonntag unseren Nachthimmel**." }
            ],
            keyPoints: [
              "Merkur ist der Sonne am nächsten; Neptun am weitesten entfernt",
              "Jupiter ist der größte Planet, Merkur der kleinste",
              "Pluto ist ein Zwergplanet, kein Planet",
              "Die Erde hat einen natürlichen Begleiter: den Mond"
            ],
            example: {
              title: "Größen vergleichen",
              steps: ["Jupiters Durchmesser beträgt etwa 143.000 km", "Der Durchmesser der Erde beträgt etwa 12.700 km", "Jupiter ist ungefähr 11-mal breiter als die Erde"]
            }
          },
          questions: [
            { q: "Welcher Planet ist der größte in unserem Sonnensystem?", options: ["Jupiter", "Saturn", "Erde", "Neptun"], answer: 0, explain: "Jupiter ist der größte Planet – etwa 11-mal breiter als die Erde." },
            { q: "Welcher Planet ist der Sonne am nächsten?", options: ["Merkur", "Venus", "Erde", "Mars"], answer: 0, explain: "Merkur ist der innerste Planet und umkreist die Sonne am nächsten." },
            { q: "Welcher davon wird nicht mehr als Planet eingestuft?", options: ["Pluto", "Neptun", "Uranus", "Mars"], answer: 0, explain: "Im Jahr 2006 wurde Pluto zum Zwergplaneten umgestuft, weil er seine Umlaufbahn nicht freigeräumt hat." },
            { q: "Welcher Planet ist als der Rote Planet bekannt?", options: ["Mars", "Venus", "Jupiter", "Merkur"], answer: 0, explain: "Mars erscheint rot, weil seine Oberfläche reich an Eisenoxid (Rost) ist." },
            { q: "Welcher Planet ist für sein helles Ringsystem berühmt?", options: ["Saturn", "Mars", "Merkur", "Venus"], answer: 0, explain: "Saturns Ringe bestehen aus Eis- und Gesteinsteilchen. Auch Jupiter, Uranus und Neptun haben schwache Ringe." },
            { q: "Wie viele Planeten hat unser Sonnensystem?", options: ["8", "9", "7", "10"], answer: 0, explain: "Es gibt 8 Planeten: Merkur, Venus, Erde, Mars, Jupiter, Saturn, Uranus und Neptun." },
            { q: "Was ist der natürliche Begleiter der Erde?", options: ["Der Mond", "Phobos", "Titan", "Europa"], answer: 0, explain: "Der Mond umkreist die Erde. Phobos umkreist den Mars; Titan und Europa umkreisen Saturn und Jupiter." }
          ]
        }
      ]
    },

    {
      id: "geography",
      name: "Geografie",
      tagline: "Kontinente, Ozeane und die Hauptstädte der Welt.",
      color: "#ea580c",
      icon: "globe",
      lessons: [
        {
          id: "continents",
          title: "Kontinente & Ozeane",
          summary: "Die sieben Landmassen und fünf Ozeane des Planeten Erde.",
          minutes: 6,
          explain: {
            intro: "Die Erde hat **7 Kontinente** – riesige zusammenhängende Landflächen – und **5 Ozeane**, die etwa 71 % der Oberfläche bedecken.",
            sections: [
              { h: "Die sieben Kontinente", p: "Von der größten zur kleinsten Fläche: **Asien, Afrika, Nordamerika, Südamerika, Antarktis, Europa, Australien (Ozeanien)**." },
              { h: "Die fünf Ozeane", p: "Vom größten zum kleinsten: **Pazifik, Atlantik, Indischer Ozean, Südlicher Ozean, Arktischer Ozean**." },
              { h: "Wissenswerte Rekorde", p: "Größter Kontinent: Asien. Kleinster: Australien. Größter Ozean: der Pazifik. Der tiefste Ort der Erde ist der Marianengraben im Pazifischen Ozean, etwa 11 km tief." },
              { h: "Eine nützliche Tatsache", p: "Afrika ist der einzige Kontinent, der in allen vier Hemisphären liegt – Nord, Süd, Ost und West." }
            ],
            keyPoints: [
              "7 Kontinente, 5 Ozeane",
              "Asien ist der größte Kontinent und Australien der kleinste",
              "Der Pazifik ist der größte und tiefste Ozean",
              "Afrika überquert den Äquator und beide Hauptlängengrade"
            ],
            example: {
              title: "Wo liegt die Sahara?",
              steps: ["Die Sahara ist die größte Wüste der Erde", "Sie bedeckt etwa 9 Millionen km²", "Sie erstreckt sich über 11 Länder", "Sie liegt in Nordafrika, auf dem Kontinent Afrika"]
            }
          },
          questions: [
            { q: "Welcher ist der größte Kontinent nach Fläche?", options: ["Asien", "Afrika", "Europa", "Nordamerika"], answer: 0, explain: "Asien ist der größte Kontinent, bedeckt etwa 44 Millionen km² und beherbergt den größten Teil der Weltbevölkerung." },
            { q: "Wie viele Kontinente gibt es auf der Erde?", options: ["7", "5", "6", "8"], answer: 0, explain: "Es gibt sieben Kontinente: Asien, Afrika, Nordamerika, Südamerika, Antarktis, Europa und Australien." },
            { q: "Welcher ist der größte Ozean?", options: ["Pazifik", "Atlantik", "Indischer Ozean", "Arktischer Ozean"], answer: 0, explain: "Der Pazifik ist der größte und tiefste Ozean und bedeckt etwa ein Drittel des Planeten." },
            { q: "Welcher Ozean liegt zwischen Afrika und Amerika?", options: ["Atlantik", "Pazifik", "Indischer Ozean", "Südlicher Ozean"], answer: 0, explain: "Der Atlantik trennt Afrika und Europa vom amerikanischen Doppelkontinent." },
            { q: "Auf welchem Kontinent liegt die Sahara?", options: ["Afrika", "Asien", "Australien", "Südamerika"], answer: 0, explain: "Die Sahara bedeckt einen großen Teil Nordafrikas." },
            { q: "Welcher Kontinent ist der kleinste?", options: ["Australien", "Europa", "Antarktis", "Südamerika"], answer: 0, explain: "Australien (Ozeanien) ist der kleinste Kontinent nach Landfläche." }
          ]
        },
        {
          id: "capitals",
          title: "Hauptstädte der Welt",
          summary: "Die Hauptstädte, die am häufigsten verwechselt werden.",
          minutes: 6,
          explain: {
            intro: "Jedes Land hat eine **Hauptstadt** – den Sitz seiner Regierung. Sie ist nicht immer die größte oder bekannteste Stadt des Landes.",
            sections: [
              { h: "Bekannte Hauptstädte", p: "", list: ["Ägypten → Kairo", "Frankreich → Paris", "Japan → Tokio", "Italien → Rom", "Vereinigtes Königreich → London"] },
              { h: "Die oft verwechselten", p: "", list: ["Vereinigte Arabische Emirate → Abu Dhabi (nicht Dubai)", "Türkei → Ankara (nicht Istanbul)", "Australien → Canberra (nicht Sydney)", "Kanada → Ottawa (nicht Toronto)", "Brasilien → Brasília (nicht Rio de Janeiro)", "Vereinigte Staaten → Washington, D.C. (nicht New York)", "Schweiz → Bern (nicht Zürich)"] },
              { h: "Warum Hauptstädte sich von großen Städten unterscheiden", p: "Manche Hauptstädte wurden absichtlich als neutrale Orte gebaut und um Reichtum weg von der größten Stadt zu verteilen – Canberra, Brasília und Ottawa wurden alle aus diesem Grund gewählt." }
            ],
            keyPoints: [
              "Die Hauptstadt ist der Regierungssitz, nicht immer die größte Stadt",
              "VAE → Abu Dhabi, Türkei → Ankara, Brasilien → Brasília",
              "Canberra, Brasília und Ottawa wurden eigens als Hauptstädte gebaut"
            ],
            example: {
              title: "Die VAE vergleichen",
              steps: ["Dubai ist die bekannteste Stadt und ein wichtiges Wirtschaftszentrum", "Die Hauptstadt ist Abu Dhabi", "In Abu Dhabi sitzt die Bundesregierung", "Die Antwort auf 'Hauptstadt der VAE' lautet also Abu Dhabi, nicht Dubai"]
            }
          },
          questions: [
            { q: "Wie heißt die Hauptstadt von Ägypten?", options: ["Kairo", "Alexandria", "Gizeh", "Luxor"], answer: 0, explain: "Kairo ist die Hauptstadt von Ägypten und die größte Stadt der arabischen Welt." },
            { q: "Wie heißt die Hauptstadt von Japan?", options: ["Tokio", "Osaka", "Kyoto", "Sapporo"], answer: 0, explain: "Tokio ist seit 1868 die Hauptstadt Japans." },
            { q: "Wie heißt die Hauptstadt der Vereinigten Arabischen Emirate?", options: ["Abu Dhabi", "Dubai", "Schardscha", "Doha"], answer: 0, explain: "Abu Dhabi ist die Hauptstadt. Dubai ist die größte Stadt, aber nicht die Hauptstadt; Doha ist die Hauptstadt von Katar." },
            { q: "Wie heißt die Hauptstadt von Kanada?", options: ["Ottawa", "Toronto", "Vancouver", "Montreal"], answer: 0, explain: "Ottawa ist die Hauptstadt. Toronto ist die größte Stadt." },
            { q: "Wie heißt die Hauptstadt von Brasilien?", options: ["Brasília", "Rio de Janeiro", "São Paulo", "Salvador"], answer: 0, explain: "Brasília wurde eigens gebaut und wurde 1960 zur Hauptstadt." },
            { q: "Wie heißt die Hauptstadt von Australien?", options: ["Canberra", "Sydney", "Melbourne", "Perth"], answer: 0, explain: "Canberra ist die Hauptstadt – gewählt als Kompromiss zwischen den Rivalen Sydney und Melbourne." },
            { q: "Wie heißt die Hauptstadt von Frankreich?", options: ["Paris", "Lyon", "Marseille", "Nizza"], answer: 0, explain: "Paris ist die Hauptstadt und größte Stadt Frankreichs." }
          ]
        }
      ]
    },

    {
      id: "computing",
      name: "Informatik",
      tagline: "Wie Computer funktionieren und wie du online sicher bleibst.",
      color: "#0284c7",
      icon: "monitor",
      lessons: [
        {
          id: "computer-basics",
          title: "Wie Computer funktionieren",
          summary: "Eingabe, Verarbeitung, Ausgabe, Speicherung – und Hardware vs. Software.",
          minutes: 7,
          explain: {
            intro: "Fast jeder Computer folgt demselben Muster: Er nimmt **Eingaben** auf, **verarbeitet** sie, erzeugt eine **Ausgabe** und kann die Ergebnisse **speichern**.",
            sections: [
              { h: "Eingabe", p: "Eingabegeräte senden Daten in den Computer.", list: ["Tastatur, Maus, Mikrofon, Kamera, Touchscreen, Scanner"] },
              { h: "Verarbeitung", p: "Die **CPU** (Central Processing Unit, zentrale Recheneinheit) führt die Befehle aus – sie wird oft als das Gehirn des Computers bezeichnet. Mehr Kerne und eine höhere Taktfrequenz bedeuten mehr Arbeit auf einmal." },
              { h: "Ausgabe", p: "Ausgabegeräte präsentieren die Ergebnisse.", list: ["Monitor, Lautsprecher, Drucker, Kopfhörer"] },
              { h: "Speicherung", p: "Der **Arbeitsspeicher (RAM)** ist sehr schnell, aber nur vorübergehend – er wird gelöscht, wenn der Strom ausfällt. Eine **Festplatte oder SSD** speichert deine Dateien dauerhaft, auch wenn der Computer ausgeschaltet ist." },
              { h: "Hardware vs. Software", p: "**Hardware** ist die physische Ausstattung, die man anfassen kann (Bildschirm, CPU, Tastatur). **Software** ist die Gesamtheit der Programme und Anweisungen (das Betriebssystem, ein Browser, ein Spiel)." }
            ],
            keyPoints: [
              "CPU = der Prozessor, das Gehirn des Computers",
              "RAM = schneller, vorübergehender Speicher; SSD/HDD = dauerhafter Speicher",
              "Hardware kann man anfassen, Software nicht",
              "Jede Aufgabe folgt dem Muster Eingabe → Verarbeitung → Ausgabe"
            ],
            example: {
              title: "Dem Muster folgen: einen Brief tippen",
              steps: ["Eingabe: Du drückst die Tasten auf der Tastatur", "Verarbeitung: Die CPU wandelt die Tastendrücke in Zeichen um", "Ausgabe: Die Buchstaben erscheinen auf dem Bildschirm", "Speicherung: Du speicherst die Datei auf der SSD"]
            }
          },
          questions: [
            { q: "Welches davon ist ein Eingabegerät?", options: ["Tastatur", "Monitor", "Drucker", "Lautsprecher"], answer: 0, explain: "Eine Tastatur sendet Daten in den Computer, ist also ein Eingabegerät. Die anderen sind Ausgabegeräte." },
            { q: "Wofür steht die Abkürzung CPU?", options: ["Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Control Panel Unit"], answer: 0, explain: "CPU steht für Central Processing Unit – den Teil, der die Befehle ausführt." },
            { q: "Welche Art von Speicher verliert ihren Inhalt, wenn der Strom abgeschaltet wird?", options: ["RAM", "SSD", "Festplatte", "USB-Stick"], answer: 0, explain: "Der RAM ist ein flüchtiger Speicher. SSDs, Festplatten und USB-Sticks behalten Daten ohne Strom." },
            { q: "Welches davon ist Software?", options: ["Ein Betriebssystem", "Eine Tastatur", "Eine Maus", "Ein Monitor"], answer: 0, explain: "Ein Betriebssystem ist ein Programm, also Software. Der Rest ist physische Hardware." },
            { q: "Welches Gerät erzeugt eine Ausgabe?", options: ["Drucker", "Mikrofon", "Scanner", "Maus"], answer: 0, explain: "Ein Drucker zeigt Ergebnisse auf Papier, ist also ein Ausgabegerät." },
            { q: "Welcher Speicher bewahrt deine Dateien dauerhaft auf?", options: ["SSD", "RAM", "Cache", "Register"], answer: 0, explain: "Eine SSD (oder Festplatte) speichert Daten dauerhaft, auch wenn der Computer ausgeschaltet ist." }
          ]
        },
        {
          id: "online-safety",
          title: "Das Internet & Online-Sicherheit",
          summary: "Passwörter, Phishing und der Schutz deiner persönlichen Daten.",
          minutes: 8,
          explain: {
            intro: "Das Internet ist mächtig, aber alles, was du veröffentlichst, und jedes Passwort, das du eingibst, muss geschützt werden. Ein paar einfache Gewohnheiten halten dich sicher.",
            sections: [
              { h: "Starke Passwörter", p: "Verwende mindestens 12 Zeichen mit einer Mischung aus Groß- und Kleinbuchstaben, Zahlen und Symbolen. **Verwende niemals** dasselbe Passwort auf verschiedenen Websites, und benutze nie deinen Namen oder dein Geburtsdatum." },
              { h: "Phishing", p: "Gefälschte E-Mails, Nachrichten oder Websites, die sich als echt ausgeben, um dein Passwort oder deine Bankdaten zu stehlen. Die Warnsignale: Dringlichkeit, Rechtschreibfehler, seltsame Absenderadressen und Links, die nicht zur echten Website passen." },
              { h: "Zwei-Faktor-Authentifizierung (2FA)", p: "Fügt einen zweiten Identitätsnachweis hinzu – meist einen Code auf deinem Handy –, sodass ein gestohlenes Passwort allein nicht ausreicht, um in dein Konto zu gelangen." },
              { h: "HTTPS und das Schloss", p: "Das Schloss in der Adressleiste bedeutet, dass die Verbindung **verschlüsselt** ist. Gib niemals ein Passwort auf einer Seite ohne dieses Symbol ein." },
              { h: "Persönliche Informationen", p: "Teile niemals deinen vollständigen Namen, deine Adresse, den Namen deiner Schule oder Fotos mit Fremden im Internet. Was einmal veröffentlicht ist, lässt sich nur sehr schwer entfernen." }
            ],
            keyPoints: [
              "Lange, einzigartige Passwörter – ein Passwortmanager hilft",
              "Klicke niemals auf Links in unerwarteten Nachrichten",
              "Aktiviere die Zwei-Faktor-Authentifizierung, wo immer sie angeboten wird",
              "Ein Schloss (HTTPS) bedeutet, dass die Verbindung verschlüsselt ist",
              "Halte persönliche Informationen geheim"
            ],
            example: {
              title: "Eine Phishing-Nachricht erkennen",
              steps: ["Es heißt, dein Konto werde in 1 Stunde geschlossen (Dringlichkeit)", "Die Absenderadresse ist support@bank-secure-login.xyz (nicht die echte Domain)", "Der Link führt woanders hin als zur Website der Bank", "Es wird verlangt, dass du dein Passwort eingibst, um es zu bestätigen", "Fazit: Lösche sie und melde sie – klicke nicht"]
            }
          },
          questions: [
            { q: "Wofür steht das 'S' in HTTPS?", options: ["Secure", "Simple", "Server", "Speed"], answer: 0, explain: "HTTPS bedeutet HyperText Transfer Protocol Secure – die Verbindung ist verschlüsselt." },
            { q: "Was ist Phishing?", options: ["Eine gefälschte Nachricht, die versucht, deine Daten zu stehlen", "Eine Möglichkeit, das Internet zu beschleunigen", "Eine Art Firewall", "Eine Suchmaschine"], answer: 0, explain: "Phishing ist ein Trick, bei dem sich jemand als vertrauenswürdige Organisation ausgibt, damit du Passwörter oder Zahlungsdaten preisgibst." },
            { q: "Welches Passwort ist das stärkste?", options: ["Tr7#kL9!pQ2@", "passwort123", "deinname2010", "12345678"], answer: 0, explain: "Es ist lang und mischt Groß- und Kleinschreibung, Zahlen und Symbole, was es sehr schwer zu erraten macht." },
            { q: "Was fügt die Zwei-Faktor-Authentifizierung hinzu?", options: ["Einen zweiten Identitätsnachweis, etwa einen Code auf deinem Handy", "Ein längeres Passwort", "Eine schnellere Internetverbindung", "Eine Ersatz-E-Mail-Adresse"], answer: 0, explain: "2FA verlangt etwas, das du weißt, plus etwas, das du hast, sodass ein gestohlenes Passwort nicht ausreicht." },
            { q: "Eine Nachricht behauptet, du hättest einen Preis gewonnen, und du sollst zum Einlösen auf einen Link klicken. Was solltest du tun?", options: ["Sie löschen oder melden, ohne auf den Link zu klicken", "Schnell klicken, bevor sie abläuft", "Mit deinen Bankdaten antworten", "Sie an alle deine Freunde weiterleiten"], answer: 0, explain: "Das ist ein klassischer Phishing-Köder. Dringlichkeit und Preise sind die Warnsignale – nicht klicken, einfach löschen oder melden." },
            { q: "Was bedeutet ein Schloss-Symbol in der Adressleiste?", options: ["Die Verbindung ist verschlüsselt", "Die Website ist kostenlos nutzbar", "Die Website ist die schnellste", "Die Seite gehört einer Regierung"], answer: 0, explain: "Das Schloss zeigt, dass die Verbindung HTTPS verwendet und verschlüsselt ist, sodass Daten unterwegs nicht leicht gelesen werden können." }
          ]
        }
      ]
    },

    {
      id: "arabic",
      name: "Arabisch",
      tagline: "Das Alphabet, alltägliche Begrüßungen und die Zahlen 1 bis 10.",
      color: "#16a34a",
      icon: "book",
      lessons: [
        {
          id: "alphabet",
          title: "Das arabische Alphabet",
          summary: "28 Buchstaben, von rechts nach links geschrieben, die je nach Position ihre Form ändern.",
          minutes: 9,
          explain: {
            intro: "Arabisch (العربية) wird **von rechts nach links** geschrieben und verwendet **28 Buchstaben**. Die meisten Buchstaben ändern zudem leicht ihre Form, je nachdem, wo sie in einem Wort stehen.",
            sections: [
              { h: "Die ersten Buchstaben", p: "Hier sind einige Buchstaben mit dem Laut, den sie erzeugen:", list: ["ا alif — a", "ب bā — b", "ت tā — t", "ث thā — th (wie in engl. think)", "ج jīm — dsch", "د dāl — d", "ر rā — r", "س sīn — s", "ش shīn — sch", "م mīm — m", "ن nūn — n", "ه hā — h", "ي yā — j"] },
              { h: "Buchstaben ändern ihre Form", p: "Ein Buchstabe hat eine **isolierte** Form, eine **Anfangsform**, eine **Mittelform** und eine **Endform**. Die Grundform bleibt gleich, aber die Art der Verbindung ändert sich. Zum Beispiel sieht ب so aus: ب (allein), بـ (am Anfang), ـبـ (in der Mitte), ـب (am Ende)." },
              { h: "Kurze Vokale (Harakat)", p: "Kurze Vokale werden als kleine Zeichen über oder unter einem Buchstaben geschrieben: Eine **Fatha** (َ) ergibt einen 'a'-Laut, eine **Kasra** (ِ) ergibt 'i' und eine **Damma** (ُ) ergibt 'u'. Kinderbücher drucken sie alle; in Texten für Erwachsene werden sie oft weggelassen." },
              { h: "In welche Richtung geht es?", p: "Lies die einzelnen Buchstaben von rechts nach links, aber die Zahlen von links nach rechts. Die arabischen Ziffern ١ ٢ ٣ werden in derselben Links-nach-rechts-Reihenfolge geschrieben wie deutsche Zahlen." }
            ],
            keyPoints: [
              "28 Buchstaben, immer von rechts nach links geschrieben",
              "Ein Buchstabe ändert seine Form je nach Position im Wort",
              "Kurze Vokale werden als Zeichen über oder unter den Buchstaben geschrieben",
              "Arabische Ziffern werden von links nach rechts geschrieben"
            ],
            example: {
              title: "Dein erstes Wort lesen: كِتَاب (kitāb, Buch)",
              steps: ["Beginne rechts: ك  = k-Laut", "ت  = t-Laut, mit einer Kasra (ِ) darunter → kɪ", "ا  = langes ā", "ب  = b-Laut", "Zusammen gelesen: كِتَاب = ki-tāb"]
            }
          },
          questions: [
            { q: "Wie viele Buchstaben hat das arabische Alphabet?", options: ["28", "26", "29", "22"], answer: 0, explain: "Das arabische Alphabet hat 28 Buchstaben, beginnt mit Alif (ا) und endet mit Yā (ي)." },
            { q: "In welche Richtung wird Arabisch geschrieben?", options: ["Von rechts nach links", "Von links nach rechts", "Von oben nach unten", "Das ändert sich je nach Thema"], answer: 0, explain: "Arabisch wird von rechts nach links geschrieben und gelesen." },
            { q: "Welcher Buchstabe ist der erste des arabischen Alphabets?", options: ["ا (alif)", "ب (bā)", "م (mīm)", "ي (yā)"], answer: 0, explain: "Alif (ا) ist der erste Buchstabe und Yā (ي) der letzte." },
            { q: "Welchen Laut erzeugt der Buchstabe ب?", options: ["b", "m", "t", "n"], answer: 0, explain: "ب ist bā und erzeugt den Laut 'b'. Achtung: م erzeugt 'm' und ن erzeugt 'n'." },
            { q: "Welcher davon ist der Buchstabe mīm?", options: ["م", "ن", "ه", "ل"], answer: 0, explain: "م ist mīm (m). ن ist nūn (n), ه ist hā (h) und ل ist lām (l)." },
            { q: "Warum ändern arabische Buchstaben ihre Form?", options: ["Ihre Form hängt von ihrer Position im Wort ab", "Sie ändern nie ihre Form", "Um anzuzeigen, ob der Sprecher männlich ist", "Um die Vergangenheitsform anzuzeigen"], answer: 0, explain: "Buchstaben haben isolierte, anfängliche, mittlere und endständige Formen, je nachdem, wo sie im Wort stehen." },
            { q: "Wie heißen die kleinen Vokalzeichen über und unter den Buchstaben?", options: ["Harakat", "Zahlen", "Wurzelbuchstaben", "Satzzeichen"], answer: 0, explain: "Harakat sind die kurzen Vokalzeichen – Fatha (َ), Kasra (ِ) und Damma (ُ)." }
          ]
        },
        {
          id: "greetings",
          title: "Begrüßungen & Vorstellungen",
          summary: "Sag Hallo, frag, wie es jemandem geht, und stelle dich vor.",
          minutes: 8,
          explain: {
            intro: "Arabische Begrüßungen sind großzügig – oft tauscht man mehrere gleichzeitig aus. Hier sind die Wendungen, die du jeden Tag hören wirst.",
            sections: [
              { h: "Hallo und willkommen", p: "", list: ["السلام عليكم — as-salāmu ʿalaykum (Friede sei mit dir)", "وعليكم السلام — wa ʿalaykumu s-salām (die Antwort: auch mit dir sei Friede)", "مرحبا — marhaba (hallo)", "أهلا وسهلا — ahlan wa sahlan (willkommen)"] },
              { h: "Nach Tageszeit", p: "", list: ["صباح الخير — sabāh al-khayr (guten Morgen)", "مساء الخير — masāʾ al-khayr (guten Abend)"] },
              { h: "Fragen und Antworten", p: "", list: ["كيف حالك؟ — kayfa hāluk? (wie geht es dir? — zu einem Mann)", "كيف حالكِ؟ — kayfa hāluki? (zu einer Frau)", "أنا بخير، شكرا — anā bi-khayr, shukran (mir geht es gut, danke)", "ما اسمك؟ — mā ismuk? (wie heißt du?)", "اسمي… — ismī … (ich heiße …)"] },
              { h: "Auf Wiedersehen sagen", p: "", list: ["شكرا — shukran (danke)", "عفوا — ʿafwan (bitte / gern geschehen)", "مع السلامة — maʿa s-salāma (auf Wiedersehen)"] }
            ],
            keyPoints: [
              "السلام عليكم ist die häufigste Begrüßung – antworte mit وعليكم السلام",
              "مساء الخير verwendet man ab dem späten Nachmittag",
              "شكرا bedeutet danke und عفوا bedeutet gern geschehen",
              "مع السلامة bedeutet auf Wiedersehen"
            ],
            example: {
              title: "Ein kurzes Gespräch",
              steps: ["A: السلام عليكم  (Friede sei mit dir)", "B: وعليكم السلام  (und auch mit dir sei Friede)", "A: كيف حالك؟  (wie geht es dir?)", "B: أنا بخير، شكرا  (mir geht es gut, danke)", "A: ما اسمك؟  (wie heißt du?)", "B: اسمي نور  (ich heiße Noor)"]
            }
          },
          questions: [
            { q: "Was bedeutet مرحبا (marhaba)?", options: ["Hallo", "Auf Wiedersehen", "Danke", "Entschuldigung"], answer: 0, explain: "مرحبا (marhaba) ist eine freundliche Art, hallo zu sagen." },
            { q: "Wie sagt man 'Guten Morgen' auf Arabisch?", options: ["صباح الخير", "مساء الخير", "مع السلامة", "شكرا"], answer: 0, explain: "صباح الخير (sabāh al-khayr) bedeutet guten Morgen. مساء الخير ist guten Abend." },
            { q: "Was bedeutet شكرا (shukran)?", options: ["Danke", "Bitte", "Hallo", "Ja"], answer: 0, explain: "شكرا bedeutet danke. Du kannst mit عفوا (gern geschehen) antworten." },
            { q: "Was bedeutet ما اسمك؟ (mā ismuk?)?", options: ["Wie heißt du?", "Wie alt bist du?", "Woher kommst du?", "Wie geht es dir?"], answer: 0, explain: "ما اسمك؟ bedeutet wörtlich 'was dein Name?' – wie heißt du?" },
            { q: "Wenn jemand كيف حالك؟ sagt, welche Antwort passt am besten?", options: ["أنا بخير، شكرا", "مع السلامة", "صباح الخير", "ما اسمك؟"], answer: 0, explain: "كيف حالك؟ fragt, wie es dir geht, also ist أنا بخير، شكرا (mir geht es gut, danke) die natürliche Antwort." },
            { q: "Was bedeutet مع السلامة (maʿa s-salāma)?", options: ["Auf Wiedersehen", "Willkommen", "Gute Nacht", "Danke"], answer: 0, explain: "مع السلامة bedeutet wörtlich 'mit Sicherheit' und wird beim Abschied verwendet." },
            { q: "Welche Begrüßung verwendest du, wenn ein Gast bei dir zu Hause ankommt?", options: ["أهلا وسهلا", "مع السلامة", "شكرا", "اسمي"], answer: 0, explain: "أهلا وسهلا (ahlan wa sahlan) bedeutet willkommen und wird verwendet, um ankommende Gäste zu begrüßen." }
          ]
        },
        {
          id: "numbers",
          title: "Zahlen ١ – ١٠",
          summary: "Zähle auf Arabisch von eins bis zehn, in Wörtern und Ziffern.",
          minutes: 6,
          explain: {
            intro: "Arabisch hat eigene Ziffern – ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠ –, die **von links nach rechts** geschrieben werden, obwohl die Sprache selbst von rechts nach links läuft.",
            sections: [
              { h: "Zahlen ١ – ٥", p: "", list: ["١ واحد — wāhid (1)", "٢ اثنان — ithnān (2)", "٣ ثلاثة — thalātha (3)", "٤ أربعة — arbaʿa (4)", "٥ خمسة — khamsa (5)"] },
              { h: "Zahlen ٦ – ١٠", p: "", list: ["٦ ستة — sitta (6)", "٧ سبعة — sabʿa (7)", "٨ ثمانية — thamāniya (8)", "٩ تسعة — tisʿa (9)", "١٠ عشرة — ʿashara (10)"] },
              { h: "Wie die Ziffern aussehen", p: "Beachte, dass ٠ als einfacher Punkt geschrieben wird und ١ wie eine gespiegelte deutsche 1 aussieht. ٢ und ٣ sind zueinander umgekehrte Versionen, also verwechsle sie nicht." },
              { h: "Lerntipp", p: "Lerne sie paarweise: ١/٢, ٣/٤, ٥/٦, ٧/٨ und ٩/١٠. Wiederhole jedes Paar fünfmal laut, dann bleiben sie durch den Rhythmus besser haften." }
            ],
            keyPoints: [
              "Arabische Ziffern: ٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩",
              "Zahlen werden von links nach rechts gelesen",
              "خمسة (khamsa) ist fünf, عشرة (ʿashara) ist zehn"
            ],
            example: {
              title: "Gegenstände zählen",
              steps: ["كتاب واحد — kitāb wāhid (ein Buch)", "كتابان اثنان — kitābān ithnān (zwei Bücher)", "ثلاثة كتب — thalātha kutub (drei Bücher)", "عشرة كتب — ʿashara kutub (zehn Bücher)"]
            }
          },
          questions: [
            { q: "Welches ist die arabische Ziffer für 5?", options: ["٥", "٤", "٦", "٥٠"], answer: 0, explain: "٥ ist fünf, ausgesprochen khamsa (خمسة)." },
            { q: "Was bedeutet ثلاثة (thalātha)?", options: ["Drei", "Vier", "Zwei", "Zehn"], answer: 0, explain: "ثلاثة ist drei. أربعة ist vier und اثنان ist zwei." },
            { q: "Wie wird die Zahl 7 in arabischen Ziffern geschrieben?", options: ["٧", "٦", "٩", "١٠"], answer: 0, explain: "٧ ist 7 (sabʿa). ٦ ist 6 und ٩ ist 9." },
            { q: "Was bedeutet عشرة (ʿashara)?", options: ["Zehn", "Neun", "Fünf", "Eins"], answer: 0, explain: "عشرة ist zehn. تسعة ist neun und واحد ist eins." },
            { q: "Welche Zahl ist ٢?", options: ["Zwei", "Eins", "Drei", "Zwanzig"], answer: 0, explain: "٢ ist zwei – ithnān (اثنان)." },
            { q: "Was bedeutet خمسة (khamsa)?", options: ["Fünf", "Sechs", "Sieben", "Vier"], answer: 0, explain: "خمسة ist fünf. ستة ist sechs und سبعة ist sieben." }
          ]
        }
      ]
    },

    {
      id: "english",
      name: "Englisch",
      tagline: "Wortarten, Zeitformen der Verben und alltägliche Redewendungen.",
      color: "#e11d48",
      icon: "letter-a",
      lessons: [
        {
          id: "parts-of-speech",
          title: "Wortarten",
          summary: "Benenne die Aufgabe, die jedes Wort im Satz erfüllt.",
          minutes: 8,
          explain: {
            intro: "Jedes englische Wort gehört zu einer **Wortart** – der Aufgabe, die es im Satz erfüllt. Dasselbe Wort kann seine Aufgabe je nach Verwendung ändern.",
            sections: [
              { h: "Substantiv (noun)", p: "Eine Person, ein Ort, eine Sache oder eine Idee.", list: ["teacher, Cairo, bicycle, freedom, happiness"] },
              { h: "Verb", p: "Eine Handlung oder ein Zustand.", list: ["run, write, is, believe, seem"] },
              { h: "Adjektiv (adjective)", p: "Beschreibt ein Substantiv – welche Art, wie viele, welches.", list: ["tall, clever, blue, three, expensive"] },
              { h: "Adverb", p: "Beschreibt ein Verb, ein Adjektiv oder ein anderes Adverb. Viele enden auf -ly.", list: ["quickly, very, yesterday, almost, here"] },
              { h: "Pronomen (pronoun)", p: "Ersetzt ein Substantiv, damit du es nicht wiederholst.", list: ["I, you, he, she, it, we, they, this, someone"] },
              { h: "Präposition (preposition)", p: "Zeigt die Beziehung von Ort, Zeit oder Richtung.", list: ["in, on, under, at, between, during, with"] },
              { h: "Konjunktion (conjunction)", p: "Verbindet Wörter, Wortgruppen oder Teilsätze miteinander.", list: ["and, but, or, because, although, so"] }
            ],
            keyPoints: [
              "Frage dich: 'Welche Aufgabe erfüllt dieses Wort hier?' – das verrät dir die Wortart",
              "'Fast' kann ein Adjektiv sein (a fast car) oder ein Adverb (he ran fast)",
              "Adverbien enden oft auf -ly, aber nicht immer (very, soon, often)"
            ],
            example: {
              title: "Bestimme die Wortarten: 'The young boy ran quickly to school.'",
              steps: ["The — Artikel", "young — Adjektiv (beschreibt boy)", "boy — Substantiv", "ran — Verb", "quickly — Adverb (beschreibt ran)", "to — Präposition", "school — Substantiv"]
            }
          },
          questions: [
            { q: "Welches Wort ist das Substantiv in 'The dog barked loudly'?", options: ["dog", "barked", "loudly", "The"], answer: 0, explain: "Ein Hund ist eine Sache, also ist 'dog' das Substantiv. 'Barked' ist das Verb und 'loudly' das Adverb." },
            { q: "Welches Wort ist das Adjektiv in 'She wore a red hat'?", options: ["red", "wore", "She", "hat"], answer: 0, explain: "'Red' beschreibt das Substantiv 'hat', ist also ein Adjektiv." },
            { q: "Welches Wort ist das Verb in 'They played football yesterday'?", options: ["played", "They", "football", "yesterday"], answer: 0, explain: "'Played' ist die Handlung, also das Verb. 'Yesterday' ist ein Adverb der Zeit." },
            { q: "Welches Wort ist das Adverb in 'He ran quickly'?", options: ["quickly", "ran", "He", "keines davon"], answer: 0, explain: "'Quickly' beschreibt, wie er lief, ist also ein Adverb." },
            { q: "Welches Wort ist das Pronomen in 'Sara said she was tired'?", options: ["she", "Sara", "said", "tired"], answer: 0, explain: "'She' ersetzt das Substantiv 'Sara', ist also ein Pronomen." },
            { q: "Welches Wort ist die Präposition in 'The cat is under the table'?", options: ["under", "cat", "is", "table"], answer: 0, explain: "'Under' zeigt die Ortsbeziehung zwischen der Katze und dem Tisch." },
            { q: "Welches Wort ist die Konjunktion in 'I like tea but not coffee'?", options: ["but", "like", "tea", "not"], answer: 0, explain: "'But' verbindet die beiden Ideen miteinander, ist also eine Konjunktion." }
          ]
        },
        {
          id: "tenses",
          title: "Zeitformen der Verben",
          summary: "Vergangenheit, Gegenwart, Zukunft, Verlaufsform und Perfekt – klar gegenübergestellt.",
          minutes: 9,
          explain: {
            intro: "Die **Zeitform (tense)** sagt dir, *wann* eine Handlung stattfindet. Englisch zeigt die Zeitform, indem es das Verb ändert oder ein Hilfsverb wie be, have oder will ergänzt.",
            sections: [
              { h: "Simple Present (Gegenwart)", p: "Wird für Fakten, Gewohnheiten und Routinen verwendet. Bei he, she und it wird **-s** angehängt.", list: ["I walk to school.", "She walks to school every day.", "Water boils at 100 °C."] },
              { h: "Present Continuous (Verlaufsform)", p: "Wird für Handlungen verwendet, die gerade jetzt stattfinden: **am / is / are + Verb-ing**.", list: ["I am reading a book.", "They are playing outside."] },
              { h: "Simple Past (Vergangenheit)", p: "Wird für abgeschlossene Handlungen verwendet. Regelmäßige Verben erhalten **-ed**; unregelmäßige Verben ändern sich völlig.", list: ["I walked home.", "He went to Cairo last year.", "go → went, eat → ate, see → saw"] },
              { h: "Simple Future (Zukunft)", p: "Wird für Entscheidungen und Vorhersagen verwendet: **will + Grundform des Verbs**.", list: ["I will call you tomorrow.", "It will rain later."] },
              { h: "Present Perfect", p: "Verbindet die Vergangenheit mit der Gegenwart: **have / has + Partizip Perfekt**.", list: ["I have eaten already.", "She has finished her homework."] }
            ],
            keyPoints: [
              "Regelmäßige Vergangenheitsform = Verb + ed",
              "Unregelmäßige Vergangenheitsformen muss man lernen (go → went, eat → ate)",
              "Im Simple Present bei he, she und it ein -s anhängen",
              "Verlaufsform = be + Verb-ing; Perfekt = have + Partizip Perfekt"
            ],
            example: {
              title: "Dasselbe Verb in fünf Zeitformen: 'study'",
              steps: ["Simple Present: I study English", "Present Continuous: I am studying English", "Simple Past: I studied English yesterday", "Simple Future: I will study English tomorrow", "Present Perfect: I have studied English for three years"]
            }
          },
          questions: [
            { q: "Wie lautet das Simple Past von 'go'?", options: ["went", "goed", "gone", "going"], answer: 0, explain: "'Go' ist unregelmäßig, das Simple Past lautet also 'went'. 'Gone' ist das Partizip Perfekt." },
            { q: "Ergänze: She ___ to school every day.", options: ["goes", "go", "going", "gone"], answer: 0, explain: "Im Simple Present erhält he, she oder it ein -s, also 'she goes'." },
            { q: "Ergänze: They ___ football yesterday.", options: ["played", "play", "have played", "will play"], answer: 0, explain: "'Yesterday' ist ein abgeschlossener Zeitpunkt, also ist das Simple Past 'played' richtig." },
            { q: "Ergänze: I ___ you tomorrow.", options: ["will call", "called", "have called", "was calling"], answer: 0, explain: "'Tomorrow' verlangt eine Zukunftsform, und 'will call' ist das Simple Future." },
            { q: "Welcher Satz steht im Present Continuous?", options: ["I am reading a book", "I read a book", "I read a book yesterday", "I will read a book"], answer: 0, explain: "Das Present Continuous verwendet am/is/are + Verb-ing: 'I am reading'." },
            { q: "Welcher Satz verwendet das Present Perfect?", options: ["She has finished her homework", "She finished her homework", "She is finishing her homework", "She finishes her homework"], answer: 0, explain: "'Has finished' ist have/has + Partizip Perfekt, also das Present Perfect." },
            { q: "Wie lautet das Simple Past von 'eat'?", options: ["ate", "eated", "eaten", "eating"], answer: 0, explain: "'Eat' ist unregelmäßig: eat → ate → eaten. 'Eaten' ist das Partizip Perfekt." }
          ]
        },
        {
          id: "idioms",
          title: "Wortschatz & Redewendungen",
          summary: "Gängige Ausdrücke, deren Bedeutung nicht in den Wörtern steckt.",
          minutes: 7,
          explain: {
            intro: "**Redewendungen (idioms)** sind feste Wendungen, deren Bedeutung sich nicht aus den einzelnen Wörtern erschließt. Wenn du sie lernst, klingt dein Englisch natürlicher.",
            sections: [
              { h: "Alltägliche Redewendungen", p: "", list: ["break the ice — in einer peinlichen Situation ein Gespräch beginnen", "a piece of cake — sehr einfach", "hit the books — fleißig lernen", "under the weather — sich krank fühlen", "once in a blue moon — sehr selten", "cost an arm and a leg — sehr teuer sein"] },
              { h: "Im Satz", p: "", list: ["The exam was a piece of cake — I finished in ten minutes.", "He is a bit under the weather today, so he stayed home.", "We only see our cousins once in a blue moon."] },
              { h: "Wortschatz aufbauen", p: "Lerne ein neues Wort mit drei Dingen: seiner **Bedeutung**, einem **Beispielsatz** und mindestens einem **Synonym oder Antonym**. So gelernte Wörter bleiben viel länger im Gedächtnis." }
            ],
            keyPoints: [
              "Redewendungen lassen sich nicht Wort für Wort übersetzen",
              "Lerne jede Redewendung in einem vollständigen Beispielsatz",
              "Nutze den Kontext, um die Bedeutung eines unbekannten Wortes zu erraten"
            ],
            example: {
              title: "Aus dem Kontext erschließen",
              steps: ["Satz: 'That phone cost me an arm and a leg.'", "Die Wörter 'arm' und 'leg' ergeben wörtlich keinen Sinn", "Der Satz handelt vom Kauf von etwas", "Also muss die Wendung bedeuten, dass es sehr teuer war"]
            }
          },
          questions: [
            { q: "'The test was a piece of cake.' Der Test war …", options: ["sehr einfach", "sehr schwierig", "köstlich", "sehr lang"], answer: 0, explain: "'A piece of cake' bedeutet, dass etwas sehr einfach zu tun ist." },
            { q: "Wenn du 'under the weather' bist, bist du …", options: ["krank", "draußen im Regen", "sehr glücklich", "im Flugzeug"], answer: 0, explain: "'Under the weather' bedeutet, sich leicht krank oder unwohl zu fühlen." },
            { q: "'Break the ice' bedeutet, …", options: ["in einer peinlichen Situation ein Gespräch zu beginnen", "etwas versehentlich kaputtzumachen", "Schlittschuh zu laufen", "wütend auf jemanden zu werden"], answer: 0, explain: "'Break the ice' bedeutet, ein Gespräch in Gang zu bringen und die Leute locker zu machen." },
            { q: "'Hit the books' bedeutet, …", options: ["fleißig zu lernen", "Bücher wegzuwerfen", "zum Vergnügen zu lesen", "neue Bücher zu kaufen"], answer: 0, explain: "'Hit the books' bedeutet, ernsthaft mit dem Lernen zu beginnen." },
            { q: "'Once in a blue moon' bedeutet …", options: ["sehr selten", "jede Nacht", "immer", "nie"], answer: 0, explain: "Ein blue moon ist selten, also bedeutet die Wendung, dass etwas sehr selten passiert." },
            { q: "Welches Wort ist ein Synonym für 'happy'?", options: ["joyful", "angry", "tired", "quiet"], answer: 0, explain: "'Joyful' hat dieselbe Bedeutung wie 'happy'. Die anderen sind unverwandt oder das Gegenteil." },
            { q: "Welches Wort ist das Gegenteil von 'ancient'?", options: ["modern", "old", "historic", "antique"], answer: 0, explain: "'Ancient' bedeutet sehr alt, also ist 'modern' (neu, aktuell) das Gegenteil." }
          ]
        }
      ]
    },

    {
      id: "french",
      name: "Französisch",
      tagline: "Fang an, Französisch zu sprechen: Begrüßungen und Zahlen.",
      color: "#2563eb",
      icon: "tower",
      lessons: [
        {
          id: "greetings",
          title: "Begrüßungen & Vorstellungen",
          summary: "Sag auf Französisch Hallo, stell dich vor und verabschiede dich.",
          minutes: 8,
          explain: {
            intro: "Französische Begrüßungen ändern sich je nachdem, wie gut man jemanden kennt. **Bonjour** passt fast überall; **salut** ist für Freunde und Familie.",
            sections: [
              { h: "Hallo und auf Wiedersehen", p: "", list: ["Bonjour — guten Tag / guten Morgen (fast überall passend)", "Bonsoir — guten Abend", "Salut — hallo / tschüss (informell, unter Freunden)", "Au revoir — auf Wiedersehen", "À bientôt — bis bald"] },
              { h: "Sich vorstellen", p: "", list: ["Comment tu t'appelles ? — wie heißt du? (informell)", "Comment vous appelez-vous ? — wie heißen Sie? (formell)", "Je m'appelle… — ich heiße…", "Enchanté / Enchantée — freut mich"] },
              { h: "Wie geht es dir?", p: "", list: ["Comment ça va ? / Ça va ? — wie geht's?", "Ça va bien, merci — mir geht es gut, danke", "Comme ci, comme ça — so einigermaßen"] },
              { h: "Höflich sein", p: "", list: ["Merci — danke", "Merci beaucoup — vielen Dank", "S'il vous plaît — bitte (formell)", "De rien — gern geschehen", "Excusez-moi — entschuldigen Sie", "Pardon — Verzeihung / Entschuldigung"] }
            ],
            keyPoints: [
              "Bonjour passt fast in jeder Situation",
              "Salut ist nur für Freunde und Familie",
              "Je m'appelle… bedeutet ich heiße…",
              "Merci = danke, s'il vous plaît = bitte"
            ],
            example: {
              title: "Ein erstes Gespräch auf Französisch",
              steps: ["A: Bonjour ! Comment tu t'appelles ?", "B: Salut, je m'appelle Léa. Et toi ?", "A: Je m'appelle Sami. Enchanté !", "B: Enchantée ! Ça va ?", "A: Ça va bien, merci. Au revoir !"]
            }
          },
          questions: [
            { q: "Was bedeutet 'Bonjour'?", options: ["Hallo", "Auf Wiedersehen", "Danke", "Bitte"], answer: 0, explain: "Bonjour bedeutet hallo oder guten Morgen – es passt in fast jeder Situation." },
            { q: "Welches französische Wort bedeutet 'danke'?", options: ["Merci", "Pardon", "Salut", "De rien"], answer: 0, explain: "Merci heißt danke. De rien bedeutet gern geschehen." },
            { q: "Wie sagt man auf Französisch 'Ich heiße…'?", options: ["Je m'appelle…", "Comment tu t'appelles ?", "Ça va ?", "Au revoir"], answer: 0, explain: "Je m'appelle… bedeutet wörtlich 'ich nenne mich…'. Die Frage lautet Comment tu t'appelles ?" },
            { q: "Welche Begrüßung ist informell und wird unter Freunden verwendet?", options: ["Salut", "Bonsoir", "Bonjour", "Au revoir"], answer: 0, explain: "Salut ist informell und bedeutet sowohl hallo als auch tschüss – verwende es nur bei Menschen, die du gut kennst." },
            { q: "Was bedeutet 'Comment ça va ?'?", options: ["Wie geht es dir?", "Wie heißt du?", "Woher kommst du?", "Wie alt bist du?"], answer: 0, explain: "Comment ça va ? (oder einfach Ça va ?) fragt, wie es jemandem geht." },
            { q: "Welche Wendung bedeutet 'bitte'?", options: ["S'il vous plaît", "Merci", "De rien", "Excusez-moi"], answer: 0, explain: "S'il vous plaît bedeutet bitte. Unter Freunden kann man s'il te plaît sagen." },
            { q: "Was bedeutet 'Au revoir'?", options: ["Auf Wiedersehen", "Hallo", "Willkommen", "Guten Abend"], answer: 0, explain: "Au revoir bedeutet auf Wiedersehen. À bientôt bedeutet bis bald." }
          ]
        },
        {
          id: "numbers",
          title: "Zahlen 1 – 10",
          summary: "Zähle auf Französisch von eins bis zehn und lerne, dein Alter zu sagen.",
          minutes: 6,
          explain: {
            intro: "Französische Zahlen von **un** bis **dix**. Achte auf **un** und **une** – französische Substantive haben ein Geschlecht, und die Zahl muss dazu passen.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 un / une — ö(n)", "2 deux — dö", "3 trois — trwa", "4 quatre — katt(r)", "5 cinq — sänk"] },
              { h: "6 – 10", p: "", list: ["6 six — sis", "7 sept — sett", "8 huit — üit", "9 neuf — nöf", "10 dix — dis"] },
              { h: "Nützliche Wendungen", p: "", list: ["Combien ? — wie viele / wie viel?", "J'ai dix ans — ich bin zehn Jahre alt (wörtlich: ich habe zehn Jahre)", "Il y a trois livres — es gibt drei Bücher"] }
            ],
            keyPoints: [
              "un, deux, trois, quatre, cinq",
              "six, sept, huit, neuf, dix",
              "Das Alter verwendet das Verb avoir: J'ai dix ans",
              "Der letzte Buchstabe von cinq, huit und dix ist oft stumm"
            ],
            example: {
              title: "Laut zählen",
              steps: ["un, deux, trois…", "quatre, cinq, six…", "sept, huit, neuf, dix !"]
            }
          },
          questions: [
            { q: "Was bedeutet 'trois' auf Deutsch?", options: ["Drei", "Zwei", "Vier", "Zehn"], answer: 0, explain: "trois ist drei. deux ist zwei und quatre ist vier." },
            { q: "Wie sagt man 5 auf Französisch?", options: ["cinq", "six", "sept", "quatre"], answer: 0, explain: "5 ist cinq. six ist 6." },
            { q: "Was bedeutet 'dix'?", options: ["Zehn", "Acht", "Sechs", "Zwei"], answer: 0, explain: "dix ist zehn. huit ist acht und six ist sechs." },
            { q: "Welches ist das französische Wort für 8?", options: ["huit", "neuf", "sept", "six"], answer: 0, explain: "huit ist acht. neuf ist neun." },
            { q: "Was bedeutet 'un / une'?", options: ["Eins", "Neun", "Elf", "Null"], answer: 0, explain: "un (männlich) und une (weiblich) bedeuten beide eins." },
            { q: "Wie sagt man auf Französisch 'Ich bin zehn Jahre alt'?", options: ["J'ai dix ans", "Je suis dix ans", "J'ai dix", "J'ai ans dix"], answer: 0, explain: "Französisch verwendet avoir (haben) für das Alter: J'ai dix ans – wörtlich 'ich habe zehn Jahre'." }
          ]
        }
      ]
    },

    {
      id: "german",
      name: "Deutsch",
      tagline: "Fang an, Deutsch zu sprechen: Begrüßungen und Zahlen.",
      color: "#7c3aed",
      icon: "flag",
      lessons: [
        {
          id: "greetings",
          title: "Begrüßungen & Vorstellungen",
          summary: "Sag auf Deutsch Hallo, stell dich vor und verabschiede dich.",
          minutes: 8,
          explain: {
            intro: "Deutsch kennt eine formelle und eine informelle Art, **du** zu sagen: **du** für Freunde und Familie, **Sie** für alle anderen. Das richtig zu machen, ist wichtig.",
            sections: [
              { h: "Hallo und auf Wiedersehen", p: "", list: ["Hallo — hallo", "Guten Morgen — guten Morgen", "Guten Tag — guten Tag (wird den größten Teil des Tages verwendet)", "Guten Abend — guten Abend", "Gute Nacht — gute Nacht (vor dem Schlafen)", "Tschüss — tschüss (informell)", "Auf Wiedersehen — auf Wiedersehen (formell)"] },
              { h: "Sich vorstellen", p: "", list: ["Wie heißt du? — wie heißt du? (informell)", "Wie heißen Sie? — wie heißen Sie? (formell)", "Ich heiße… — ich heiße…", "Ich bin… — ich bin…", "Freut mich — freut mich"] },
              { h: "Wie geht es dir?", p: "", list: ["Wie geht es dir? — wie geht es dir? (informell)", "Wie geht es Ihnen? — wie geht es Ihnen? (formell)", "Mir geht es gut — mir geht es gut", "Es geht — es geht so"] },
              { h: "Höfliche Wörter", p: "", list: ["Danke — danke", "Vielen Dank — vielen Dank", "Bitte — bitte / gern geschehen", "Entschuldigung — Entschuldigung / Verzeihung", "Ja / Nein — ja / nein"] }
            ],
            keyPoints: [
              "du = informelles Du, Sie = formelles Sie",
              "Ich heiße… bedeutet ich heiße…",
              "Bitte bedeutet sowohl bitte als auch gern geschehen",
              "Alle deutschen Substantive werden großgeschrieben"
            ],
            example: {
              title: "Ein erstes Gespräch auf Deutsch",
              steps: ["A: Hallo! Wie heißt du?", "B: Ich heiße Anna. Und du?", "A: Ich bin Jonas. Freut mich!", "B: Freut mich. Wie geht es dir?", "A: Mir geht es gut, danke. Tschüss!"]
            }
          },
          questions: [
            { q: "Was bedeutet 'Guten Morgen'?", options: ["Guten Morgen", "Gute Nacht", "Auf Wiedersehen", "Danke"], answer: 0, explain: "Guten Morgen heißt guten Morgen. Gute Nacht ist gute Nacht." },
            { q: "Welches Wort bedeutet 'danke'?", options: ["Danke", "Bitte", "Tschüss", "Hallo"], answer: 0, explain: "Danke heißt danke. Bitte bedeutet bitte oder gern geschehen." },
            { q: "Wie sagt man 'Ich heiße…'?", options: ["Ich heiße…", "Wie heißt du?", "Mir geht es gut", "Freut mich"], answer: 0, explain: "Ich heiße… bedeutet ich heiße…; Wie heißt du? ist die Frage." },
            { q: "Welche Form von 'du' verwendest du bei deiner Lehrerin oder deinem Lehrer?", options: ["Sie", "du", "dich", "dir"], answer: 0, explain: "Verwende Sie bei Menschen, die du nicht gut kennst, und du bei Freunden und Familie." },
            { q: "Was bedeutet 'Tschüss'?", options: ["Auf Wiedersehen", "Hallo", "Bitte", "Entschuldigung"], answer: 0, explain: "Tschüss ist die informelle Art, auf Wiedersehen zu sagen. Auf Wiedersehen ist die formelle." },
            { q: "Was bedeutet 'Bitte'?", options: ["Bitte / gern geschehen", "Danke", "Guten Abend", "Ja"], answer: 0, explain: "Bitte hat eine Doppelfunktion: bitte, wenn du etwas erbittest, und gern geschehen, wenn du antwortest." }
          ]
        },
        {
          id: "numbers",
          title: "Zahlen 1 – 10",
          summary: "Zähle auf Deutsch von eins bis zehn und lerne, dein Alter zu sagen.",
          minutes: 6,
          explain: {
            intro: "Deutsche Zahlen von **eins** bis **zehn**. Das Alter sagt man im Deutschen mit dem Verb **sein**: Ich bin zehn Jahre alt.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 eins", "2 zwei", "3 drei", "4 vier", "5 fünf"] },
              { h: "6 – 10", p: "", list: ["6 sechs", "7 sieben", "8 acht", "9 neun", "10 zehn"] },
              { h: "Ein kleiner Tipp", p: "Am Telefon sagt man **zwei** oft als **zwo**, damit es nicht mit **drei** verwechselt werden kann. Beide bedeuten zwei." },
              { h: "Nützliche Wendungen", p: "", list: ["Wie viele? — wie viele?", "Ich bin zehn Jahre alt — ich bin zehn Jahre alt", "Ich habe drei Bücher — ich habe drei Bücher"] }
            ],
            keyPoints: [
              "eins, zwei, drei, vier, fünf",
              "sechs, sieben, acht, neun, zehn",
              "Das Alter verwendet das Verb sein: Ich bin zehn Jahre alt",
              "Ab 20 sagt man im Deutschen die Einer vor den Zehnern: einundzwanzig = eins und zwanzig"
            ],
            example: {
              title: "Laut zählen",
              steps: ["eins, zwei, drei…", "vier, fünf, sechs…", "sieben, acht, neun, zehn !"]
            }
          },
          questions: [
            { q: "Was bedeutet 'drei' auf Englisch?", options: ["Three", "Two", "Four", "Ten"], answer: 0, explain: "drei ist three. zwei ist two und vier ist four." },
            { q: "Wie sagt man 5 auf Deutsch?", options: ["fünf", "vier", "sechs", "sieben"], answer: 0, explain: "5 ist fünf. sechs ist 6." },
            { q: "Was bedeutet 'zehn'?", options: ["Zehn", "Acht", "Zwei", "Sechs"], answer: 0, explain: "zehn ist zehn. acht ist acht." },
            { q: "Welches ist das deutsche Wort für 8?", options: ["acht", "neun", "sieben", "sechs"], answer: 0, explain: "acht ist acht. neun ist neun." },
            { q: "Was bedeutet 'eins'?", options: ["Eins", "Neun", "Elf", "Null"], answer: 0, explain: "eins ist eins." },
            { q: "Wie sagt man auf Deutsch 'Ich bin zehn Jahre alt'?", options: ["Ich bin zehn Jahre alt", "Ich heiße zehn", "Mir geht es zehn", "Ich habe zehn"], answer: 0, explain: "Deutsch verwendet das Verb sein für das Alter: Ich bin zehn Jahre alt." }
          ]
        }
      ]
    },

    {
      id: "spanish",
      name: "Spanisch",
      tagline: "Fang an, Spanisch zu sprechen: Begrüßungen und Zahlen.",
      color: "#f59e0b",
      icon: "chat",
      lessons: [
        {
          id: "greetings",
          title: "Begrüßungen & Vorstellungen",
          summary: "Sag auf Spanisch Hallo, stell dich vor und verabschiede dich.",
          minutes: 8,
          explain: {
            intro: "Spanische Begrüßungen sind herzlich und kurz. **¡Hola!** passt bei jedem, überall, zu jeder Tageszeit.",
            sections: [
              { h: "Hallo und auf Wiedersehen", p: "", list: ["¡Hola! — hallo", "Buenos días — guten Morgen", "Buenas tardes — guten Nachmittag", "Buenas noches — guten Abend / gute Nacht", "Adiós — auf Wiedersehen", "Hasta luego — bis später", "Hasta mañana — bis morgen"] },
              { h: "Sich vorstellen", p: "", list: ["¿Cómo te llamas? — wie heißt du? (informell)", "¿Cómo se llama? — wie heißen Sie? (formell)", "Me llamo… — ich heiße…", "Mucho gusto — freut mich"] },
              { h: "Wie geht es dir?", p: "", list: ["¿Cómo estás? — wie geht es dir? (informell)", "¿Cómo está usted? — wie geht es Ihnen? (formell)", "Estoy bien, gracias — mir geht es gut, danke", "Más o menos — so einigermaßen"] },
              { h: "Höflich sein", p: "", list: ["Gracias — danke", "Muchas gracias — vielen Dank", "Por favor — bitte", "De nada — gern geschehen", "Perdón — Verzeihung", "Lo siento — es tut mir leid"] }
            ],
            keyPoints: [
              "¡Hola! passt in jeder Situation",
              "¿Cómo te llamas? → Me llamo…",
              "gracias = danke, por favor = bitte",
              "Die umgekehrten ¿ und ¡ eröffnen eine Frage oder einen Ausruf"
            ],
            example: {
              title: "Ein erstes Gespräch auf Spanisch",
              steps: ["A: ¡Hola! ¿Cómo te llamas?", "B: Me llamo Lucía. ¿Y tú?", "A: Me llamo Diego. Mucho gusto.", "B: ¿Cómo estás?", "A: Estoy bien, gracias. ¡Hasta luego!"]
            }
          },
          questions: [
            { q: "Was bedeutet '¡Hola!'?", options: ["Hallo", "Auf Wiedersehen", "Danke", "Bitte"], answer: 0, explain: "¡Hola! bedeutet hallo und kann zu jeder Tageszeit verwendet werden." },
            { q: "Welches spanische Wort bedeutet 'danke'?", options: ["Gracias", "Por favor", "De nada", "Perdón"], answer: 0, explain: "Gracias heißt danke. De nada bedeutet gern geschehen." },
            { q: "Wie sagt man auf Spanisch 'Ich heiße…'?", options: ["Me llamo…", "¿Cómo te llamas?", "Estoy bien", "Mucho gusto"], answer: 0, explain: "Me llamo… bedeutet wörtlich 'ich nenne mich…'. Die Frage lautet ¿Cómo te llamas?" },
            { q: "Was bedeutet 'Buenos días'?", options: ["Guten Morgen", "Gute Nacht", "Bis später", "Gern geschehen"], answer: 0, explain: "Buenos días heißt guten Morgen; buenas noches heißt gute Nacht." },
            { q: "Was bedeutet '¿Cómo estás?'?", options: ["Wie geht es dir?", "Wie heißt du?", "Wo bist du?", "Wie alt bist du?"], answer: 0, explain: "¿Cómo estás? fragt, wie es jemandem geht. Die formelle Variante ist ¿Cómo está usted?" },
            { q: "Welches Zeichen eröffnet im Spanischen eine Frage?", options: ["¿", "¡", "?", "!"], answer: 0, explain: "Spanisch verwendet ¿ am Anfang einer Frage und ¡ am Anfang eines Ausrufs, zusätzlich zu den normalen Schlusszeichen." },
            { q: "Was bedeutet 'Hasta luego'?", options: ["Bis später", "Guten Morgen", "Freut mich", "Bitte"], answer: 0, explain: "Hasta luego bedeutet bis später. Hasta mañana bedeutet bis morgen." }
          ]
        },
        {
          id: "numbers",
          title: "Zahlen 1 – 10",
          summary: "Zähle auf Spanisch von eins bis zehn.",
          minutes: 6,
          explain: {
            intro: "Spanische Zahlen von **uno** bis **diez**. Sie werden genau so ausgesprochen, wie sie geschrieben werden, was sie schnell zu lernen macht.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 uno — uno", "2 dos — dos", "3 tres — tres", "4 cuatro — kwa-tro", "5 cinco — sin-ko"] },
              { h: "6 – 10", p: "", list: ["6 seis — seis", "7 siete — sje-te", "8 ocho — o-tscho", "9 nueve — nue-be", "10 diez — djes"] },
              { h: "Eine kleine Regel", p: "**uno** verliert das -o vor einem männlichen Substantiv: un libro (ein Buch). Vor einem weiblichen Substantiv wird es zu **una**: una casa (ein Haus)." },
              { h: "Nützliche Wendungen", p: "", list: ["¿Cuántos? — wie viele?", "Tengo diez años — ich bin zehn Jahre alt (wörtlich: ich habe zehn Jahre)", "Hay tres libros — es gibt drei Bücher"] }
            ],
            keyPoints: [
              "uno, dos, tres, cuatro, cinco",
              "seis, siete, ocho, nueve, diez",
              "uno → un vor einem männlichen Substantiv, una vor einem weiblichen",
              "Das Alter verwendet tener: Tengo diez años"
            ],
            example: {
              title: "Laut zählen",
              steps: ["uno, dos, tres…", "cuatro, cinco, seis…", "siete, ocho, nueve, diez !"]
            }
          },
          questions: [
            { q: "Was bedeutet 'tres' auf Englisch?", options: ["Three", "Two", "Four", "Ten"], answer: 0, explain: "tres ist three. dos ist two und cuatro ist four." },
            { q: "Wie sagt man 5 auf Spanisch?", options: ["cinco", "cuatro", "seis", "siete"], answer: 0, explain: "5 ist cinco. seis ist 6." },
            { q: "Was bedeutet 'diez'?", options: ["Zehn", "Acht", "Zwei", "Sechs"], answer: 0, explain: "diez ist zehn. ocho ist acht." },
            { q: "Welches ist das spanische Wort für 8?", options: ["ocho", "nueve", "siete", "seis"], answer: 0, explain: "ocho ist acht. nueve ist neun." },
            { q: "Was bedeutet 'uno'?", options: ["Eins", "Neun", "Elf", "Null"], answer: 0, explain: "uno ist eins. Vor einem männlichen Substantiv wird es zu un verkürzt." },
            { q: "Was bedeutet '¿Cuántos?'?", options: ["Wie viele?", "Wie geht es dir?", "Wo?", "Warum?"], answer: 0, explain: "¿Cuántos? fragt nach der Anzahl. ¿Cuánto? fragt nach dem Betrag." }
          ]
        }
      ]
    }
  ]
};
