/* LearnHub — English pack.
   Contains the interface strings and every lesson, written in English. */
window.PACKS = window.PACKS || {};
window.PACKS.en = {
  code: "en",
  name: "English",
  dir: "ltr",

  ui: {
    appName: "LearnHub",
    taglineShort: "Learn anything",
    welcomeTitle: "Welcome to LearnHub",
    welcomeSub: "Learn maths, science, languages and more. Every lesson explains the idea first, then you practise with questions.",
    pickLanguage: "Choose your language",
    yourName: "What should we call you?",
    namePlaceholder: "Type your name",
    pickAnimal: "Pick your animal",
    startLearning: "Start learning",
    needName: "Please type a name first.",
    soundPreview: "Tap an animal, then tap Start.",
    yourProfile: "Your profile",
    yourNameLabel: "Name",
    yourAnimal: "Your animal",
    saveProfile: "Save",
    profileSaved: "Saved!",
    yourProgress: "Your progress",
    lessonsDone: "Lessons done",
    starsEarned: "Stars earned",
    avgScore: "Average score",
    soundOn: "Sound effects: on",
    soundOff: "Sound effects: off",
    heroTitle: "Learn anything, one small step at a time",
    heroLead: "Every lesson starts with a short, clear explanation — then you practise with questions. Get one right and you hear a ting; get one wrong and the sad trombone plays.",
    welcomeBack: "Welcome back, {name}!",
    continueLearning: "Continue learning",
    startLesson: "Start lesson",
    allCaughtUp: "You have finished every lesson",
    allCaughtUpBody: "Revisit any subject below to beat your best score.",
    chooseSubject: "Choose a subject",
    subjectsCount: "{n} subjects",
    lessonsCount: "{n} lessons",
    ofComplete: "{done} of {total} complete",
    progressLabel: "Progress",
    allSubjects: "All subjects",
    notStarted: "Not started",
    minRead: "{n} min read",
    questionsCount: "{n} questions",
    stepExplain: "Explanation",
    stepPractice: "Practice",
    readyButton: "I am ready — start the quiz",
    readyHint: "A ting means correct. A womp womp womp means try again.",
    rememberThese: "Remember these",
    questionOf: "Question {i} of {n}",
    scoreLabel: "Score {n}",
    streakLabel: "Streak {n} in a row",
    correctFeedback: "Correct!",
    wrongFeedback: "Not quite",
    inARow: "{n} in a row!",
    quizTip: "Tip: press 1–4 to choose, Enter to continue.",
    nextQuestion: "Next question",
    seeResults: "See my results",
    msgPerfect: "A perfect score. You have completely mastered this lesson.",
    msgExcellent: "Excellent work — nearly perfect.",
    msgGood: "Well done. You have a solid understanding.",
    msgOk: "A good start. Read the explanation once more, then try again.",
    msgKeepGoing: "Keep going. Go back through the explanation and retry — you will get there.",
    pctCorrect: "{p}% correct",
    bestStreakLabel: "best streak {n} in a row",
    prevBest: "previous best {b}/{t}",
    reviewTitle: "Review your {n} mistakes",
    reviewTitleOne: "Review your mistake",
    correctIs: "Correct:",
    youAnswered: "You answered:",
    noMistakes: "Every question correct — no mistakes to review.",
    tryAgain: "Try again",
    backTo: "Back to {subject}",
    nextLessonLabel: "Next lesson: {title}",
    soundToggle: "Sound effects",
    backHome: "Home",
    langLabel: "Language",
    closeLabel: "Close",
    editProfile: "Edit profile",
    switchHint: "Everything — the menus and every lesson — switches to the language you choose."
  },

  avatars: {
    cat: "Cat",
    dog: "Dog",
    fox: "Fox",
    panda: "Panda",
    owl: "Owl",
    lion: "Lion",
    frog: "Frog",
    penguin: "Penguin"
  },

  subjects: [
    {
      id: "math",
      name: "Mathematics",
      tagline: "Fractions, algebra and geometry, explained step by step.",
      color: "#4f46e5",
      icon: "calculator",
      lessons: [
        {
          id: "fractions",
          title: "Fractions",
          summary: "Read, compare, simplify and add fractions with confidence.",
          minutes: 8,
          explain: {
            intro: "A fraction shows **part of a whole**. Every fraction has two parts: the **numerator** (top number) and the **denominator** (bottom number).",
            sections: [
              { h: "Numerator and denominator", p: "The denominator tells you how many equal pieces the whole is cut into. The numerator tells you how many of those pieces you take. In 3/4 the whole is cut into 4 pieces and you take 3 of them." },
              { h: "Equivalent fractions", p: "Multiplying or dividing the top and bottom by the same number gives an **equivalent fraction** with exactly the same value.", list: ["1/2 = 2/4 = 4/8 = 50/100", "6/8 = 3/4  (divide both parts by 2)", "10/15 = 2/3  (divide both parts by 5)"] },
              { h: "Adding fractions", p: "If the denominators already match, add the numerators and keep the denominator. If they differ, first rewrite both fractions with a **common denominator**.", list: ["1/4 + 2/4 = 3/4", "1/2 + 1/3 = 3/6 + 2/6 = 5/6"] },
              { h: "Comparing fractions", p: "Rewrite both fractions with a common denominator, then compare the numerators. 2/3 and 3/5 become 10/15 and 9/15, so **2/3 is larger**." }
            ],
            keyPoints: [
              "Denominator = size of the pieces, numerator = how many pieces you have",
              "Simplify by dividing both parts by their greatest common factor",
              "Never add the denominators — only the numerators, after they match"
            ],
            example: {
              title: "Worked example: 2/3 + 1/4",
              steps: ["Find a common denominator: 12", "Rewrite: 2/3 = 8/12 and 1/4 = 3/12", "Add the numerators: 8 + 3 = 11", "Answer: 11/12"]
            }
          },
          questions: [
            { q: "In the fraction 3/4, which number is the denominator?", options: ["4", "3", "7", "12"], answer: 0, explain: "The denominator is the bottom number, 4. It tells you the whole is split into 4 equal parts." },
            { q: "Which fraction is equivalent to 1/2?", options: ["2/4", "2/3", "1/3", "3/5"], answer: 0, explain: "Multiply the top and bottom of 1/2 by 2: 1/2 = 2/4. Same value, different numbers." },
            { q: "What is 1/4 + 2/4?", options: ["3/4", "3/8", "2/8", "1/2"], answer: 0, explain: "The denominators match, so add the numerators (1 + 2 = 3) and keep 4. The answer is 3/4, not 3/8." },
            { q: "What is 1/2 + 1/3?", options: ["5/6", "2/5", "1/5", "2/6"], answer: 0, explain: "A common denominator is 6: 1/2 = 3/6 and 1/3 = 2/6. Then 3/6 + 2/6 = 5/6." },
            { q: "Simplify 6/8.", options: ["3/4", "2/3", "1/2", "6/8"], answer: 0, explain: "Divide both parts by their greatest common factor, 2: 6 ÷ 2 = 3 and 8 ÷ 2 = 4, giving 3/4." },
            { q: "Which fraction is larger: 2/3 or 3/5?", options: ["2/3", "3/5", "They are equal", "It cannot be compared"], answer: 0, explain: "With a common denominator of 15: 2/3 = 10/15 and 3/5 = 9/15. So 2/3 is larger." },
            { q: "What is 3/5 of 20?", options: ["12", "15", "8", "5"], answer: 0, explain: "Divide by the denominator (20 ÷ 5 = 4), then multiply by the numerator (4 × 3 = 12)." }
          ]
        },
        {
          id: "equations",
          title: "Solving Linear Equations",
          summary: "Use inverse operations to find the value of x — and check your answer.",
          minutes: 9,
          explain: {
            intro: "An equation is a **balance**. The two sides are equal, and your job is to find the value of the unknown (usually x) that keeps them equal.",
            sections: [
              { h: "Keep the balance", p: "Whatever you do to one side you must do to the other side. If you subtract 3 on the left, subtract 3 on the right as well." },
              { h: "Inverse operations", p: "To get x alone, undo what is being done to it by using the opposite operation.", list: ["+ undoes −  and  − undoes +", "× undoes ÷  and  ÷ undoes ×"] },
              { h: "Order matters", p: "Undo **addition and subtraction first**, then multiplication and division. This is the reverse of the order of operations (BIDMAS)." },
              { h: "Always check", p: "Substitute your answer back into the original equation. If both sides come out equal, your answer is correct." }
            ],
            keyPoints: [
              "Do the same thing to both sides of the equals sign",
              "Undo + and − before × and ÷",
              "Always substitute back into the original equation to check"
            ],
            example: {
              title: "Worked example: 2x + 3 = 11",
              steps: ["Subtract 3 from both sides: 2x = 8", "Divide both sides by 2: x = 4", "Check: 2(4) + 3 = 11 ✓"]
            }
          },
          questions: [
            { q: "Solve x + 5 = 12", options: ["7", "17", "−7", "5"], answer: 0, explain: "Subtract 5 from both sides: x = 12 − 5 = 7." },
            { q: "Solve 3x = 18", options: ["6", "15", "21", "3"], answer: 0, explain: "Divide both sides by 3: x = 18 ÷ 3 = 6." },
            { q: "Solve 2x − 4 = 10", options: ["7", "3", "14", "6"], answer: 0, explain: "Add 4 to both sides: 2x = 14. Then divide by 2: x = 7." },
            { q: "Solve x / 4 = 3", options: ["12", "7", "0.75", "4"], answer: 0, explain: "Multiply both sides by 4: x = 3 × 4 = 12." },
            { q: "Solve 5x + 3 = 2x + 12", options: ["3", "5", "1", "9"], answer: 0, explain: "Subtract 2x from both sides: 3x + 3 = 12. Subtract 3: 3x = 9. Divide by 3: x = 3." },
            { q: "Which operation undoes multiplication?", options: ["Division", "Addition", "Subtraction", "Squaring"], answer: 0, explain: "Division is the inverse of multiplication, so dividing undoes multiplying." },
            { q: "If 4x = 2x + 10, what is x?", options: ["5", "10", "2", "4"], answer: 0, explain: "Subtract 2x from both sides: 2x = 10, so x = 5." }
          ]
        },
        {
          id: "area-perimeter",
          title: "Area and Perimeter",
          summary: "Measure the distance around shapes and the space inside them.",
          minutes: 7,
          explain: {
            intro: "**Perimeter** is the distance around a shape, measured in ordinary units (cm, m). **Area** is the amount of space inside, measured in square units (cm², m²).",
            sections: [
              { h: "Rectangle", p: "Area = length × width.  Perimeter = 2 × (length + width)." },
              { h: "Square", p: "Area = side².  Perimeter = 4 × side, because all four sides are equal." },
              { h: "Triangle", p: "Area = ½ × base × height. The height must be measured at right angles to the base." },
              { h: "Circle", p: "Circumference (the perimeter) = 2πr.  Area = πr², where r is the radius — half the diameter." }
            ],
            keyPoints: [
              "Perimeter is a length (cm); area is in square units (cm²)",
              "Circle formulas use the radius, not the diameter",
              "For a triangle, always use the perpendicular height"
            ],
            example: {
              title: "A rectangle is 8 cm long and 3 cm wide",
              steps: ["Area = 8 × 3 = 24 cm²", "Perimeter = 2 × (8 + 3) = 22 cm"]
            }
          },
          questions: [
            { q: "What is the area of a rectangle measuring 5 cm by 3 cm?", options: ["15 cm²", "8 cm²", "16 cm²", "10 cm²"], answer: 0, explain: "Area = length × width = 5 × 3 = 15 cm²." },
            { q: "What is the perimeter of a square with sides of 6 cm?", options: ["24 cm", "36 cm", "12 cm", "30 cm"], answer: 0, explain: "Perimeter = 4 × side = 4 × 6 = 24 cm." },
            { q: "A triangle has a base of 10 cm and a height of 6 cm. What is its area?", options: ["30 cm²", "60 cm²", "16 cm²", "20 cm²"], answer: 0, explain: "Area = ½ × base × height = ½ × 10 × 6 = 30 cm²." },
            { q: "Which formula gives the circumference of a circle?", options: ["2πr", "πr²", "πr", "r²"], answer: 0, explain: "Circumference = 2πr. The formula πr² gives the area instead." },
            { q: "What is the area of a circle with radius 3 cm, in terms of π?", options: ["9π cm²", "6π cm²", "3π cm²", "36π cm²"], answer: 0, explain: "Area = πr² = π × 3² = 9π cm²." },
            { q: "What is the perimeter of a rectangle measuring 7 cm by 4 cm?", options: ["22 cm", "28 cm", "11 cm", "24 cm"], answer: 0, explain: "Perimeter = 2 × (7 + 4) = 2 × 11 = 22 cm. (28 cm² would be the area.)" }
          ]
        }
      ]
    },

    {
      id: "science",
      name: "Science",
      tagline: "The water cycle, photosynthesis and the solar system.",
      color: "#0d9488",
      icon: "flask",
      lessons: [
        {
          id: "water-cycle",
          title: "The Water Cycle",
          summary: "How water travels between the oceans, the sky and the land.",
          minutes: 7,
          explain: {
            intro: "Water on Earth is constantly moving between the ground, the air and the clouds in a loop called the **water cycle**. The same water has been cycling for billions of years.",
            sections: [
              { h: "1. Evaporation", p: "The Sun heats liquid water in oceans, lakes and rivers. It turns into an invisible gas called **water vapour** and rises into the air." },
              { h: "2. Condensation", p: "High in the atmosphere the air is cold. Water vapour cools and turns back into tiny droplets, which group together to form **clouds**." },
              { h: "3. Precipitation", p: "When the droplets become heavy enough they fall as **rain, snow, sleet or hail**." },
              { h: "4. Collection", p: "The fallen water gathers in rivers, lakes and oceans, or soaks into the ground, and the cycle starts again." },
              { h: "Transpiration", p: "Plants also release water vapour from their leaves. This is called **transpiration** and it adds more water to the air." }
            ],
            keyPoints: [
              "The Sun is the energy source that drives the whole cycle",
              "Evaporation = liquid to gas; condensation = gas to liquid",
              "Precipitation is any water falling from clouds",
              "Order: evaporation → condensation → precipitation → collection"
            ],
            example: {
              title: "Why does a cold glass sweat?",
              steps: ["Warm air around the glass holds water vapour", "The cold surface cools that vapour down", "The vapour condenses into liquid droplets on the glass", "That is condensation — the same process that forms clouds"]
            }
          },
          questions: [
            { q: "Which process turns liquid water into water vapour?", options: ["Evaporation", "Condensation", "Precipitation", "Collection"], answer: 0, explain: "Evaporation changes liquid water into the gas water vapour when it is heated." },
            { q: "Clouds form when water vapour…", options: ["condenses into tiny droplets", "evaporates into the air", "freezes in the ocean", "soaks into the soil"], answer: 0, explain: "Cooling vapour condenses on dust particles to form the tiny droplets that make up clouds." },
            { q: "Rain, snow and hail are all examples of…", options: ["precipitation", "condensation", "evaporation", "transpiration"], answer: 0, explain: "Precipitation is any water that falls from clouds to the ground." },
            { q: "What is the main energy source that drives the water cycle?", options: ["The Sun", "The Moon", "Wind", "Volcanoes"], answer: 0, explain: "Solar energy heats water and causes the evaporation that powers the whole cycle." },
            { q: "Water vapour released by plant leaves is called…", options: ["transpiration", "evaporation", "precipitation", "infiltration"], answer: 0, explain: "Transpiration is the release of water vapour from plants, mainly through their leaves." },
            { q: "Which order of the water cycle is correct?", options: ["Evaporation → Condensation → Precipitation → Collection", "Condensation → Evaporation → Collection → Precipitation", "Precipitation → Collection → Condensation → Evaporation", "Collection → Precipitation → Evaporation → Condensation"], answer: 0, explain: "Water evaporates, condenses into clouds, falls as precipitation, and is collected again." }
          ]
        },
        {
          id: "photosynthesis",
          title: "Photosynthesis",
          summary: "How green plants turn sunlight into food.",
          minutes: 8,
          explain: {
            intro: "**Photosynthesis** is the process green plants use to make their own food from sunlight. It is the reason we have oxygen to breathe.",
            sections: [
              { h: "The ingredients", p: "Plants take in **carbon dioxide** from the air through tiny holes in their leaves called stomata, and **water** from the soil through their roots." },
              { h: "The energy", p: "**Chlorophyll** is the green pigment inside chloroplasts. It captures light energy and powers the reaction." },
              { h: "The products", p: "The plant makes **glucose**, a sugar it uses for energy and growth, and releases **oxygen** into the air as a by-product." },
              { h: "The word equation", p: "carbon dioxide + water + light energy → glucose + oxygen. In symbols: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂." }
            ],
            keyPoints: [
              "Needs: carbon dioxide, water, sunlight and chlorophyll",
              "Makes: glucose and oxygen",
              "Happens in the chloroplasts, mostly in the leaves",
              "Plants and algae do it — animals cannot"
            ],
            example: {
              title: "Testing for photosynthesis",
              steps: ["Cover part of a leaf so no light reaches it", "Leave the plant in sunlight for a day", "Test the leaf with iodine — it turns blue-black where starch is present", "Only the uncovered part turns dark, proving light is needed"]
            }
          },
          questions: [
            { q: "Which gas do plants take in for photosynthesis?", options: ["Carbon dioxide", "Oxygen", "Nitrogen", "Hydrogen"], answer: 0, explain: "Plants absorb carbon dioxide through the stomata in their leaves." },
            { q: "Which gas is released as a by-product of photosynthesis?", options: ["Oxygen", "Carbon dioxide", "Methane", "Helium"], answer: 0, explain: "Oxygen is released as a waste product, which is lucky for us." },
            { q: "The green pigment that captures light energy is…", options: ["chlorophyll", "carotene", "melanin", "haemoglobin"], answer: 0, explain: "Chlorophyll absorbs red and blue light and reflects green, which is why leaves look green." },
            { q: "In which part of a plant cell does photosynthesis take place?", options: ["Chloroplast", "Nucleus", "Cell wall", "Vacuole"], answer: 0, explain: "Chloroplasts contain the chlorophyll needed to capture light energy." },
            { q: "Which sugar is produced directly by photosynthesis?", options: ["Glucose", "Lactose", "Sucralose", "Maltose"], answer: 0, explain: "Glucose is the sugar made during photosynthesis; it is stored as starch." },
            { q: "Photosynthesis mainly happens in which part of the plant?", options: ["Leaves", "Roots", "Flowers", "Seeds"], answer: 0, explain: "Leaves have the largest surface area and the most chloroplasts, so most photosynthesis happens there." }
          ]
        },
        {
          id: "solar-system",
          title: "The Solar System",
          summary: "Eight planets and the objects that orbit our Sun.",
          minutes: 6,
          explain: {
            intro: "Our solar system has **8 planets** orbiting the Sun, held in orbit by gravity. The Sun contains more than 99% of all the mass in the system.",
            sections: [
              { h: "The inner planets", p: "Mercury, Venus, Earth and Mars are **rocky (terrestrial) planets** and lie closest to the Sun." },
              { h: "The outer planets", p: "Jupiter, Saturn, Uranus and Neptune are enormous **gas and ice giants**, made mostly of hydrogen, helium and ices." },
              { h: "Other objects", p: "The asteroid belt between Mars and Jupiter, hundreds of moons, comets, and dwarf planets such as Pluto all orbit the Sun too." },
              { h: "Order from the Sun", p: "Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune. A memory trick: **My Very Educated Mother Just Served Us Noodles**." }
            ],
            keyPoints: [
              "Mercury is closest to the Sun; Neptune is farthest",
              "Jupiter is the largest planet, Mercury the smallest",
              "Pluto is a dwarf planet, not a planet",
              "Earth has one natural satellite: the Moon"
            ],
            example: {
              title: "Comparing sizes",
              steps: ["Jupiter's diameter is about 143,000 km", "Earth's diameter is about 12,700 km", "Jupiter is roughly 11 times wider than Earth"]
            }
          },
          questions: [
            { q: "Which planet is the largest in our solar system?", options: ["Jupiter", "Saturn", "Earth", "Neptune"], answer: 0, explain: "Jupiter is the largest planet — about 11 times wider than Earth." },
            { q: "Which planet is closest to the Sun?", options: ["Mercury", "Venus", "Earth", "Mars"], answer: 0, explain: "Mercury is the innermost planet, orbiting closest to the Sun." },
            { q: "Which of these is no longer classified as a planet?", options: ["Pluto", "Neptune", "Uranus", "Mars"], answer: 0, explain: "In 2006 Pluto was reclassified as a dwarf planet because it has not cleared its orbit." },
            { q: "Which planet is known as the Red Planet?", options: ["Mars", "Venus", "Jupiter", "Mercury"], answer: 0, explain: "Mars looks red because its surface is rich in iron oxide (rust)." },
            { q: "Which planet is famous for its bright ring system?", options: ["Saturn", "Mars", "Mercury", "Venus"], answer: 0, explain: "Saturn's rings are made of ice and rock particles. Jupiter, Uranus and Neptune have faint rings too." },
            { q: "How many planets are in our solar system?", options: ["8", "9", "7", "10"], answer: 0, explain: "There are 8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune." },
            { q: "What is Earth's natural satellite?", options: ["The Moon", "Phobos", "Titan", "Europa"], answer: 0, explain: "The Moon orbits Earth. Phobos orbits Mars; Titan and Europa orbit Saturn and Jupiter." }
          ]
        }
      ]
    },

    {
      id: "geography",
      name: "Geography",
      tagline: "Continents, oceans and the capitals of the world.",
      color: "#ea580c",
      icon: "globe",
      lessons: [
        {
          id: "continents",
          title: "Continents & Oceans",
          summary: "The seven land masses and five oceans of planet Earth.",
          minutes: 6,
          explain: {
            intro: "Earth has **7 continents** — huge continuous areas of land — and **5 oceans** that cover about 71% of the surface.",
            sections: [
              { h: "The seven continents", p: "From largest to smallest by area: **Asia, Africa, North America, South America, Antarctica, Europe, Australia (Oceania)**." },
              { h: "The five oceans", p: "From largest to smallest: **Pacific, Atlantic, Indian, Southern (Antarctic), Arctic**." },
              { h: "Records worth knowing", p: "Largest continent: Asia. Smallest: Australia. Largest ocean: the Pacific. The deepest place on Earth is the Mariana Trench in the Pacific Ocean, about 11 km down." },
              { h: "A useful fact", p: "Africa is the only continent that lies in all four hemispheres — north, south, east and west." }
            ],
            keyPoints: [
              "7 continents, 5 oceans",
              "Asia is the largest continent and Australia the smallest",
              "The Pacific is the largest and deepest ocean",
              "Africa crosses the equator and both main lines of longitude"
            ],
            example: {
              title: "Where is the Sahara?",
              steps: ["The Sahara is the largest hot desert on Earth", "It covers about 9 million km²", "It stretches across 11 countries", "It is located in North Africa, on the continent of Africa"]
            }
          },
          questions: [
            { q: "Which is the largest continent by area?", options: ["Asia", "Africa", "Europe", "North America"], answer: 0, explain: "Asia is the largest continent, covering about 44 million km² and holding most of the world population." },
            { q: "How many continents are there on Earth?", options: ["7", "5", "6", "8"], answer: 0, explain: "There are seven continents: Asia, Africa, North America, South America, Antarctica, Europe and Australia." },
            { q: "Which is the largest ocean?", options: ["Pacific", "Atlantic", "Indian", "Arctic"], answer: 0, explain: "The Pacific is the largest and deepest ocean, covering about a third of the planet." },
            { q: "Which ocean lies between Africa and the Americas?", options: ["Atlantic", "Pacific", "Indian", "Southern"], answer: 0, explain: "The Atlantic Ocean separates Africa and Europe from the Americas." },
            { q: "On which continent is the Sahara Desert?", options: ["Africa", "Asia", "Australia", "South America"], answer: 0, explain: "The Sahara covers much of North Africa." },
            { q: "Which continent is the smallest?", options: ["Australia", "Europe", "Antarctica", "South America"], answer: 0, explain: "Australia (Oceania) is the smallest continent by land area." }
          ]
        },
        {
          id: "capitals",
          title: "World Capitals",
          summary: "The capital cities people most often get wrong.",
          minutes: 6,
          explain: {
            intro: "Every country has a **capital city** — the seat of its government. It is not always the biggest or most famous city in the country.",
            sections: [
              { h: "Well-known capitals", p: "", list: ["Egypt → Cairo", "France → Paris", "Japan → Tokyo", "Italy → Rome", "United Kingdom → London"] },
              { h: "The ones people mix up", p: "", list: ["United Arab Emirates → Abu Dhabi (not Dubai)", "Türkiye → Ankara (not Istanbul)", "Australia → Canberra (not Sydney)", "Canada → Ottawa (not Toronto)", "Brazil → Brasília (not Rio de Janeiro)", "United States → Washington, D.C. (not New York)", "Switzerland → Bern (not Zurich)"] },
              { h: "Why capitals differ from big cities", p: "Some capitals were built on purpose to be neutral ground and to spread wealth away from the largest city — Canberra, Brasília and Ottawa were all chosen for this reason." }
            ],
            keyPoints: [
              "The capital is the seat of government, not always the largest city",
              "UAE → Abu Dhabi, Türkiye → Ankara, Brazil → Brasília",
              "Canberra, Brasília and Ottawa were purpose-built capitals"
            ],
            example: {
              title: "Comparing the UAE",
              steps: ["Dubai is the best-known city and a major business hub", "The capital is Abu Dhabi", "Abu Dhabi is where the federal government sits", "So the answer to 'capital of the UAE' is Abu Dhabi, not Dubai"]
            }
          },
          questions: [
            { q: "What is the capital of Egypt?", options: ["Cairo", "Alexandria", "Giza", "Luxor"], answer: 0, explain: "Cairo is the capital of Egypt and the largest city in the Arab world." },
            { q: "What is the capital of Japan?", options: ["Tokyo", "Osaka", "Kyoto", "Sapporo"], answer: 0, explain: "Tokyo has been the capital of Japan since 1868." },
            { q: "What is the capital of the United Arab Emirates?", options: ["Abu Dhabi", "Dubai", "Sharjah", "Doha"], answer: 0, explain: "Abu Dhabi is the capital. Dubai is the largest city but not the capital; Doha is the capital of Qatar." },
            { q: "What is the capital of Canada?", options: ["Ottawa", "Toronto", "Vancouver", "Montreal"], answer: 0, explain: "Ottawa is the capital. Toronto is the largest city." },
            { q: "What is the capital of Brazil?", options: ["Brasília", "Rio de Janeiro", "São Paulo", "Salvador"], answer: 0, explain: "Brasília was purpose-built and became the capital in 1960." },
            { q: "What is the capital of Australia?", options: ["Canberra", "Sydney", "Melbourne", "Perth"], answer: 0, explain: "Canberra is the capital — chosen as a compromise between rivals Sydney and Melbourne." },
            { q: "What is the capital of France?", options: ["Paris", "Lyon", "Marseille", "Nice"], answer: 0, explain: "Paris is the capital and largest city of France." }
          ]
        }
      ]
    },

    {
      id: "computing",
      name: "Computer Science",
      tagline: "How computers work and how to stay safe online.",
      color: "#0284c7",
      icon: "monitor",
      lessons: [
        {
          id: "computer-basics",
          title: "How Computers Work",
          summary: "Input, process, output, storage — and hardware vs software.",
          minutes: 7,
          explain: {
            intro: "Almost every computer follows the same pattern: it takes **input**, **processes** it, produces **output**, and can **store** the results.",
            sections: [
              { h: "Input", p: "Input devices send data into the computer.", list: ["keyboard, mouse, microphone, camera, touchscreen, scanner"] },
              { h: "Process", p: "The **CPU** (Central Processing Unit) carries out the instructions — it is often called the brain of the computer. More cores and a higher clock speed mean more work done at once." },
              { h: "Output", p: "Output devices present the results.", list: ["monitor, speakers, printer, headphones"] },
              { h: "Storage", p: "**RAM** is very fast but temporary — it is cleared when the power goes off. A **hard drive or SSD** keeps your files permanently, even when the computer is switched off." },
              { h: "Hardware vs software", p: "**Hardware** is the physical equipment you can touch (screen, CPU, keyboard). **Software** is the set of programs and instructions (the operating system, a browser, a game)." }
            ],
            keyPoints: [
              "CPU = the processor, the brain of the computer",
              "RAM = fast, temporary memory; SSD/HDD = permanent storage",
              "Hardware you can touch, software you cannot",
              "Every task follows input → process → output"
            ],
            example: {
              title: "Following the pattern: typing a letter",
              steps: ["Input: you press the keys on the keyboard", "Process: the CPU turns the key presses into characters", "Output: the letters appear on the screen", "Storage: you save the file to the SSD"]
            }
          },
          questions: [
            { q: "Which of these is an input device?", options: ["Keyboard", "Monitor", "Printer", "Speaker"], answer: 0, explain: "A keyboard sends data into the computer, so it is an input device. The others are output devices." },
            { q: "What does CPU stand for?", options: ["Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Control Panel Unit"], answer: 0, explain: "CPU stands for Central Processing Unit — the part that executes instructions." },
            { q: "Which type of memory loses its contents when the power is turned off?", options: ["RAM", "SSD", "Hard disk drive", "USB flash drive"], answer: 0, explain: "RAM is volatile memory. SSDs, hard drives and USB drives keep data without power." },
            { q: "Which of these is software?", options: ["An operating system", "A keyboard", "A mouse", "A monitor"], answer: 0, explain: "An operating system is a program, so it is software. The rest are physical hardware." },
            { q: "Which device produces output?", options: ["Printer", "Microphone", "Scanner", "Mouse"], answer: 0, explain: "A printer shows results on paper, so it is an output device." },
            { q: "Which storage keeps your files permanently?", options: ["SSD", "RAM", "Cache", "Registers"], answer: 0, explain: "An SSD (or hard drive) stores data permanently, even when the computer is off." }
          ]
        },
        {
          id: "online-safety",
          title: "The Internet & Online Safety",
          summary: "Passwords, phishing and protecting your personal data.",
          minutes: 8,
          explain: {
            intro: "The internet is powerful, but everything you post and every password you type needs protecting. A few simple habits keep you safe.",
            sections: [
              { h: "Strong passwords", p: "Use at least 12 characters mixing upper and lower case letters, numbers and symbols. **Never reuse** the same password on different websites, and never use your name or birthday." },
              { h: "Phishing", p: "Fake emails, texts or websites that pretend to be genuine in order to steal your password or bank details. The warning signs: urgency, spelling mistakes, strange sender addresses, and links that do not match the real website." },
              { h: "Two-factor authentication (2FA)", p: "Adds a second proof of identity — usually a code on your phone — so that a stolen password alone is not enough to get into your account." },
              { h: "HTTPS and the padlock", p: "The padlock in the address bar means the connection is **encrypted**. Never type a password on a page without it." },
              { h: "Personal information", p: "Never share your full name, home address, school name or photos with strangers online. Once something is posted, it is very hard to remove." }
            ],
            keyPoints: [
              "Long, unique passwords — a password manager helps",
              "Never click links in unexpected messages",
              "Turn on two-factor authentication wherever it is offered",
              "A padlock (HTTPS) means the connection is encrypted",
              "Keep personal information private"
            ],
            example: {
              title: "Spotting a phishing message",
              steps: ["It says your account will be closed in 1 hour (urgency)", "The sender address is support@bank-secure-login.xyz (not the real domain)", "The link points somewhere different from the bank's website", "It asks you to confirm your password by typing it", "Conclusion: delete it and report it — do not click"]
            }
          },
          questions: [
            { q: "What does the 'S' in HTTPS stand for?", options: ["Secure", "Simple", "Server", "Speed"], answer: 0, explain: "HTTPS means HyperText Transfer Protocol Secure — the connection is encrypted." },
            { q: "What is phishing?", options: ["A fake message that tries to steal your information", "A way to speed up the internet", "A type of firewall", "A search engine"], answer: 0, explain: "Phishing is a trick that pretends to be a trusted organisation so you hand over passwords or payment details." },
            { q: "Which password is the strongest?", options: ["Tr7#kL9!pQ2@", "password123", "yourname2010", "12345678"], answer: 0, explain: "It is long and mixes upper case, lower case, numbers and symbols, which makes it very hard to guess." },
            { q: "What does two-factor authentication add?", options: ["A second proof of identity, such as a code on your phone", "A longer password", "A faster internet connection", "A backup email address"], answer: 0, explain: "2FA requires something you know plus something you have, so a stolen password is not enough." },
            { q: "A message says you have won a prize and you must click a link to claim it. What should you do?", options: ["Delete or report it without clicking the link", "Click quickly before it expires", "Reply with your bank details", "Forward it to all your friends"], answer: 0, explain: "This is a classic phishing lure. Urgency and prizes are the warning signs — do not click, just delete or report it." },
            { q: "What does a padlock icon in the address bar mean?", options: ["The connection is encrypted", "The website is free to use", "The website is the fastest", "The site belongs to a government"], answer: 0, explain: "The padlock shows the connection uses HTTPS and is encrypted, so data cannot easily be read in transit." }
          ]
        }
      ]
    },

    {
      id: "arabic",
      name: "Arabic",
      tagline: "The alphabet, everyday greetings and the numbers 1 to 10.",
      color: "#16a34a",
      icon: "book",
      lessons: [
        {
          id: "alphabet",
          title: "The Arabic Alphabet",
          summary: "28 letters, written right to left, that change shape by position.",
          minutes: 9,
          explain: {
            intro: "Arabic (العربية) is written from **right to left** and uses **28 letters**. Most letters also change shape slightly depending on where they appear in a word.",
            sections: [
              { h: "The first letters", p: "Here are some of the letters with the sound they make:", list: ["ا alif — a", "ب bā — b", "ت tā — t", "ث thā — th (as in think)", "ج jīm — j", "د dāl — d", "ر rā — r", "س sīn — s", "ش shīn — sh", "م mīm — m", "ن nūn — n", "ه hā — h", "ي yā — y"] },
              { h: "Letters change shape", p: "A letter has an **isolated** form, an **initial** form, a **medial** form and a **final** form. The basic shape stays the same but the way it connects changes. For example ب looks like: ب (alone), بـ (at the start), ـبـ (in the middle), ـب (at the end)." },
              { h: "Short vowels (harakat)", p: "Short vowels are written as small marks above or below a letter: a **fatha** (َ) gives an 'a' sound, a **kasra** (ِ) gives 'i', and a **damma** (ُ) gives 'u'. Books for children print them all; adult texts often leave them out." },
              { h: "Which way is it going?", p: "Read the individual letters right to left, but read numbers left to right. The Arabic numerals ١ ٢ ٣ are written in the same left-to-right order as English numbers." }
            ],
            keyPoints: [
              "28 letters, always written from right to left",
              "A letter changes shape depending on its position in the word",
              "Short vowels are written as marks above or below the letters",
              "Arabic numerals are written left to right"
            ],
            example: {
              title: "Reading your first word: كِتَاب (kitāb, book)",
              steps: ["Start at the right: ك  = k sound", "ت  = t sound, with a kasra (ِ) under it → kɪ", "ا  = long ā", "ب  = b sound", "Read together: كِتَاب = ki-tāb"]
            }
          },
          questions: [
            { q: "How many letters are in the Arabic alphabet?", options: ["28", "26", "29", "22"], answer: 0, explain: "The Arabic alphabet has 28 letters, beginning with alif (ا) and ending with yā (ي)." },
            { q: "In which direction is Arabic written?", options: ["Right to left", "Left to right", "Top to bottom", "It changes with the subject"], answer: 0, explain: "Arabic is written and read from right to left." },
            { q: "Which letter is the first letter of the Arabic alphabet?", options: ["ا (alif)", "ب (bā)", "م (mīm)", "ي (yā)"], answer: 0, explain: "Alif (ا) is the first letter and yā (ي) is the last." },
            { q: "What sound does the letter ب make?", options: ["b", "m", "t", "n"], answer: 0, explain: "ب is bā and makes the 'b' sound. Careful: م makes 'm' and ن makes 'n'." },
            { q: "Which of these is the letter mīm?", options: ["م", "ن", "ه", "ل"], answer: 0, explain: "م is mīm (m). ن is nūn (n), ه is hā (h) and ل is lām (l)." },
            { q: "Why do Arabic letters change shape?", options: ["Their shape depends on their position in the word", "They never change shape", "To show if the speaker is male", "To show past tense"], answer: 0, explain: "Letters have isolated, initial, medial and final forms, depending on where they sit in the word." },
            { q: "What are the small vowel marks above and below letters called?", options: ["Harakat", "Numbers", "Root letters", "Punctuation"], answer: 0, explain: "Harakat are the short vowel marks — fatha (َ), kasra (ِ) and damma (ُ)." }
          ]
        },
        {
          id: "greetings",
          title: "Greetings & Introductions",
          summary: "Say hello, ask how someone is, and introduce yourself.",
          minutes: 8,
          explain: {
            intro: "Arabic greetings are generous — people often exchange several at once. Here are the phrases you will hear every day.",
            sections: [
              { h: "Hello and welcome", p: "", list: ["السلام عليكم — as-salāmu ʿalaykum (peace be upon you)", "وعليكم السلام — wa ʿalaykumu s-salām (the reply: peace be upon you too)", "مرحبا — marhaba (hello)", "أهلا وسهلا — ahlan wa sahlan (welcome)"] },
              { h: "By time of day", p: "", list: ["صباح الخير — sabāh al-khayr (good morning)", "مساء الخير — masāʾ al-khayr (good evening)"] },
              { h: "Asking and answering", p: "", list: ["كيف حالك؟ — kayfa hāluk? (how are you? — to a male)", "كيف حالكِ؟ — kayfa hāluki? (to a female)", "أنا بخير، شكرا — anā bi-khayr, shukran (I am fine, thank you)", "ما اسمك؟ — mā ismuk? (what is your name?)", "اسمي… — ismī … (my name is …)"] },
              { h: "Saying goodbye", p: "", list: ["شكرا — shukran (thank you)", "عفوا — ʿafwan (you are welcome)", "مع السلامة — maʿa s-salāma (goodbye)"] }
            ],
            keyPoints: [
              "السلام عليكم is the most common greeting — reply with وعليكم السلام",
              "مساء الخير is used from late afternoon onwards",
              "شكرا means thank you and عفوا means you are welcome",
              "مع السلامة means goodbye"
            ],
            example: {
              title: "A short conversation",
              steps: ["A: السلام عليكم  (peace be upon you)", "B: وعليكم السلام  (and peace be upon you too)", "A: كيف حالك؟  (how are you?)", "B: أنا بخير، شكرا  (I am fine, thank you)", "A: ما اسمك؟  (what is your name?)", "B: اسمي نور  (my name is Noor)"]
            }
          },
          questions: [
            { q: "What does مرحبا (marhaba) mean?", options: ["Hello", "Goodbye", "Thank you", "Sorry"], answer: 0, explain: "مرحبا (marhaba) is a friendly way of saying hello." },
            { q: "How do you say 'Good morning' in Arabic?", options: ["صباح الخير", "مساء الخير", "مع السلامة", "شكرا"], answer: 0, explain: "صباح الخير (sabāh al-khayr) means good morning. مساء الخير is good evening." },
            { q: "What does شكرا (shukran) mean?", options: ["Thank you", "Please", "Hello", "Yes"], answer: 0, explain: "شكرا means thank you. You can reply with عفوا (you are welcome)." },
            { q: "What does ما اسمك؟ (mā ismuk?) mean?", options: ["What is your name?", "How old are you?", "Where are you from?", "How are you?"], answer: 0, explain: "ما اسمك؟ literally means 'what your name?' — what is your name?" },
            { q: "If someone says كيف حالك؟, which reply fits best?", options: ["أنا بخير، شكرا", "مع السلامة", "صباح الخير", "ما اسمك؟"], answer: 0, explain: "كيف حالك؟ asks how you are, so أنا بخير، شكرا (I am fine, thank you) is the natural reply." },
            { q: "What does مع السلامة (maʿa s-salāma) mean?", options: ["Goodbye", "Welcome", "Good night", "Thank you"], answer: 0, explain: "مع السلامة literally means 'with safety' and is used when saying goodbye." },
            { q: "Which greeting would you use when a guest arrives at your home?", options: ["أهلا وسهلا", "مع السلامة", "شكرا", "اسمي"], answer: 0, explain: "أهلا وسهلا (ahlan wa sahlan) means welcome and is used to greet arriving guests." }
          ]
        },
        {
          id: "numbers",
          title: "Numbers ١ – ١٠",
          summary: "Count from one to ten in Arabic, in words and numerals.",
          minutes: 6,
          explain: {
            intro: "Arabic has its own numerals — ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠ — which are written **from left to right**, even though the language itself runs right to left.",
            sections: [
              { h: "Numbers ١ – ٥", p: "", list: ["١ واحد — wāhid (1)", "٢ اثنان — ithnān (2)", "٣ ثلاثة — thalātha (3)", "٤ أربعة — arbaʿa (4)", "٥ خمسة — khamsa (5)"] },
              { h: "Numbers ٦ – ١٠", p: "", list: ["٦ ستة — sitta (6)", "٧ سبعة — sabʿa (7)", "٨ ثمانية — thamāniya (8)", "٩ تسعة — tisʿa (9)", "١٠ عشرة — ʿashara (10)"] },
              { h: "How the numerals look", p: "Notice that ٠ is written as a simple dot, and ١ looks like a mirrored English 1. ٢ and ٣ are reversed versions of each other, so take care not to mix them up." },
              { h: "Practice tip", p: "Learn them in pairs: ١/٢, ٣/٤, ٥/٦, ٧/٨ and ٩/١٠. Repeat each pair aloud five times and the rhythm makes them stick." }
            ],
            keyPoints: [
              "Arabic numerals: ٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩",
              "Numbers are read left to right",
              "خمسة (khamsa) is five, عشرة (ʿashara) is ten"
            ],
            example: {
              title: "Counting objects",
              steps: ["كتاب واحد — kitāb wāhid (one book)", "كتابان اثنان — kitābān ithnān (two books)", "ثلاثة كتب — thalātha kutub (three books)", "عشرة كتب — ʿashara kutub (ten books)"]
            }
          },
          questions: [
            { q: "Which is the Arabic numeral for 5?", options: ["٥", "٤", "٦", "٥٠"], answer: 0, explain: "٥ is five, written khamsa (خمسة)." },
            { q: "What does ثلاثة (thalātha) mean?", options: ["Three", "Four", "Two", "Ten"], answer: 0, explain: "ثلاثة is three. أربعة is four and اثنان is two." },
            { q: "How is the number 7 written in Arabic numerals?", options: ["٧", "٦", "٩", "١٠"], answer: 0, explain: "٧ is 7 (sabʿa). ٦ is 6 and ٩ is 9." },
            { q: "What does عشرة (ʿashara) mean?", options: ["Ten", "Nine", "Five", "One"], answer: 0, explain: "عشرة is ten. تسعة is nine and واحد is one." },
            { q: "Which number is ٢?", options: ["Two", "One", "Three", "Twenty"], answer: 0, explain: "٢ is two — ithnān (اثنان)." },
            { q: "What does خمسة (khamsa) mean?", options: ["Five", "Six", "Seven", "Four"], answer: 0, explain: "خمسة is five. ستة is six and سبعة is seven." }
          ]
        }
      ]
    },

    {
      id: "english",
      name: "English",
      tagline: "Parts of speech, verb tenses and everyday idioms.",
      color: "#e11d48",
      icon: "letter-a",
      lessons: [
        {
          id: "parts-of-speech",
          title: "Parts of Speech",
          summary: "Name the job every word does in a sentence.",
          minutes: 8,
          explain: {
            intro: "Every English word belongs to a **part of speech** — the job it does in a sentence. The same word can change job depending on how it is used.",
            sections: [
              { h: "Noun", p: "A person, place, thing or idea.", list: ["teacher, Cairo, bicycle, freedom, happiness"] },
              { h: "Verb", p: "An action or a state of being.", list: ["run, write, is, believe, seem"] },
              { h: "Adjective", p: "Describes a noun — what kind, how many, which one.", list: ["tall, clever, blue, three, expensive"] },
              { h: "Adverb", p: "Describes a verb, an adjective or another adverb. Many end in -ly.", list: ["quickly, very, yesterday, almost, here"] },
              { h: "Pronoun", p: "Replaces a noun so you do not repeat it.", list: ["I, you, he, she, it, we, they, this, someone"] },
              { h: "Preposition", p: "Shows the relationship of place, time or direction.", list: ["in, on, under, at, between, during, with"] },
              { h: "Conjunction", p: "Joins words, phrases or clauses together.", list: ["and, but, or, because, although, so"] }
            ],
            keyPoints: [
              "Ask 'what job is this word doing here?' — that tells you the part of speech",
              "'Fast' can be an adjective (a fast car) or an adverb (he ran fast)",
              "Adverbs often end in -ly, but not always (very, soon, often)"
            ],
            example: {
              title: "Label the sentence: 'The young boy ran quickly to school.'",
              steps: ["The — article", "young — adjective (describes boy)", "boy — noun", "ran — verb", "quickly — adverb (describes ran)", "to — preposition", "school — noun"]
            }
          },
          questions: [
            { q: "Which word is the noun in 'The dog barked loudly'?", options: ["dog", "barked", "loudly", "The"], answer: 0, explain: "A dog is a thing, so 'dog' is the noun. 'Barked' is the verb and 'loudly' is the adverb." },
            { q: "Which word is the adjective in 'She wore a red hat'?", options: ["red", "wore", "She", "hat"], answer: 0, explain: "'Red' describes the noun 'hat', so it is an adjective." },
            { q: "Which word is the verb in 'They played football yesterday'?", options: ["played", "They", "football", "yesterday"], answer: 0, explain: "'Played' is the action, so it is the verb. 'Yesterday' is an adverb of time." },
            { q: "Which word is the adverb in 'He ran quickly'?", options: ["quickly", "ran", "He", "none of these"], answer: 0, explain: "'Quickly' describes how he ran, so it is an adverb." },
            { q: "Which word is the pronoun in 'Sara said she was tired'?", options: ["she", "Sara", "said", "tired"], answer: 0, explain: "'She' replaces the noun 'Sara', so it is a pronoun." },
            { q: "Which word is the preposition in 'The cat is under the table'?", options: ["under", "cat", "is", "table"], answer: 0, explain: "'Under' shows the relationship of place between the cat and the table." },
            { q: "Which word is the conjunction in 'I like tea but not coffee'?", options: ["but", "like", "tea", "not"], answer: 0, explain: "'But' joins the two ideas together, so it is a conjunction." }
          ]
        },
        {
          id: "tenses",
          title: "Verb Tenses",
          summary: "Past, present, future, continuous and perfect — clearly compared.",
          minutes: 9,
          explain: {
            intro: "**Tense** tells you *when* an action happens. English shows tense by changing the verb, or by adding a helping verb such as be, have or will.",
            sections: [
              { h: "Present simple", p: "Used for facts, habits and routines. Add **-s** for he, she and it.", list: ["I walk to school.", "She walks to school every day.", "Water boils at 100 °C."] },
              { h: "Present continuous", p: "Used for actions happening right now: **am / is / are + verb-ing**.", list: ["I am reading a book.", "They are playing outside."] },
              { h: "Past simple", p: "Used for finished actions. Regular verbs add **-ed**; irregular verbs change completely.", list: ["I walked home.", "He went to Cairo last year.", "go → went, eat → ate, see → saw"] },
              { h: "Future simple", p: "Used for decisions and predictions: **will + base verb**.", list: ["I will call you tomorrow.", "It will rain later."] },
              { h: "Present perfect", p: "Links the past to now: **have / has + past participle**.", list: ["I have eaten already.", "She has finished her homework."] }
            ],
            keyPoints: [
              "Regular past tense = verb + ed",
              "Irregular past forms must be learned (go → went, eat → ate)",
              "Add -s in the present simple for he, she and it",
              "Continuous = be + verb-ing; perfect = have + past participle"
            ],
            example: {
              title: "The same verb in five tenses: 'study'",
              steps: ["Present simple: I study English", "Present continuous: I am studying English", "Past simple: I studied English yesterday", "Future simple: I will study English tomorrow", "Present perfect: I have studied English for three years"]
            }
          },
          questions: [
            { q: "What is the past simple of 'go'?", options: ["went", "goed", "gone", "going"], answer: 0, explain: "'Go' is irregular, so the past simple is 'went'. 'Gone' is the past participle." },
            { q: "Complete: She ___ to school every day.", options: ["goes", "go", "going", "gone"], answer: 0, explain: "Present simple with he, she or it adds -s, so 'she goes'." },
            { q: "Complete: They ___ football yesterday.", options: ["played", "play", "have played", "will play"], answer: 0, explain: "'Yesterday' is a finished time, so the past simple 'played' is correct." },
            { q: "Complete: I ___ you tomorrow.", options: ["will call", "called", "have called", "was calling"], answer: 0, explain: "'Tomorrow' needs a future form, and 'will call' is the future simple." },
            { q: "Which sentence is in the present continuous?", options: ["I am reading a book", "I read a book", "I read a book yesterday", "I will read a book"], answer: 0, explain: "Present continuous uses am/is/are + verb-ing: 'I am reading'." },
            { q: "Which sentence uses the present perfect?", options: ["She has finished her homework", "She finished her homework", "She is finishing her homework", "She finishes her homework"], answer: 0, explain: "'Has finished' is have/has + past participle, which is the present perfect." },
            { q: "What is the past simple of 'eat'?", options: ["ate", "eated", "eaten", "eating"], answer: 0, explain: "'Eat' is irregular: eat → ate → eaten. 'Eaten' is the past participle." }
          ]
        },
        {
          id: "idioms",
          title: "Vocabulary & Idioms",
          summary: "Common expressions whose meaning is not in the words.",
          minutes: 7,
          explain: {
            intro: "**Idioms** are fixed phrases whose meaning is not obvious from the individual words. Learning them makes your English sound natural.",
            sections: [
              { h: "Everyday idioms", p: "", list: ["break the ice — start a conversation in an awkward situation", "a piece of cake — very easy", "hit the books — study hard", "under the weather — feeling ill", "once in a blue moon — very rarely", "cost an arm and a leg — be very expensive"] },
              { h: "In a sentence", p: "", list: ["The exam was a piece of cake — I finished in ten minutes.", "He is a bit under the weather today, so he stayed home.", "We only see our cousins once in a blue moon."] },
              { h: "Building vocabulary", p: "Learn a new word with three things: its **meaning**, an **example sentence**, and at least one **synonym or antonym**. Words learned this way stay in memory far longer." }
            ],
            keyPoints: [
              "Idioms cannot be translated word for word",
              "Learn each idiom inside a full example sentence",
              "Use context to guess an unfamiliar word's meaning"
            ],
            example: {
              title: "Guessing from context",
              steps: ["Sentence: 'That phone cost me an arm and a leg.'", "The words 'arm' and 'leg' do not make sense literally", "The sentence is about buying something", "So the phrase must mean it was very expensive"]
            }
          },
          questions: [
            { q: "'The test was a piece of cake.' The test was…", options: ["very easy", "very difficult", "delicious", "very long"], answer: 0, explain: "'A piece of cake' means something is very easy to do." },
            { q: "If you are 'under the weather', you are…", options: ["feeling ill", "outside in the rain", "very happy", "on a plane"], answer: 0, explain: "'Under the weather' means feeling slightly ill or unwell." },
            { q: "'Break the ice' means to…", options: ["start a conversation in an awkward situation", "break something by accident", "go ice skating", "get angry with someone"], answer: 0, explain: "'Break the ice' means to get a conversation going and make people feel comfortable." },
            { q: "'Hit the books' means to…", options: ["study hard", "throw books away", "read for fun", "buy new books"], answer: 0, explain: "'Hit the books' means to begin studying seriously." },
            { q: "'Once in a blue moon' means…", options: ["very rarely", "every night", "always", "never"], answer: 0, explain: "A blue moon is rare, so the idiom means something happens very rarely." },
            { q: "Which word is a synonym of 'happy'?", options: ["joyful", "angry", "tired", "quiet"], answer: 0, explain: "'Joyful' has the same meaning as 'happy'. The others are unrelated or opposite." },
            { q: "Which word is the opposite of 'ancient'?", options: ["modern", "old", "historic", "antique"], answer: 0, explain: "'Ancient' means very old, so 'modern' (new, current) is its opposite." }
          ]
        }
      ]
    },

    {
      id: "french",
      name: "French",
      tagline: "Start speaking French: greetings and numbers.",
      color: "#2563eb",
      icon: "tower",
      lessons: [
        {
          id: "greetings",
          title: "Greetings & Introductions",
          summary: "Say hello, introduce yourself and say goodbye in French.",
          minutes: 8,
          explain: {
            intro: "French greetings change with how well you know someone. **Bonjour** works almost everywhere; **salut** is for friends and family.",
            sections: [
              { h: "Hello and goodbye", p: "", list: ["Bonjour — hello / good morning (safe in almost any situation)", "Bonsoir — good evening", "Salut — hi / bye (informal, with friends)", "Au revoir — goodbye", "À bientôt — see you soon"] },
              { h: "Introducing yourself", p: "", list: ["Comment tu t'appelles ? — what is your name? (informal)", "Comment vous appelez-vous ? — what is your name? (formal)", "Je m'appelle… — my name is…", "Enchanté / Enchantée — nice to meet you"] },
              { h: "How are you?", p: "", list: ["Comment ça va ? / Ça va ? — how are you?", "Ça va bien, merci — I am well, thank you", "Comme ci, comme ça — so-so"] },
              { h: "Being polite", p: "", list: ["Merci — thank you", "Merci beaucoup — thank you very much", "S'il vous plaît — please (formal)", "De rien — you are welcome", "Excusez-moi — excuse me", "Pardon — sorry / excuse me"] }
            ],
            keyPoints: [
              "Bonjour is safe in almost any situation",
              "Salut is only for friends and family",
              "Je m'appelle… means my name is…",
              "Merci = thank you, s'il vous plaît = please"
            ],
            example: {
              title: "A first conversation in French",
              steps: ["A: Bonjour ! Comment tu t'appelles ?", "B: Salut, je m'appelle Léa. Et toi ?", "A: Je m'appelle Sami. Enchanté !", "B: Enchantée ! Ça va ?", "A: Ça va bien, merci. Au revoir !"]
            }
          },
          questions: [
            { q: "What does 'Bonjour' mean?", options: ["Hello", "Goodbye", "Thank you", "Please"], answer: 0, explain: "Bonjour means hello, or good morning — it works in almost any situation." },
            { q: "Which French word means 'thank you'?", options: ["Merci", "Pardon", "Salut", "De rien"], answer: 0, explain: "Merci is thank you. De rien means you are welcome." },
            { q: "How do you say 'My name is…' in French?", options: ["Je m'appelle…", "Comment tu t'appelles ?", "Ça va ?", "Au revoir"], answer: 0, explain: "Je m'appelle… literally means 'I call myself…'. The question is Comment tu t'appelles ?" },
            { q: "Which greeting is informal and used with friends?", options: ["Salut", "Bonsoir", "Bonjour", "Au revoir"], answer: 0, explain: "Salut is informal and means both hi and bye — use it only with people you know well." },
            { q: "What does 'Comment ça va ?' mean?", options: ["How are you?", "What is your name?", "Where are you from?", "How old are you?"], answer: 0, explain: "Comment ça va ? (or just Ça va ?) asks how someone is." },
            { q: "Which phrase means 'please'?", options: ["S'il vous plaît", "Merci", "De rien", "Excusez-moi"], answer: 0, explain: "S'il vous plaît means please. With a friend you can say s'il te plaît." },
            { q: "What does 'Au revoir' mean?", options: ["Goodbye", "Hello", "Welcome", "Good evening"], answer: 0, explain: "Au revoir means goodbye. À bientôt means see you soon." }
          ]
        },
        {
          id: "numbers",
          title: "Numbers 1 – 10",
          summary: "Count from one to ten in French and learn to say your age.",
          minutes: 6,
          explain: {
            intro: "French numbers from **un** to **dix**. Watch out for **un** and **une** — French nouns have a gender, and the number has to match.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 un / une — uh(n)", "2 deux — duh", "3 trois — twah", "4 quatre — katr", "5 cinq — sank"] },
              { h: "6 – 10", p: "", list: ["6 six — sees", "7 sept — set", "8 huit — weet", "9 neuf — nuhf", "10 dix — dees"] },
              { h: "Useful phrases", p: "", list: ["Combien ? — how many / how much?", "J'ai dix ans — I am ten years old (literally: I have ten years)", "Il y a trois livres — there are three books"] }
            ],
            keyPoints: [
              "un, deux, trois, quatre, cinq",
              "six, sept, huit, neuf, dix",
              "Age uses the verb avoir: J'ai dix ans",
              "The final letter of cinq, huit and dix is often silent"
            ],
            example: {
              title: "Counting aloud",
              steps: ["un, deux, trois…", "quatre, cinq, six…", "sept, huit, neuf, dix !"]
            }
          },
          questions: [
            { q: "What is 'trois' in English?", options: ["Three", "Two", "Four", "Ten"], answer: 0, explain: "trois is three. deux is two and quatre is four." },
            { q: "How do you say 5 in French?", options: ["cinq", "six", "sept", "quatre"], answer: 0, explain: "5 is cinq. six is 6." },
            { q: "What does 'dix' mean?", options: ["Ten", "Eight", "Six", "Two"], answer: 0, explain: "dix is ten. huit is eight and six is six." },
            { q: "Which is the French word for 8?", options: ["huit", "neuf", "sept", "six"], answer: 0, explain: "huit is eight. neuf is nine." },
            { q: "What does 'un / une' mean?", options: ["One", "Nine", "Eleven", "Zero"], answer: 0, explain: "un (masculine) and une (feminine) both mean one." },
            { q: "How do you say 'I am ten years old' in French?", options: ["J'ai dix ans", "Je suis dix ans", "J'ai dix", "J'ai ans dix"], answer: 0, explain: "French uses avoir (to have) for age: J'ai dix ans — literally 'I have ten years'." }
          ]
        }
      ]
    },

    {
      id: "german",
      name: "German",
      tagline: "Start speaking German: greetings and numbers.",
      color: "#7c3aed",
      icon: "flag",
      lessons: [
        {
          id: "greetings",
          title: "Greetings & Introductions",
          summary: "Say hello, introduce yourself and say goodbye in German.",
          minutes: 8,
          explain: {
            intro: "German has a formal and an informal way of saying **you**: **du** for friends and family, **Sie** for everyone else. Getting this right matters.",
            sections: [
              { h: "Hello and goodbye", p: "", list: ["Hallo — hello", "Guten Morgen — good morning", "Guten Tag — good day (used most of the day)", "Guten Abend — good evening", "Gute Nacht — good night (before sleeping)", "Tschüss — bye (informal)", "Auf Wiedersehen — goodbye (formal)"] },
              { h: "Introducing yourself", p: "", list: ["Wie heißt du? — what is your name? (informal)", "Wie heißen Sie? — what is your name? (formal)", "Ich heiße… — my name is…", "Ich bin… — I am…", "Freut mich — nice to meet you"] },
              { h: "How are you?", p: "", list: ["Wie geht es dir? — how are you? (informal)", "Wie geht es Ihnen? — how are you? (formal)", "Mir geht es gut — I am well", "Es geht — I am okay"] },
              { h: "Polite words", p: "", list: ["Danke — thank you", "Vielen Dank — many thanks", "Bitte — please / you are welcome", "Entschuldigung — excuse me / sorry", "Ja / Nein — yes / no"] }
            ],
            keyPoints: [
              "du = informal you, Sie = formal you",
              "Ich heiße… means my name is…",
              "Bitte means both please and you are welcome",
              "All German nouns are written with a capital letter"
            ],
            example: {
              title: "A first conversation in German",
              steps: ["A: Hallo! Wie heißt du?", "B: Ich heiße Anna. Und du?", "A: Ich bin Jonas. Freut mich!", "B: Freut mich. Wie geht es dir?", "A: Mir geht es gut, danke. Tschüss!"]
            }
          },
          questions: [
            { q: "What does 'Guten Morgen' mean?", options: ["Good morning", "Good night", "Goodbye", "Thank you"], answer: 0, explain: "Guten Morgen is good morning. Gute Nacht is good night." },
            { q: "Which word means 'thank you'?", options: ["Danke", "Bitte", "Tschüss", "Hallo"], answer: 0, explain: "Danke is thank you. Bitte means please, or you are welcome." },
            { q: "How do you say 'My name is…'?", options: ["Ich heiße…", "Wie heißt du?", "Mir geht es gut", "Freut mich"], answer: 0, explain: "Ich heiße… means my name is…; Wie heißt du? is the question." },
            { q: "Which form of 'you' do you use with your teacher?", options: ["Sie", "du", "dich", "dir"], answer: 0, explain: "Use Sie with people you do not know well, and du with friends and family." },
            { q: "What does 'Tschüss' mean?", options: ["Bye", "Hello", "Please", "Sorry"], answer: 0, explain: "Tschüss is the informal way of saying bye. Auf Wiedersehen is the formal one." },
            { q: "What does 'Bitte' mean?", options: ["Please / you are welcome", "Thank you", "Good evening", "Yes"], answer: 0, explain: "Bitte does double duty: please when you ask, and you are welcome when you reply." }
          ]
        },
        {
          id: "numbers",
          title: "Numbers 1 – 10",
          summary: "Count from one to ten in German and learn to say your age.",
          minutes: 6,
          explain: {
            intro: "German numbers from **eins** to **zehn**. German says your age with the verb **sein**: Ich bin zehn Jahre alt.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 eins", "2 zwei", "3 drei", "4 vier", "5 fünf"] },
              { h: "6 – 10", p: "", list: ["6 sechs", "7 sieben", "8 acht", "9 neun", "10 zehn"] },
              { h: "A small tip", p: "On the phone, **zwei** is often said as **zwo** so that it cannot be confused with **drei**. Both mean two." },
              { h: "Useful phrases", p: "", list: ["Wie viele? — how many?", "Ich bin zehn Jahre alt — I am ten years old", "Ich habe drei Bücher — I have three books"] }
            ],
            keyPoints: [
              "eins, zwei, drei, vier, fünf",
              "sechs, sieben, acht, neun, zehn",
              "Age uses sein: Ich bin zehn Jahre alt",
              "After 20, German says the units before the tens: einundzwanzig = one-and-twenty"
            ],
            example: {
              title: "Counting aloud",
              steps: ["eins, zwei, drei…", "vier, fünf, sechs…", "sieben, acht, neun, zehn !"]
            }
          },
          questions: [
            { q: "What is 'drei' in English?", options: ["Three", "Two", "Four", "Ten"], answer: 0, explain: "drei is three. zwei is two and vier is four." },
            { q: "How do you say 5 in German?", options: ["fünf", "vier", "sechs", "sieben"], answer: 0, explain: "5 is fünf. sechs is 6." },
            { q: "What does 'zehn' mean?", options: ["Ten", "Eight", "Two", "Six"], answer: 0, explain: "zehn is ten. acht is eight." },
            { q: "Which is the German word for 8?", options: ["acht", "neun", "sieben", "sechs"], answer: 0, explain: "acht is eight. neun is nine." },
            { q: "What does 'eins' mean?", options: ["One", "Nine", "Eleven", "Zero"], answer: 0, explain: "eins is one." },
            { q: "How do you say 'I am ten years old' in German?", options: ["Ich bin zehn Jahre alt", "Ich heiße zehn", "Mir geht es zehn", "Ich habe zehn"], answer: 0, explain: "German uses sein (to be) for age: Ich bin zehn Jahre alt." }
          ]
        }
      ]
    },

    {
      id: "spanish",
      name: "Spanish",
      tagline: "Start speaking Spanish: greetings and numbers.",
      color: "#f59e0b",
      icon: "chat",
      lessons: [
        {
          id: "greetings",
          title: "Greetings & Introductions",
          summary: "Say hello, introduce yourself and say goodbye in Spanish.",
          minutes: 8,
          explain: {
            intro: "Spanish greetings are warm and quick. **¡Hola!** works with anyone, anywhere, at any time of day.",
            sections: [
              { h: "Hello and goodbye", p: "", list: ["¡Hola! — hello", "Buenos días — good morning", "Buenas tardes — good afternoon", "Buenas noches — good evening / good night", "Adiós — goodbye", "Hasta luego — see you later", "Hasta mañana — see you tomorrow"] },
              { h: "Introducing yourself", p: "", list: ["¿Cómo te llamas? — what is your name? (informal)", "¿Cómo se llama? — what is your name? (formal)", "Me llamo… — my name is…", "Mucho gusto — nice to meet you"] },
              { h: "How are you?", p: "", list: ["¿Cómo estás? — how are you? (informal)", "¿Cómo está usted? — how are you? (formal)", "Estoy bien, gracias — I am well, thank you", "Más o menos — so-so"] },
              { h: "Being polite", p: "", list: ["Gracias — thank you", "Muchas gracias — thank you very much", "Por favor — please", "De nada — you are welcome", "Perdón — sorry", "Lo siento — I am sorry"] }
            ],
            keyPoints: [
              "¡Hola! works in any situation",
              "¿Cómo te llamas? → Me llamo…",
              "gracias = thank you, por favor = please",
              "The upside-down ¿ and ¡ open a question or an exclamation"
            ],
            example: {
              title: "A first conversation in Spanish",
              steps: ["A: ¡Hola! ¿Cómo te llamas?", "B: Me llamo Lucía. ¿Y tú?", "A: Me llamo Diego. Mucho gusto.", "B: ¿Cómo estás?", "A: Estoy bien, gracias. ¡Hasta luego!"]
            }
          },
          questions: [
            { q: "What does '¡Hola!' mean?", options: ["Hello", "Goodbye", "Thank you", "Please"], answer: 0, explain: "¡Hola! means hello and can be used at any time of day." },
            { q: "Which Spanish word means 'thank you'?", options: ["Gracias", "Por favor", "De nada", "Perdón"], answer: 0, explain: "Gracias is thank you. De nada means you are welcome." },
            { q: "How do you say 'My name is…' in Spanish?", options: ["Me llamo…", "¿Cómo te llamas?", "Estoy bien", "Mucho gusto"], answer: 0, explain: "Me llamo… literally means 'I call myself…'. The question is ¿Cómo te llamas?" },
            { q: "What does 'Buenos días' mean?", options: ["Good morning", "Good night", "See you later", "You are welcome"], answer: 0, explain: "Buenos días is good morning; buenas noches is good night." },
            { q: "What does '¿Cómo estás?' mean?", options: ["How are you?", "What is your name?", "Where are you?", "How old are you?"], answer: 0, explain: "¿Cómo estás? asks how someone is. The formal version is ¿Cómo está usted?" },
            { q: "Which mark opens a question in Spanish?", options: ["¿", "¡", "?", "!"], answer: 0, explain: "Spanish uses ¿ at the start of a question and ¡ at the start of an exclamation, as well as the normal closing marks." },
            { q: "What does 'Hasta luego' mean?", options: ["See you later", "Good morning", "Nice to meet you", "Please"], answer: 0, explain: "Hasta luego means see you later. Hasta mañana means see you tomorrow." }
          ]
        },
        {
          id: "numbers",
          title: "Numbers 1 – 10",
          summary: "Count from one to ten in Spanish.",
          minutes: 6,
          explain: {
            intro: "Spanish numbers from **uno** to **diez**. They are spoken exactly as they are written, which makes them quick to learn.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 uno — oo-no", "2 dos — dos", "3 tres — tres", "4 cuatro — kwah-tro", "5 cinco — seen-ko"] },
              { h: "6 – 10", p: "", list: ["6 seis — says", "7 siete — syeh-te", "8 ocho — o-cho", "9 nueve — nweh-ve", "10 diez — dyes"] },
              { h: "One small rule", p: "**uno** drops the -o in front of a masculine noun: un libro (one book). In front of a feminine noun it becomes **una**: una casa (one house)." },
              { h: "Useful phrases", p: "", list: ["¿Cuántos? — how many?", "Tengo diez años — I am ten years old (literally: I have ten years)", "Hay tres libros — there are three books"] }
            ],
            keyPoints: [
              "uno, dos, tres, cuatro, cinco",
              "seis, siete, ocho, nueve, diez",
              "uno → un before a masculine noun, una before a feminine one",
              "Age uses tener: Tengo diez años"
            ],
            example: {
              title: "Counting aloud",
              steps: ["uno, dos, tres…", "cuatro, cinco, seis…", "siete, ocho, nueve, diez !"]
            }
          },
          questions: [
            { q: "What is 'tres' in English?", options: ["Three", "Two", "Four", "Ten"], answer: 0, explain: "tres is three. dos is two and cuatro is four." },
            { q: "How do you say 5 in Spanish?", options: ["cinco", "cuatro", "seis", "siete"], answer: 0, explain: "5 is cinco. seis is 6." },
            { q: "What does 'diez' mean?", options: ["Ten", "Eight", "Two", "Six"], answer: 0, explain: "diez is ten. ocho is eight." },
            { q: "Which is the Spanish word for 8?", options: ["ocho", "nueve", "siete", "seis"], answer: 0, explain: "ocho is eight. nueve is nine." },
            { q: "What does 'uno' mean?", options: ["One", "Nine", "Eleven", "Zero"], answer: 0, explain: "uno is one. Before a masculine noun it shortens to un." },
            { q: "What does '¿Cuántos?' mean?", options: ["How many?", "How are you?", "Where?", "Why?"], answer: 0, explain: "¿Cuántos? asks how many. ¿Cuánto? asks how much." }
          ]
        }
      ]
    }
  ]
};
