/* LearnHub — French pack.
   Contains the interface strings and every lesson, written in French. */
window.PACKS = window.PACKS || {};
window.PACKS.fr = {
  code: "fr",
  name: "Français",
  dir: "ltr",

  ui: {
    appName: "LearnHub",
    taglineShort: "Apprenez tout",
    welcomeTitle: "Bienvenue sur LearnHub",
    welcomeSub: "Apprenez les maths, les sciences, les langues et bien plus. Chaque leçon explique d'abord l'idée, puis vous vous entraînez avec des questions.",
    pickLanguage: "Choisissez votre langue",
    yourName: "Comment devons-nous vous appeler ?",
    namePlaceholder: "Saisissez votre nom",
    pickAnimal: "Choisissez votre animal",
    startLearning: "Commencer à apprendre",
    needName: "Veuillez d'abord saisir un nom.",
    soundPreview: "Touchez un animal, puis touchez Commencer.",
    yourProfile: "Votre profil",
    yourNameLabel: "Nom",
    yourAnimal: "Votre animal",
    saveProfile: "Enregistrer",
    profileSaved: "Enregistré !",
    yourProgress: "Votre progression",
    lessonsDone: "Leçons terminées",
    starsEarned: "Étoiles gagnées",
    avgScore: "Score moyen",
    soundOn: "Effets sonores : activés",
    soundOff: "Effets sonores : désactivés",
    heroTitle: "Apprenez tout, un petit pas à la fois",
    heroLead: "Chaque leçon commence par une explication courte et claire — puis vous vous entraînez avec des questions. Bonne réponse, vous entendez un ding ; mauvaise réponse, le trombone triste retentit.",
    welcomeBack: "Bon retour, {name} !",
    continueLearning: "Continuer à apprendre",
    startLesson: "Commencer la leçon",
    allCaughtUp: "Vous avez terminé toutes les leçons",
    allCaughtUpBody: "Revenez sur n'importe quelle matière ci-dessous pour battre votre meilleur score.",
    chooseSubject: "Choisissez une matière",
    subjectsCount: "{n} matières",
    lessonsCount: "{n} leçons",
    ofComplete: "{done} sur {total} terminés",
    progressLabel: "Progression",
    allSubjects: "Toutes les matières",
    notStarted: "Non commencé",
    minRead: "{n} min de lecture",
    questionsCount: "{n} questions",
    stepExplain: "Explication",
    stepPractice: "Entraînement",
    readyButton: "Je suis prêt — commencer le quiz",
    readyHint: "Un ding signifie correct. Un womp womp womp signifie réessayez.",
    rememberThese: "À retenir",
    questionOf: "Question {i} sur {n}",
    scoreLabel: "Score {n}",
    streakLabel: "Série de {n} d'affilée",
    correctFeedback: "Correct !",
    wrongFeedback: "Pas tout à fait",
    inARow: "{n} d'affilée !",
    quizTip: "Astuce : appuyez sur 1–4 pour choisir, sur Entrée pour continuer.",
    nextQuestion: "Question suivante",
    seeResults: "Voir mes résultats",
    msgPerfect: "Un score parfait. Vous maîtrisez totalement cette leçon.",
    msgExcellent: "Excellent travail — presque parfait.",
    msgGood: "Bravo. Vous avez une solide compréhension.",
    msgOk: "Un bon début. Relisez l'explication une fois de plus, puis réessayez.",
    msgKeepGoing: "Continuez. Reprenez l'explication et réessayez — vous y arriverez.",
    pctCorrect: "{p}% de bonnes réponses",
    bestStreakLabel: "meilleure série de {n} d'affilée",
    prevBest: "meilleur précédent {b}/{t}",
    reviewTitle: "Revoir vos {n} erreurs",
    reviewTitleOne: "Revoir votre erreur",
    correctIs: "Correct :",
    youAnswered: "Vous avez répondu :",
    noMistakes: "Toutes les questions sont correctes — aucune erreur à revoir.",
    tryAgain: "Réessayer",
    backTo: "Retour à {subject}",
    nextLessonLabel: "Leçon suivante : {title}",
    soundToggle: "Effets sonores",
    backHome: "Accueil",
    langLabel: "Langue",
    closeLabel: "Fermer",
    editProfile: "Modifier le profil",
    switchHint: "Tout — les menus et chaque leçon — passe dans la langue que vous choisissez."
  },

  avatars: {
    cat: "Chat",
    dog: "Chien",
    fox: "Renard",
    panda: "Panda",
    owl: "Hibou",
    lion: "Lion",
    frog: "Grenouille",
    penguin: "Pingouin"
  },

  subjects: [
    {
      id: "math",
      name: "Mathématiques",
      tagline: "Fractions, algèbre et géométrie, expliquées étape par étape.",
      color: "#4f46e5",
      icon: "calculator",
      lessons: [
        {
          id: "fractions",
          title: "Les fractions",
          summary: "Lire, comparer, simplifier et additionner des fractions en toute confiance.",
          minutes: 8,
          explain: {
            intro: "Une fraction représente **une partie d'un tout**. Chaque fraction a deux parties : le **numérateur** (nombre du haut) et le **dénominateur** (nombre du bas).",
            sections: [
              { h: "Numérateur et dénominateur", p: "Le dénominateur indique en combien de parts égales le tout est découpé. Le numérateur indique combien de ces parts vous prenez. Dans 3/4, le tout est découpé en 4 parts et vous en prenez 3." },
              { h: "Fractions équivalentes", p: "Multiplier ou diviser le haut et le bas par le même nombre donne une **fraction équivalente** de valeur exactement identique.", list: ["1/2 = 2/4 = 4/8 = 50/100", "6/8 = 3/4  (divisez les deux termes par 2)", "10/15 = 2/3  (divisez les deux termes par 5)"] },
              { h: "Additionner des fractions", p: "Si les dénominateurs sont déjà identiques, additionnez les numérateurs et gardez le dénominateur. S'ils diffèrent, réécrivez d'abord les deux fractions avec un **dénominateur commun**.", list: ["1/4 + 2/4 = 3/4", "1/2 + 1/3 = 3/6 + 2/6 = 5/6"] },
              { h: "Comparer des fractions", p: "Réécrivez les deux fractions avec un dénominateur commun, puis comparez les numérateurs. 2/3 et 3/5 deviennent 10/15 et 9/15, donc **2/3 est la plus grande**." }
            ],
            keyPoints: [
              "Dénominateur = taille des parts, numérateur = nombre de parts que vous avez",
              "Simplifiez en divisant les deux termes par leur plus grand diviseur commun",
              "N'additionnez jamais les dénominateurs — seulement les numérateurs, une fois qu'ils sont identiques"
            ],
            example: {
              title: "Exemple guidé : 2/3 + 1/4",
              steps: ["Trouvez un dénominateur commun : 12", "Réécrivez : 2/3 = 8/12 et 1/4 = 3/12", "Additionnez les numérateurs : 8 + 3 = 11", "Réponse : 11/12"]
            }
          },
          questions: [
            { q: "Dans la fraction 3/4, quel nombre est le dénominateur ?", options: ["4", "3", "7", "12"], answer: 0, explain: "Le dénominateur est le nombre du bas, 4. Il indique que le tout est partagé en 4 parts égales." },
            { q: "Quelle fraction est équivalente à 1/2 ?", options: ["2/4", "2/3", "1/3", "3/5"], answer: 0, explain: "Multipliez le haut et le bas de 1/2 par 2 : 1/2 = 2/4. Même valeur, nombres différents." },
            { q: "Combien font 1/4 + 2/4 ?", options: ["3/4", "3/8", "2/8", "1/2"], answer: 0, explain: "Les dénominateurs sont identiques, donc additionnez les numérateurs (1 + 2 = 3) et gardez 4. La réponse est 3/4, pas 3/8." },
            { q: "Combien font 1/2 + 1/3 ?", options: ["5/6", "2/5", "1/5", "2/6"], answer: 0, explain: "Un dénominateur commun est 6 : 1/2 = 3/6 et 1/3 = 2/6. Ensuite 3/6 + 2/6 = 5/6." },
            { q: "Simplifiez 6/8.", options: ["3/4", "2/3", "1/2", "6/8"], answer: 0, explain: "Divisez les deux termes par leur plus grand diviseur commun, 2 : 6 ÷ 2 = 3 et 8 ÷ 2 = 4, ce qui donne 3/4." },
            { q: "Quelle fraction est la plus grande : 2/3 ou 3/5 ?", options: ["2/3", "3/5", "Elles sont égales", "On ne peut pas les comparer"], answer: 0, explain: "Avec un dénominateur commun de 15 : 2/3 = 10/15 et 3/5 = 9/15. Donc 2/3 est la plus grande." },
            { q: "Combien font 3/5 de 20 ?", options: ["12", "15", "8", "5"], answer: 0, explain: "Divisez par le dénominateur (20 ÷ 5 = 4), puis multipliez par le numérateur (4 × 3 = 12)." }
          ]
        },
        {
          id: "equations",
          title: "Résoudre des équations linéaires",
          summary: "Utilisez les opérations inverses pour trouver la valeur de x — et vérifiez votre réponse.",
          minutes: 9,
          explain: {
            intro: "Une équation est une **balance**. Les deux membres sont égaux, et votre tâche est de trouver la valeur de l'inconnue (souvent x) qui les garde égaux.",
            sections: [
              { h: "Gardez l'équilibre", p: "Tout ce que vous faites d'un côté, vous devez le faire de l'autre côté. Si vous soustrayez 3 à gauche, soustrayez aussi 3 à droite." },
              { h: "Opérations inverses", p: "Pour isoler x, annulez ce qui lui est fait en utilisant l'opération opposée.", list: ["+ annule −  et  − annule +", "× annule ÷  et  ÷ annule ×"] },
              { h: "L'ordre compte", p: "Annulez d'abord les **additions et les soustractions**, puis les multiplications et les divisions. C'est l'inverse de l'ordre habituel des opérations." },
              { h: "Vérifiez toujours", p: "Remplacez votre réponse dans l'équation de départ. Si les deux membres sont égaux, votre réponse est correcte." }
            ],
            keyPoints: [
              "Faites la même chose des deux côtés du signe égal",
              "Annulez + et − avant × et ÷",
              "Remplacez toujours la réponse dans l'équation de départ pour vérifier"
            ],
            example: {
              title: "Exemple guidé : 2x + 3 = 11",
              steps: ["Soustrayez 3 des deux côtés : 2x = 8", "Divisez les deux côtés par 2 : x = 4", "Vérification : 2(4) + 3 = 11 ✓"]
            }
          },
          questions: [
            { q: "Résolvez x + 5 = 12", options: ["7", "17", "−7", "5"], answer: 0, explain: "Soustrayez 5 des deux côtés : x = 12 − 5 = 7." },
            { q: "Résolvez 3x = 18", options: ["6", "15", "21", "3"], answer: 0, explain: "Divisez les deux côtés par 3 : x = 18 ÷ 3 = 6." },
            { q: "Résolvez 2x − 4 = 10", options: ["7", "3", "14", "6"], answer: 0, explain: "Ajoutez 4 des deux côtés : 2x = 14. Puis divisez par 2 : x = 7." },
            { q: "Résolvez x / 4 = 3", options: ["12", "7", "0,75", "4"], answer: 0, explain: "Multipliez les deux côtés par 4 : x = 3 × 4 = 12." },
            { q: "Résolvez 5x + 3 = 2x + 12", options: ["3", "5", "1", "9"], answer: 0, explain: "Soustrayez 2x des deux côtés : 3x + 3 = 12. Soustrayez 3 : 3x = 9. Divisez par 3 : x = 3." },
            { q: "Quelle opération annule la multiplication ?", options: ["La division", "L'addition", "La soustraction", "Le carré"], answer: 0, explain: "La division est l'inverse de la multiplication, donc diviser annule le fait de multiplier." },
            { q: "Si 4x = 2x + 10, que vaut x ?", options: ["5", "10", "2", "4"], answer: 0, explain: "Soustrayez 2x des deux côtés : 2x = 10, donc x = 5." }
          ]
        },
        {
          id: "area-perimeter",
          title: "Aire et périmètre",
          summary: "Mesurez la distance autour des figures et l'espace qu'elles contiennent.",
          minutes: 7,
          explain: {
            intro: "Le **périmètre** est la distance autour d'une figure, mesurée en unités ordinaires (cm, m). L'**aire** est la quantité d'espace à l'intérieur, mesurée en unités carrées (cm², m²).",
            sections: [
              { h: "Rectangle", p: "Aire = longueur × largeur.  Périmètre = 2 × (longueur + largeur)." },
              { h: "Carré", p: "Aire = côté².  Périmètre = 4 × côté, car les quatre côtés sont égaux." },
              { h: "Triangle", p: "Aire = ½ × base × hauteur. La hauteur doit être mesurée perpendiculairement à la base." },
              { h: "Cercle", p: "Circonférence (le périmètre) = 2πr.  Aire = πr², où r est le rayon — la moitié du diamètre." }
            ],
            keyPoints: [
              "Le périmètre est une longueur (cm) ; l'aire s'exprime en unités carrées (cm²)",
              "Les formules du cercle utilisent le rayon, pas le diamètre",
              "Pour un triangle, utilisez toujours la hauteur perpendiculaire"
            ],
            example: {
              title: "Un rectangle mesure 8 cm de long et 3 cm de large",
              steps: ["Aire = 8 × 3 = 24 cm²", "Périmètre = 2 × (8 + 3) = 22 cm"]
            }
          },
          questions: [
            { q: "Quelle est l'aire d'un rectangle de 5 cm sur 3 cm ?", options: ["15 cm²", "8 cm²", "16 cm²", "10 cm²"], answer: 0, explain: "Aire = longueur × largeur = 5 × 3 = 15 cm²." },
            { q: "Quel est le périmètre d'un carré de 6 cm de côté ?", options: ["24 cm", "36 cm", "12 cm", "30 cm"], answer: 0, explain: "Périmètre = 4 × côté = 4 × 6 = 24 cm." },
            { q: "Un triangle a une base de 10 cm et une hauteur de 6 cm. Quelle est son aire ?", options: ["30 cm²", "60 cm²", "16 cm²", "20 cm²"], answer: 0, explain: "Aire = ½ × base × hauteur = ½ × 10 × 6 = 30 cm²." },
            { q: "Quelle formule donne la circonférence d'un cercle ?", options: ["2πr", "πr²", "πr", "r²"], answer: 0, explain: "Circonférence = 2πr. La formule πr² donne l'aire à la place." },
            { q: "Quelle est l'aire d'un cercle de rayon 3 cm, en fonction de π ?", options: ["9π cm²", "6π cm²", "3π cm²", "36π cm²"], answer: 0, explain: "Aire = πr² = π × 3² = 9π cm²." },
            { q: "Quel est le périmètre d'un rectangle de 7 cm sur 4 cm ?", options: ["22 cm", "28 cm", "11 cm", "24 cm"], answer: 0, explain: "Périmètre = 2 × (7 + 4) = 2 × 11 = 22 cm. (28 cm² serait l'aire.)" }
          ]
        }
      ]
    },

    {
      id: "science",
      name: "Sciences",
      tagline: "Le cycle de l'eau, la photosynthèse et le système solaire.",
      color: "#0d9488",
      icon: "flask",
      lessons: [
        {
          id: "water-cycle",
          title: "Le cycle de l'eau",
          summary: "Comment l'eau voyage entre les océans, le ciel et la terre.",
          minutes: 7,
          explain: {
            intro: "L'eau sur Terre se déplace sans cesse entre le sol, l'air et les nuages dans une boucle appelée le **cycle de l'eau**. Cette même eau tourne en boucle depuis des milliards d'années.",
            sections: [
              { h: "1. Évaporation", p: "Le Soleil chauffe l'eau liquide des océans, des lacs et des rivières. Elle se transforme en un gaz invisible appelé **vapeur d'eau** et monte dans l'air." },
              { h: "2. Condensation", p: "En altitude, l'air est froid. La vapeur d'eau se refroidit et redevient de minuscules gouttelettes, qui se regroupent pour former des **nuages**." },
              { h: "3. Précipitation", p: "Quand les gouttelettes deviennent assez lourdes, elles tombent sous forme de **pluie, de neige, de grésil ou de grêle**." },
              { h: "4. Accumulation", p: "L'eau tombée s'accumule dans les rivières, les lacs et les océans, ou s'infiltre dans le sol, et le cycle recommence." },
              { h: "Transpiration", p: "Les plantes libèrent elles aussi de la vapeur d'eau par leurs feuilles. C'est ce qu'on appelle la **transpiration**, et cela ajoute encore de l'eau dans l'air." }
            ],
            keyPoints: [
              "Le Soleil est la source d'énergie qui anime tout le cycle",
              "Évaporation = liquide vers gaz ; condensation = gaz vers liquide",
              "Les précipitations sont toute eau qui tombe des nuages",
              "Ordre : évaporation → condensation → précipitation → accumulation"
            ],
            example: {
              title: "Pourquoi un verre froid transpire-t-il ?",
              steps: ["L'air chaud autour du verre contient de la vapeur d'eau", "La surface froide refroidit cette vapeur", "La vapeur se condense en gouttelettes liquides sur le verre", "C'est la condensation — le même processus qui forme les nuages"]
            }
          },
          questions: [
            { q: "Quel processus transforme l'eau liquide en vapeur d'eau ?", options: ["L'évaporation", "La condensation", "La précipitation", "L'accumulation"], answer: 0, explain: "L'évaporation transforme l'eau liquide en vapeur d'eau, le gaz, lorsqu'elle est chauffée." },
            { q: "Les nuages se forment quand la vapeur d'eau…", options: ["se condense en minuscules gouttelettes", "s'évapore dans l'air", "gèle dans l'océan", "s'infiltre dans le sol"], answer: 0, explain: "La vapeur qui se refroidit se condense sur les particules de poussière pour former les minuscules gouttelettes qui composent les nuages." },
            { q: "La pluie, la neige et la grêle sont toutes des exemples de…", options: ["précipitations", "condensation", "évaporation", "transpiration"], answer: 0, explain: "Les précipitations sont toute eau qui tombe des nuages jusqu'au sol." },
            { q: "Quelle est la principale source d'énergie qui anime le cycle de l'eau ?", options: ["Le Soleil", "La Lune", "Le vent", "Les volcans"], answer: 0, explain: "L'énergie solaire chauffe l'eau et provoque l'évaporation qui alimente tout le cycle." },
            { q: "La vapeur d'eau libérée par les feuilles des plantes s'appelle…", options: ["la transpiration", "l'évaporation", "la précipitation", "l'infiltration"], answer: 0, explain: "La transpiration est la libération de vapeur d'eau par les plantes, principalement par leurs feuilles." },
            { q: "Quel ordre du cycle de l'eau est correct ?", options: ["Évaporation → Condensation → Précipitation → Accumulation", "Condensation → Évaporation → Accumulation → Précipitation", "Précipitation → Accumulation → Condensation → Évaporation", "Accumulation → Précipitation → Évaporation → Condensation"], answer: 0, explain: "L'eau s'évapore, se condense en nuages, tombe en précipitations, puis s'accumule de nouveau." }
          ]
        },
        {
          id: "photosynthesis",
          title: "La photosynthèse",
          summary: "Comment les plantes vertes transforment la lumière du soleil en nourriture.",
          minutes: 8,
          explain: {
            intro: "La **photosynthèse** est le processus par lequel les plantes vertes fabriquent leur propre nourriture à partir de la lumière du soleil. C'est la raison pour laquelle nous avons de l'oxygène à respirer.",
            sections: [
              { h: "Les ingrédients", p: "Les plantes absorbent le **dioxyde de carbone** de l'air par de minuscules ouvertures de leurs feuilles appelées stomates, et l'**eau** du sol par leurs racines." },
              { h: "L'énergie", p: "La **chlorophylle** est le pigment vert contenu dans les chloroplastes. Elle capte l'énergie lumineuse et alimente la réaction." },
              { h: "Les produits", p: "La plante fabrique du **glucose**, un sucre qu'elle utilise pour son énergie et sa croissance, et libère de l'**oxygène** dans l'air comme sous-produit." },
              { h: "L'équation en mots", p: "dioxyde de carbone + eau + énergie lumineuse → glucose + oxygène. En symboles : 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂." }
            ],
            keyPoints: [
              "Besoins : dioxyde de carbone, eau, lumière du soleil et chlorophylle",
              "Produits : glucose et oxygène",
              "Se déroule dans les chloroplastes, surtout dans les feuilles",
              "Les plantes et les algues le font — les animaux ne le peuvent pas"
            ],
            example: {
              title: "Tester la photosynthèse",
              steps: ["Couvrez une partie d'une feuille pour que la lumière ne l'atteigne pas", "Laissez la plante au soleil pendant une journée", "Testez la feuille à l'iode — elle devient bleu-noir là où il y a de l'amidon", "Seule la partie non couverte devient sombre, ce qui prouve que la lumière est nécessaire"]
            }
          },
          questions: [
            { q: "Quel gaz les plantes absorbent-elles pour la photosynthèse ?", options: ["Le dioxyde de carbone", "L'oxygène", "L'azote", "L'hydrogène"], answer: 0, explain: "Les plantes absorbent le dioxyde de carbone par les stomates de leurs feuilles." },
            { q: "Quel gaz est libéré comme sous-produit de la photosynthèse ?", options: ["L'oxygène", "Le dioxyde de carbone", "Le méthane", "L'hélium"], answer: 0, explain: "L'oxygène est libéré comme déchet, ce qui est une chance pour nous." },
            { q: "Le pigment vert qui capte l'énergie lumineuse est…", options: ["la chlorophylle", "le carotène", "la mélanine", "l'hémoglobine"], answer: 0, explain: "La chlorophylle absorbe la lumière rouge et bleue et réfléchit le vert, c'est pourquoi les feuilles paraissent vertes." },
            { q: "Dans quelle partie de la cellule végétale la photosynthèse a-t-elle lieu ?", options: ["Le chloroplaste", "Le noyau", "La paroi cellulaire", "La vacuole"], answer: 0, explain: "Les chloroplastes contiennent la chlorophylle nécessaire pour capter l'énergie lumineuse." },
            { q: "Quel sucre est produit directement par la photosynthèse ?", options: ["Le glucose", "Le lactose", "Le sucralose", "Le maltose"], answer: 0, explain: "Le glucose est le sucre fabriqué pendant la photosynthèse ; il est stocké sous forme d'amidon." },
            { q: "La photosynthèse se produit principalement dans quelle partie de la plante ?", options: ["Les feuilles", "Les racines", "Les fleurs", "Les graines"], answer: 0, explain: "Les feuilles ont la plus grande surface et le plus de chloroplastes, donc c'est là que se déroule l'essentiel de la photosynthèse." }
          ]
        },
        {
          id: "solar-system",
          title: "Le système solaire",
          summary: "Huit planètes et les objets qui tournent autour de notre Soleil.",
          minutes: 6,
          explain: {
            intro: "Notre système solaire compte **8 planètes** en orbite autour du Soleil, maintenues par la gravité. Le Soleil contient plus de 99 % de toute la masse du système.",
            sections: [
              { h: "Les planètes internes", p: "Mercure, Vénus, la Terre et Mars sont des **planètes rocheuses (telluriques)** et sont les plus proches du Soleil." },
              { h: "Les planètes externes", p: "Jupiter, Saturne, Uranus et Neptune sont d'énormes **géantes gazeuses et de glace**, composées surtout d'hydrogène, d'hélium et de glaces." },
              { h: "D'autres objets", p: "La ceinture d'astéroïdes entre Mars et Jupiter, des centaines de lunes, des comètes et des planètes naines comme Pluton tournent aussi autour du Soleil." },
              { h: "Ordre à partir du Soleil", p: "Mercure, Vénus, la Terre, Mars, Jupiter, Saturne, Uranus, Neptune. Un moyen mnémotechnique : **Mon Vieux Tu M'as Jeté Sur Une Navette**." }
            ],
            keyPoints: [
              "Mercure est la plus proche du Soleil ; Neptune la plus éloignée",
              "Jupiter est la plus grande planète, Mercure la plus petite",
              "Pluton est une planète naine, pas une planète",
              "La Terre a un seul satellite naturel : la Lune"
            ],
            example: {
              title: "Comparer les tailles",
              steps: ["Le diamètre de Jupiter est d'environ 143 000 km", "Le diamètre de la Terre est d'environ 12 700 km", "Jupiter est environ 11 fois plus large que la Terre"]
            }
          },
          questions: [
            { q: "Quelle planète est la plus grande de notre système solaire ?", options: ["Jupiter", "Saturne", "La Terre", "Neptune"], answer: 0, explain: "Jupiter est la plus grande planète — environ 11 fois plus large que la Terre." },
            { q: "Quelle planète est la plus proche du Soleil ?", options: ["Mercure", "Vénus", "La Terre", "Mars"], answer: 0, explain: "Mercure est la planète la plus interne, en orbite au plus près du Soleil." },
            { q: "Laquelle de ces planètes n'est plus classée comme planète ?", options: ["Pluton", "Neptune", "Uranus", "Mars"], answer: 0, explain: "En 2006, Pluton a été reclassée comme planète naine car elle n'a pas nettoyé son orbite." },
            { q: "Quelle planète est appelée la planète rouge ?", options: ["Mars", "Vénus", "Jupiter", "Mercure"], answer: 0, explain: "Mars paraît rouge car sa surface est riche en oxyde de fer (rouille)." },
            { q: "Quelle planète est célèbre pour son système d'anneaux brillants ?", options: ["Saturne", "Mars", "Mercure", "Vénus"], answer: 0, explain: "Les anneaux de Saturne sont faits de glace et de particules rocheuses. Jupiter, Uranus et Neptune ont aussi de faibles anneaux." },
            { q: "Combien de planètes compte notre système solaire ?", options: ["8", "9", "7", "10"], answer: 0, explain: "Il y a 8 planètes : Mercure, Vénus, la Terre, Mars, Jupiter, Saturne, Uranus et Neptune." },
            { q: "Quel est le satellite naturel de la Terre ?", options: ["La Lune", "Phobos", "Titan", "Europe"], answer: 0, explain: "La Lune tourne autour de la Terre. Phobos tourne autour de Mars ; Titan et Europe tournent autour de Saturne et de Jupiter." }
          ]
        }
      ]
    },

    {
      id: "geography",
      name: "Géographie",
      tagline: "Les continents, les océans et les capitales du monde.",
      color: "#ea580c",
      icon: "globe",
      lessons: [
        {
          id: "continents",
          title: "Continents et océans",
          summary: "Les sept masses terrestres et les cinq océans de la planète Terre.",
          minutes: 6,
          explain: {
            intro: "La Terre compte **7 continents** — d'immenses étendues de terre continues — et **5 océans** qui couvrent environ 71 % de sa surface.",
            sections: [
              { h: "Les sept continents", p: "Du plus grand au plus petit par superficie : **Asie, Afrique, Amérique du Nord, Amérique du Sud, Antarctique, Europe, Australie (Océanie)**." },
              { h: "Les cinq océans", p: "Du plus grand au plus petit : **Pacifique, Atlantique, Indien, Austral (Antarctique), Arctique**." },
              { h: "Des records à connaître", p: "Plus grand continent : l'Asie. Plus petit : l'Australie. Plus grand océan : le Pacifique. L'endroit le plus profond de la Terre est la fosse des Mariannes, dans l'océan Pacifique, à environ 11 km de profondeur." },
              { h: "Un fait utile", p: "L'Afrique est le seul continent qui se trouve dans les quatre hémisphères — nord, sud, est et ouest." }
            ],
            keyPoints: [
              "7 continents, 5 océans",
              "L'Asie est le plus grand continent et l'Australie le plus petit",
              "Le Pacifique est l'océan le plus grand et le plus profond",
              "L'Afrique traverse l'équateur et les deux principaux méridiens"
            ],
            example: {
              title: "Où se trouve le Sahara ?",
              steps: ["Le Sahara est le plus grand désert chaud de la Terre", "Il couvre environ 9 millions de km²", "Il s'étend sur 11 pays", "Il se situe en Afrique du Nord, sur le continent africain"]
            }
          },
          questions: [
            { q: "Quel est le plus grand continent par superficie ?", options: ["L'Asie", "L'Afrique", "L'Europe", "L'Amérique du Nord"], answer: 0, explain: "L'Asie est le plus grand continent, couvrant environ 44 millions de km² et abritant la majeure partie de la population mondiale." },
            { q: "Combien y a-t-il de continents sur Terre ?", options: ["7", "5", "6", "8"], answer: 0, explain: "Il y a sept continents : l'Asie, l'Afrique, l'Amérique du Nord, l'Amérique du Sud, l'Antarctique, l'Europe et l'Australie." },
            { q: "Quel est le plus grand océan ?", options: ["Le Pacifique", "L'Atlantique", "L'Indien", "L'Arctique"], answer: 0, explain: "Le Pacifique est le plus grand et le plus profond des océans, couvrant environ un tiers de la planète." },
            { q: "Quel océan se trouve entre l'Afrique et les Amériques ?", options: ["L'Atlantique", "Le Pacifique", "L'Indien", "L'Austral"], answer: 0, explain: "L'océan Atlantique sépare l'Afrique et l'Europe des Amériques." },
            { q: "Sur quel continent se trouve le désert du Sahara ?", options: ["L'Afrique", "L'Asie", "L'Australie", "L'Amérique du Sud"], answer: 0, explain: "Le Sahara couvre une grande partie de l'Afrique du Nord." },
            { q: "Quel est le plus petit continent ?", options: ["L'Australie", "L'Europe", "L'Antarctique", "L'Amérique du Sud"], answer: 0, explain: "L'Australie (l'Océanie) est le plus petit continent par superficie." }
          ]
        },
        {
          id: "capitals",
          title: "Les capitales du monde",
          summary: "Les capitales que l'on confond le plus souvent.",
          minutes: 6,
          explain: {
            intro: "Chaque pays a une **capitale** — le siège de son gouvernement. Ce n'est pas toujours la ville la plus grande ou la plus connue du pays.",
            sections: [
              { h: "Des capitales bien connues", p: "", list: ["Égypte → Le Caire", "France → Paris", "Japon → Tokyo", "Italie → Rome", "Royaume-Uni → Londres"] },
              { h: "Celles que l'on confond", p: "", list: ["Émirats arabes unis → Abou Dabi (pas Dubaï)", "Turquie → Ankara (pas Istanbul)", "Australie → Canberra (pas Sydney)", "Canada → Ottawa (pas Toronto)", "Brésil → Brasília (pas Rio de Janeiro)", "États-Unis → Washington, D.C. (pas New York)", "Suisse → Berne (pas Zurich)"] },
              { h: "Pourquoi les capitales diffèrent des grandes villes", p: "Certaines capitales ont été construites exprès pour être un terrain neutre et pour répartir la richesse en dehors de la plus grande ville — Canberra, Brasília et Ottawa ont toutes été choisies pour cette raison." }
            ],
            keyPoints: [
              "La capitale est le siège du gouvernement, pas toujours la plus grande ville",
              "Émirats arabes unis → Abou Dabi, Turquie → Ankara, Brésil → Brasília",
              "Canberra, Brasília et Ottawa sont des capitales construites exprès"
            ],
            example: {
              title: "Comparer les Émirats arabes unis",
              steps: ["Dubaï est la ville la plus connue et un grand pôle économique", "La capitale est Abou Dabi", "C'est à Abou Dabi que siège le gouvernement fédéral", "Donc la réponse à « capitale des Émirats arabes unis » est Abou Dabi, pas Dubaï"]
            }
          },
          questions: [
            { q: "Quelle est la capitale de l'Égypte ?", options: ["Le Caire", "Alexandrie", "Gizeh", "Louxor"], answer: 0, explain: "Le Caire est la capitale de l'Égypte et la plus grande ville du monde arabe." },
            { q: "Quelle est la capitale du Japon ?", options: ["Tokyo", "Osaka", "Kyoto", "Sapporo"], answer: 0, explain: "Tokyo est la capitale du Japon depuis 1868." },
            { q: "Quelle est la capitale des Émirats arabes unis ?", options: ["Abou Dabi", "Dubaï", "Charjah", "Doha"], answer: 0, explain: "Abou Dabi est la capitale. Dubaï est la plus grande ville mais pas la capitale ; Doha est la capitale du Qatar." },
            { q: "Quelle est la capitale du Canada ?", options: ["Ottawa", "Toronto", "Vancouver", "Montréal"], answer: 0, explain: "Ottawa est la capitale. Toronto est la plus grande ville." },
            { q: "Quelle est la capitale du Brésil ?", options: ["Brasília", "Rio de Janeiro", "São Paulo", "Salvador"], answer: 0, explain: "Brasília a été construite exprès et est devenue la capitale en 1960." },
            { q: "Quelle est la capitale de l'Australie ?", options: ["Canberra", "Sydney", "Melbourne", "Perth"], answer: 0, explain: "Canberra est la capitale — choisie comme compromis entre les villes rivales de Sydney et Melbourne." },
            { q: "Quelle est la capitale de la France ?", options: ["Paris", "Lyon", "Marseille", "Nice"], answer: 0, explain: "Paris est la capitale et la plus grande ville de France." }
          ]
        }
      ]
    },

    {
      id: "computing",
      name: "Informatique",
      tagline: "Comment fonctionnent les ordinateurs et comment rester en sécurité en ligne.",
      color: "#0284c7",
      icon: "monitor",
      lessons: [
        {
          id: "computer-basics",
          title: "Comment fonctionnent les ordinateurs",
          summary: "Entrée, traitement, sortie, stockage — et matériel contre logiciel.",
          minutes: 7,
          explain: {
            intro: "Presque tous les ordinateurs suivent le même schéma : ils reçoivent une **entrée**, la **traitent**, produisent une **sortie** et peuvent **stocker** les résultats.",
            sections: [
              { h: "Entrée", p: "Les périphériques d'entrée envoient des données dans l'ordinateur.", list: ["clavier, souris, microphone, caméra, écran tactile, scanner"] },
              { h: "Traitement", p: "Le **processeur** (unité centrale de traitement) exécute les instructions — on l'appelle souvent le cerveau de l'ordinateur. Plus de cœurs et une fréquence d'horloge plus élevée signifient plus de travail accompli à la fois." },
              { h: "Sortie", p: "Les périphériques de sortie présentent les résultats.", list: ["écran, haut-parleurs, imprimante, casque"] },
              { h: "Stockage", p: "La **mémoire vive (RAM)** est très rapide mais temporaire — elle s'efface quand l'alimentation est coupée. Un **disque dur ou un SSD** conserve vos fichiers de façon permanente, même lorsque l'ordinateur est éteint." },
              { h: "Matériel contre logiciel", p: "Le **matériel** est l'équipement physique que l'on peut toucher (écran, processeur, clavier). Le **logiciel** est l'ensemble des programmes et des instructions (le système d'exploitation, un navigateur, un jeu)." }
            ],
            keyPoints: [
              "Processeur = le processeur, le cerveau de l'ordinateur",
              "RAM = mémoire rapide et temporaire ; SSD/disque dur = stockage permanent",
              "Le matériel se touche, le logiciel non",
              "Chaque tâche suit le schéma entrée → traitement → sortie"
            ],
            example: {
              title: "Suivre le schéma : taper une lettre",
              steps: ["Entrée : vous appuyez sur les touches du clavier", "Traitement : le processeur transforme les frappes en caractères", "Sortie : les lettres apparaissent à l'écran", "Stockage : vous enregistrez le fichier sur le SSD"]
            }
          },
          questions: [
            { q: "Lequel de ces éléments est un périphérique d'entrée ?", options: ["Le clavier", "L'écran", "L'imprimante", "Le haut-parleur"], answer: 0, explain: "Un clavier envoie des données dans l'ordinateur, c'est donc un périphérique d'entrée. Les autres sont des périphériques de sortie." },
            { q: "Que signifie CPU ?", options: ["Central Processing Unit (unité centrale de traitement)", "Computer Personal Unit", "Central Program Utility", "Control Panel Unit"], answer: 0, explain: "CPU signifie Central Processing Unit — la partie qui exécute les instructions." },
            { q: "Quel type de mémoire perd son contenu lorsque l'alimentation est coupée ?", options: ["La RAM", "Le SSD", "Le disque dur", "La clé USB"], answer: 0, explain: "La RAM est une mémoire volatile. Les SSD, les disques durs et les clés USB conservent les données sans alimentation." },
            { q: "Lequel de ces éléments est un logiciel ?", options: ["Un système d'exploitation", "Un clavier", "Une souris", "Un écran"], answer: 0, explain: "Un système d'exploitation est un programme, c'est donc un logiciel. Les autres sont du matériel physique." },
            { q: "Quel appareil produit une sortie ?", options: ["L'imprimante", "Le microphone", "Le scanner", "La souris"], answer: 0, explain: "Une imprimante affiche les résultats sur papier, c'est donc un périphérique de sortie." },
            { q: "Quel stockage conserve vos fichiers de façon permanente ?", options: ["Le SSD", "La RAM", "Le cache", "Les registres"], answer: 0, explain: "Un SSD (ou un disque dur) stocke les données de façon permanente, même lorsque l'ordinateur est éteint." }
          ]
        },
        {
          id: "online-safety",
          title: "Internet et sécurité en ligne",
          summary: "Mots de passe, hameçonnage et protection de vos données personnelles.",
          minutes: 8,
          explain: {
            intro: "Internet est puissant, mais tout ce que vous publiez et chaque mot de passe que vous tapez doivent être protégés. Quelques habitudes simples vous gardent en sécurité.",
            sections: [
              { h: "Des mots de passe solides", p: "Utilisez au moins 12 caractères mêlant majuscules, minuscules, chiffres et symboles. **Ne réutilisez jamais** le même mot de passe sur différents sites, et n'utilisez jamais votre nom ni votre date de naissance." },
              { h: "L'hameçonnage", p: "De faux e-mails, SMS ou sites qui se font passer pour authentiques afin de voler votre mot de passe ou vos coordonnées bancaires. Les signes d'alerte : l'urgence, les fautes d'orthographe, les adresses d'expéditeur étranges et les liens qui ne correspondent pas au vrai site." },
              { h: "L'authentification à deux facteurs (2FA)", p: "Ajoute une seconde preuve d'identité — souvent un code sur votre téléphone — afin qu'un mot de passe volé ne suffise pas à accéder à votre compte." },
              { h: "HTTPS et le cadenas", p: "Le cadenas dans la barre d'adresse signifie que la connexion est **chiffrée**. Ne tapez jamais un mot de passe sur une page qui en est dépourvue." },
              { h: "Les informations personnelles", p: "Ne partagez jamais votre nom complet, votre adresse, le nom de votre école ni vos photos avec des inconnus en ligne. Une fois quelque chose publié, il est très difficile de le retirer." }
            ],
            keyPoints: [
              "Des mots de passe longs et uniques — un gestionnaire de mots de passe aide",
              "Ne cliquez jamais sur les liens de messages inattendus",
              "Activez l'authentification à deux facteurs partout où elle est proposée",
              "Un cadenas (HTTPS) signifie que la connexion est chiffrée",
              "Gardez vos informations personnelles privées"
            ],
            example: {
              title: "Repérer un message d'hameçonnage",
              steps: ["Il dit que votre compte sera fermé dans 1 heure (urgence)", "L'adresse d'expéditeur est support@bank-secure-login.xyz (pas le vrai domaine)", "Le lien pointe ailleurs que vers le site de la banque", "Il vous demande de confirmer votre mot de passe en le tapant", "Conclusion : supprimez-le et signalez-le — ne cliquez pas"]
            }
          },
          questions: [
            { q: "Que signifie le « S » de HTTPS ?", options: ["Secure (sécurisé)", "Simple", "Server (serveur)", "Speed (vitesse)"], answer: 0, explain: "HTTPS signifie HyperText Transfer Protocol Secure — la connexion est chiffrée." },
            { q: "Qu'est-ce que l'hameçonnage ?", options: ["Un faux message qui tente de voler vos informations", "Un moyen d'accélérer Internet", "Un type de pare-feu", "Un moteur de recherche"], answer: 0, explain: "L'hameçonnage est une ruse qui se fait passer pour une organisation de confiance afin que vous livriez vos mots de passe ou vos coordonnées bancaires." },
            { q: "Quel mot de passe est le plus fort ?", options: ["Tr7#kL9!pQ2@", "password123", "votrenom2010", "12345678"], answer: 0, explain: "Il est long et mêle majuscules, minuscules, chiffres et symboles, ce qui le rend très difficile à deviner." },
            { q: "Qu'ajoute l'authentification à deux facteurs ?", options: ["Une seconde preuve d'identité, comme un code sur votre téléphone", "Un mot de passe plus long", "Une connexion Internet plus rapide", "Une adresse e-mail de secours"], answer: 0, explain: "La 2FA exige quelque chose que vous savez plus quelque chose que vous possédez, donc un mot de passe volé ne suffit pas." },
            { q: "Un message dit que vous avez gagné un prix et que vous devez cliquer sur un lien pour le réclamer. Que devez-vous faire ?", options: ["Le supprimer ou le signaler sans cliquer sur le lien", "Cliquer vite avant qu'il expire", "Répondre avec vos coordonnées bancaires", "Le transférer à tous vos amis"], answer: 0, explain: "C'est un appât d'hameçonnage classique. L'urgence et les prix sont les signes d'alerte — ne cliquez pas, supprimez-le ou signalez-le." },
            { q: "Que signifie une icône de cadenas dans la barre d'adresse ?", options: ["La connexion est chiffrée", "Le site est gratuit", "Le site est le plus rapide", "Le site appartient à un gouvernement"], answer: 0, explain: "Le cadenas montre que la connexion utilise HTTPS et est chiffrée, les données ne peuvent donc pas être facilement lues en transit." }
          ]
        }
      ]
    },

    {
      id: "arabic",
      name: "Arabe",
      tagline: "L'alphabet, les salutations du quotidien et les nombres de 1 à 10.",
      color: "#16a34a",
      icon: "book",
      lessons: [
        {
          id: "alphabet",
          title: "L'alphabet arabe",
          summary: "28 lettres, écrites de droite à gauche, qui changent de forme selon leur position.",
          minutes: 9,
          explain: {
            intro: "L'arabe (العربية) s'écrit de **droite à gauche** et utilise **28 lettres**. La plupart des lettres changent aussi légèrement de forme selon leur position dans le mot.",
            sections: [
              { h: "Les premières lettres", p: "Voici quelques lettres avec le son qu'elles produisent :", list: ["ا alif — a", "ب bā — b", "ت tā — t", "ث thā — th (comme dans l'anglais « think »)", "ج jīm — dj", "د dāl — d", "ر rā — r", "س sīn — s", "ش shīn — ch", "م mīm — m", "ن nūn — n", "ه hā — h", "ي yā — y"] },
              { h: "Les lettres changent de forme", p: "Une lettre a une forme **isolée**, une forme **initiale**, une forme **médiane** et une forme **finale**. La forme de base reste la même, mais la façon dont elle se lie change. Par exemple, ب s'écrit : ب (seule), بـ (au début), ـبـ (au milieu), ـب (à la fin)." },
              { h: "Les voyelles brèves (harakat)", p: "Les voyelles brèves s'écrivent avec de petits signes au-dessus ou au-dessous d'une lettre : une **fatha** (َ) donne un son « a », une **kasra** (ِ) donne « i » et une **damma** (ُ) donne « u ». Les livres pour enfants les indiquent toutes ; les textes pour adultes les omettent souvent." },
              { h: "Dans quel sens ça va ?", p: "Lisez les lettres une à une de droite à gauche, mais lisez les nombres de gauche à droite. Les chiffres arabes ١ ٢ ٣ s'écrivent dans le même ordre, de gauche à droite, que les chiffres français." }
            ],
            keyPoints: [
              "28 lettres, toujours écrites de droite à gauche",
              "Une lettre change de forme selon sa position dans le mot",
              "Les voyelles brèves s'écrivent avec des signes au-dessus ou au-dessous des lettres",
              "Les chiffres arabes s'écrivent de gauche à droite"
            ],
            example: {
              title: "Lire votre premier mot : كِتَاب (kitāb, livre)",
              steps: ["Commencez à droite : ك  = son k", "ت  = son t, avec une kasra (ِ) en dessous → kɪ", "ا  = ā long", "ب  = son b", "Lisez ensemble : كِتَاب = ki-tāb"]
            }
          },
          questions: [
            { q: "Combien de lettres compte l'alphabet arabe ?", options: ["28", "26", "29", "22"], answer: 0, explain: "L'alphabet arabe compte 28 lettres, commençant par alif (ا) et se terminant par yā (ي)." },
            { q: "Dans quel sens s'écrit l'arabe ?", options: ["De droite à gauche", "De gauche à droite", "De haut en bas", "Cela dépend du sujet"], answer: 0, explain: "L'arabe s'écrit et se lit de droite à gauche." },
            { q: "Quelle est la première lettre de l'alphabet arabe ?", options: ["ا (alif)", "ب (bā)", "م (mīm)", "ي (yā)"], answer: 0, explain: "Alif (ا) est la première lettre et yā (ي) la dernière." },
            { q: "Quel son produit la lettre ب ?", options: ["b", "m", "t", "n"], answer: 0, explain: "ب est bā et produit le son « b ». Attention : م produit « m » et ن produit « n »." },
            { q: "Laquelle de ces lettres est mīm ?", options: ["م", "ن", "ه", "ل"], answer: 0, explain: "م est mīm (m). ن est nūn (n), ه est hā (h) et ل est lām (l)." },
            { q: "Pourquoi les lettres arabes changent-elles de forme ?", options: ["Leur forme dépend de leur position dans le mot", "Elles ne changent jamais de forme", "Pour indiquer si le locuteur est un homme", "Pour indiquer le passé"], answer: 0, explain: "Les lettres ont des formes isolée, initiale, médiane et finale, selon leur place dans le mot." },
            { q: "Comment appelle-t-on les petits signes de voyelles placés au-dessus et au-dessous des lettres ?", options: ["Les harakat", "Les nombres", "Les lettres racines", "La ponctuation"], answer: 0, explain: "Les harakat sont les signes de voyelles brèves — fatha (َ), kasra (ِ) et damma (ُ)." }
          ]
        },
        {
          id: "greetings",
          title: "Salutations et présentations",
          summary: "Dites bonjour, demandez comment va quelqu'un et présentez-vous.",
          minutes: 8,
          explain: {
            intro: "Les salutations arabes sont généreuses — on en échange souvent plusieurs d'un coup. Voici les phrases que vous entendrez chaque jour.",
            sections: [
              { h: "Bonjour et bienvenue", p: "", list: ["السلام عليكم — as-salāmu ʿalaykum (que la paix soit sur vous)", "وعليكم السلام — wa ʿalaykumu s-salām (la réponse : que la paix soit aussi sur vous)", "مرحبا — marhaba (bonjour)", "أهلا وسهلا — ahlan wa sahlan (bienvenue)"] },
              { h: "Selon le moment de la journée", p: "", list: ["صباح الخير — sabāh al-khayr (bonjour / bon matin)", "مساء الخير — masāʾ al-khayr (bonsoir)"] },
              { h: "Demander et répondre", p: "", list: ["كيف حالك؟ — kayfa hāluk? (comment vas-tu ? — à un homme)", "كيف حالكِ؟ — kayfa hāluki? (à une femme)", "أنا بخير، شكرا — anā bi-khayr, shukran (je vais bien, merci)", "ما اسمك؟ — mā ismuk? (comment t'appelles-tu ?)", "اسمي… — ismī … (je m'appelle …)"] },
              { h: "Dire au revoir", p: "", list: ["شكرا — shukran (merci)", "عفوا — ʿafwan (de rien)", "مع السلامة — maʿa s-salāma (au revoir)"] }
            ],
            keyPoints: [
              "السلام عليكم est la salutation la plus courante — répondez وعليكم السلام",
              "مساء الخير s'utilise à partir de la fin de l'après-midi",
              "شكرا signifie merci et عفوا signifie de rien",
              "مع السلامة signifie au revoir"
            ],
            example: {
              title: "Une courte conversation",
              steps: ["A : السلام عليكم  (que la paix soit sur vous)", "B : وعليكم السلام  (et que la paix soit aussi sur vous)", "A : كيف حالك؟  (comment vas-tu ?)", "B : أنا بخير، شكرا  (je vais bien, merci)", "A : ما اسمك؟  (comment t'appelles-tu ?)", "B : اسمي نور  (je m'appelle Noor)"]
            }
          },
          questions: [
            { q: "Que signifie مرحبا (marhaba) ?", options: ["Bonjour", "Au revoir", "Merci", "Pardon"], answer: 0, explain: "مرحبا (marhaba) est une façon amicale de dire bonjour." },
            { q: "Comment dit-on « bonjour » (le matin) en arabe ?", options: ["صباح الخير", "مساء الخير", "مع السلامة", "شكرا"], answer: 0, explain: "صباح الخير (sabāh al-khayr) signifie bonjour le matin. مساء الخير signifie bonsoir." },
            { q: "Que signifie شكرا (shukran) ?", options: ["Merci", "S'il vous plaît", "Bonjour", "Oui"], answer: 0, explain: "شكرا signifie merci. Vous pouvez répondre par عفوا (de rien)." },
            { q: "Que signifie ما اسمك؟ (mā ismuk?) ?", options: ["Comment t'appelles-tu ?", "Quel âge as-tu ?", "D'où viens-tu ?", "Comment vas-tu ?"], answer: 0, explain: "ما اسمك؟ signifie littéralement « quel ton nom ? » — comment t'appelles-tu ?" },
            { q: "Si quelqu'un dit كيف حالك؟, quelle réponse convient le mieux ?", options: ["أنا بخير، شكرا", "مع السلامة", "صباح الخير", "ما اسمك؟"], answer: 0, explain: "كيف حالك؟ demande comment vous allez, donc أنا بخير، شكرا (je vais bien, merci) est la réponse naturelle." },
            { q: "Que signifie مع السلامة (maʿa s-salāma) ?", options: ["Au revoir", "Bienvenue", "Bonne nuit", "Merci"], answer: 0, explain: "مع السلامة signifie littéralement « avec la sécurité » et s'emploie pour dire au revoir." },
            { q: "Quelle salutation utiliseriez-vous quand un invité arrive chez vous ?", options: ["أهلا وسهلا", "مع السلامة", "شكرا", "اسمي"], answer: 0, explain: "أهلا وسهلا (ahlan wa sahlan) signifie bienvenue et s'utilise pour accueillir des invités." }
          ]
        },
        {
          id: "numbers",
          title: "Les nombres ١ – ١٠",
          summary: "Comptez de un à dix en arabe, en mots et en chiffres.",
          minutes: 6,
          explain: {
            intro: "L'arabe a ses propres chiffres — ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠ — qui s'écrivent **de gauche à droite**, même si la langue elle-même se lit de droite à gauche.",
            sections: [
              { h: "Les nombres ١ – ٥", p: "", list: ["١ واحد — wāhid (1)", "٢ اثنان — ithnān (2)", "٣ ثلاثة — thalātha (3)", "٤ أربعة — arbaʿa (4)", "٥ خمسة — khamsa (5)"] },
              { h: "Les nombres ٦ – ١٠", p: "", list: ["٦ ستة — sitta (6)", "٧ سبعة — sabʿa (7)", "٨ ثمانية — thamāniya (8)", "٩ تسعة — tisʿa (9)", "١٠ عشرة — ʿashara (10)"] },
              { h: "L'aspect des chiffres", p: "Remarquez que ٠ s'écrit comme un simple point, et que ١ ressemble à un 1 français en miroir. ٢ et ٣ sont des versions inversées l'un de l'autre, alors faites attention à ne pas les confondre." },
              { h: "Conseil de pratique", p: "Apprenez-les par paires : ١/٢, ٣/٤, ٥/٦, ٧/٨ et ٩/١٠. Répétez chaque paire à voix haute cinq fois et le rythme les fera retenir." }
            ],
            keyPoints: [
              "Chiffres arabes : ٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩",
              "Les nombres se lisent de gauche à droite",
              "خمسة (khamsa) c'est cinq, عشرة (ʿashara) c'est dix"
            ],
            example: {
              title: "Compter des objets",
              steps: ["كتاب واحد — kitāb wāhid (un livre)", "كتابان اثنان — kitābān ithnān (deux livres)", "ثلاثة كتب — thalātha kutub (trois livres)", "عشرة كتب — ʿashara kutub (dix livres)"]
            }
          },
          questions: [
            { q: "Quel est le chiffre arabe pour 5 ?", options: ["٥", "٤", "٦", "٥٠"], answer: 0, explain: "٥ c'est cinq, écrit khamsa (خمسة)." },
            { q: "Que signifie ثلاثة (thalātha) ?", options: ["Trois", "Quatre", "Deux", "Dix"], answer: 0, explain: "ثلاثة c'est trois. أربعة c'est quatre et اثنان c'est deux." },
            { q: "Comment s'écrit le nombre 7 en chiffres arabes ?", options: ["٧", "٦", "٩", "١٠"], answer: 0, explain: "٧ c'est 7 (sabʿa). ٦ c'est 6 et ٩ c'est 9." },
            { q: "Que signifie عشرة (ʿashara) ?", options: ["Dix", "Neuf", "Cinq", "Un"], answer: 0, explain: "عشرة c'est dix. تسعة c'est neuf et واحد c'est un." },
            { q: "Quel nombre est ٢ ?", options: ["Deux", "Un", "Trois", "Vingt"], answer: 0, explain: "٢ c'est deux — ithnān (اثنان)." },
            { q: "Que signifie خمسة (khamsa) ?", options: ["Cinq", "Six", "Sept", "Quatre"], answer: 0, explain: "خمسة c'est cinq. ستة c'est six et سبعة c'est sept." }
          ]
        }
      ]
    },

    {
      id: "english",
      name: "Anglais",
      tagline: "Les classes de mots, les temps verbaux et les expressions du quotidien.",
      color: "#e11d48",
      icon: "letter-a",
      lessons: [
        {
          id: "parts-of-speech",
          title: "Les classes de mots",
          summary: "Nommez le rôle que chaque mot joue dans une phrase.",
          minutes: 8,
          explain: {
            intro: "Chaque mot anglais appartient à une **classe grammaticale** — le rôle qu'il joue dans la phrase. Un même mot peut changer de classe selon la façon dont il est employé.",
            sections: [
              { h: "Nom (noun)", p: "Une personne, un lieu, une chose ou une idée.", list: ["teacher, Cairo, bicycle, freedom, happiness"] },
              { h: "Verbe (verb)", p: "Une action ou un état d'être.", list: ["run, write, is, believe, seem"] },
              { h: "Adjectif (adjective)", p: "Décrit un nom — de quel type, combien, lequel.", list: ["tall, clever, blue, three, expensive"] },
              { h: "Adverbe (adverb)", p: "Décrit un verbe, un adjectif ou un autre adverbe. Beaucoup se terminent par -ly.", list: ["quickly, very, yesterday, almost, here"] },
              { h: "Pronom (pronoun)", p: "Remplace un nom pour éviter de le répéter.", list: ["I, you, he, she, it, we, they, this, someone"] },
              { h: "Préposition (preposition)", p: "Exprime un rapport de lieu, de temps ou de direction.", list: ["in, on, under, at, between, during, with"] },
              { h: "Conjonction (conjunction)", p: "Relie des mots, des groupes de mots ou des propositions.", list: ["and, but, or, because, although, so"] }
            ],
            keyPoints: [
              "Demandez-vous « quel rôle ce mot joue-t-il ici ? » — c'est ce qui indique la classe grammaticale",
              "« Fast » peut être un adjectif (a fast car) ou un adverbe (he ran fast)",
              "Les adverbes se terminent souvent par -ly, mais pas toujours (very, soon, often)"
            ],
            example: {
              title: "Étiquetez la phrase : « The young boy ran quickly to school. »",
              steps: ["The — article", "young — adjectif (décrit boy)", "boy — nom", "ran — verbe", "quickly — adverbe (décrit ran)", "to — préposition", "school — nom"]
            }
          },
          questions: [
            { q: "Quel mot est le nom dans « The dog barked loudly » ?", options: ["dog", "barked", "loudly", "The"], answer: 0, explain: "Un chien est une chose, donc « dog » est le nom. « Barked » est le verbe et « loudly » l'adverbe." },
            { q: "Quel mot est l'adjectif dans « She wore a red hat » ?", options: ["red", "wore", "She", "hat"], answer: 0, explain: "« Red » décrit le nom « hat », c'est donc un adjectif." },
            { q: "Quel mot est le verbe dans « They played football yesterday » ?", options: ["played", "They", "football", "yesterday"], answer: 0, explain: "« Played » est l'action, c'est donc le verbe. « Yesterday » est un adverbe de temps." },
            { q: "Quel mot est l'adverbe dans « He ran quickly » ?", options: ["quickly", "ran", "He", "aucun de ceux-ci"], answer: 0, explain: "« Quickly » décrit la manière dont il a couru, c'est donc un adverbe." },
            { q: "Quel mot est le pronom dans « Sara said she was tired » ?", options: ["she", "Sara", "said", "tired"], answer: 0, explain: "« She » remplace le nom « Sara », c'est donc un pronom." },
            { q: "Quel mot est la préposition dans « The cat is under the table » ?", options: ["under", "cat", "is", "table"], answer: 0, explain: "« Under » exprime le rapport de lieu entre le chat et la table." },
            { q: "Quel mot est la conjonction dans « I like tea but not coffee » ?", options: ["but", "like", "tea", "not"], answer: 0, explain: "« But » relie les deux idées, c'est donc une conjonction." }
          ]
        },
        {
          id: "tenses",
          title: "Les temps verbaux",
          summary: "Passé, présent, futur, continu et parfait — comparés clairement.",
          minutes: 9,
          explain: {
            intro: "Le **temps** indique *quand* une action se produit. L'anglais marque le temps en modifiant le verbe, ou en ajoutant un auxiliaire comme be, have ou will.",
            sections: [
              { h: "Présent simple (present simple)", p: "Employé pour les faits, les habitudes et les routines. Ajoutez **-s** pour he, she et it.", list: ["I walk to school.", "She walks to school every day.", "Water boils at 100 °C."] },
              { h: "Présent continu (present continuous)", p: "Employé pour les actions en cours : **am / is / are + verbe-ing**.", list: ["I am reading a book.", "They are playing outside."] },
              { h: "Passé simple (past simple)", p: "Employé pour les actions terminées. Les verbes réguliers prennent **-ed** ; les verbes irréguliers changent complètement.", list: ["I walked home.", "He went to Cairo last year.", "go → went, eat → ate, see → saw"] },
              { h: "Futur simple (future simple)", p: "Employé pour les décisions et les prédictions : **will + verbe de base**.", list: ["I will call you tomorrow.", "It will rain later."] },
              { h: "Présent parfait (present perfect)", p: "Relie le passé au présent : **have / has + participe passé**.", list: ["I have eaten already.", "She has finished her homework."] }
            ],
            keyPoints: [
              "Le passé régulier = verbe + ed",
              "Les formes irrégulières du passé doivent être apprises (go → went, eat → ate)",
              "Ajoutez -s au présent simple pour he, she et it",
              "Continu = be + verbe-ing ; parfait = have + participe passé"
            ],
            example: {
              title: "Le même verbe dans cinq temps : « study »",
              steps: ["Présent simple : I study English", "Présent continu : I am studying English", "Passé simple : I studied English yesterday", "Futur simple : I will study English tomorrow", "Présent parfait : I have studied English for three years"]
            }
          },
          questions: [
            { q: "Quel est le passé simple de « go » ?", options: ["went", "goed", "gone", "going"], answer: 0, explain: "« Go » est irrégulier, donc le passé simple est « went ». « Gone » est le participe passé." },
            { q: "Complétez : She ___ to school every day.", options: ["goes", "go", "going", "gone"], answer: 0, explain: "Le présent simple avec he, she ou it prend un -s, donc « she goes »." },
            { q: "Complétez : They ___ football yesterday.", options: ["played", "play", "have played", "will play"], answer: 0, explain: "« Yesterday » renvoie à un temps révolu, donc le passé simple « played » est correct." },
            { q: "Complétez : I ___ you tomorrow.", options: ["will call", "called", "have called", "was calling"], answer: 0, explain: "« Tomorrow » exige une forme du futur, et « will call » est le futur simple." },
            { q: "Quelle phrase est au présent continu ?", options: ["I am reading a book", "I read a book", "I read a book yesterday", "I will read a book"], answer: 0, explain: "Le présent continu emploie am/is/are + verbe-ing : « I am reading »." },
            { q: "Quelle phrase emploie le présent parfait ?", options: ["She has finished her homework", "She finished her homework", "She is finishing her homework", "She finishes her homework"], answer: 0, explain: "« Has finished » est have/has + participe passé, c'est le présent parfait." },
            { q: "Quel est le passé simple de « eat » ?", options: ["ate", "eated", "eaten", "eating"], answer: 0, explain: "« Eat » est irrégulier : eat → ate → eaten. « Eaten » est le participe passé." }
          ]
        },
        {
          id: "idioms",
          title: "Vocabulaire et expressions",
          summary: "Des expressions courantes dont le sens n'est pas dans les mots.",
          minutes: 7,
          explain: {
            intro: "Les **expressions idiomatiques** sont des formules figées dont le sens n'apparaît pas clairement dans les mots pris séparément. Les apprendre rend votre anglais plus naturel.",
            sections: [
              { h: "Expressions du quotidien", p: "", list: ["break the ice — lancer la conversation dans une situation gênante", "a piece of cake — très facile", "hit the books — étudier sérieusement", "under the weather — se sentir mal", "once in a blue moon — très rarement", "cost an arm and a leg — coûter très cher"] },
              { h: "Dans une phrase", p: "", list: ["The exam was a piece of cake — I finished in ten minutes.", "He is a bit under the weather today, so he stayed home.", "We only see our cousins once in a blue moon."] },
              { h: "Enrichir son vocabulaire", p: "Apprenez un nouveau mot avec trois choses : son **sens**, une **phrase d'exemple**, et au moins un **synonyme ou son contraire**. Les mots appris ainsi restent en mémoire bien plus longtemps." }
            ],
            keyPoints: [
              "Les expressions idiomatiques ne se traduisent pas mot à mot",
              "Apprenez chaque expression dans une phrase d'exemple complète",
              "Servez-vous du contexte pour deviner le sens d'un mot inconnu"
            ],
            example: {
              title: "Deviner à partir du contexte",
              steps: ["Phrase : « That phone cost me an arm and a leg. »", "Les mots « arm » et « leg » n'ont pas de sens au sens propre", "La phrase parle de l'achat de quelque chose", "L'expression signifie donc que c'était très cher"]
            }
          },
          questions: [
            { q: "« The test was a piece of cake. » Le test était…", options: ["très facile", "très difficile", "délicieux", "très long"], answer: 0, explain: "« A piece of cake » signifie que quelque chose est très facile à faire." },
            { q: "Si vous êtes « under the weather », vous êtes…", options: ["malade", "dehors sous la pluie", "très heureux", "dans un avion"], answer: 0, explain: "« Under the weather » signifie se sentir un peu malade ou souffrant." },
            { q: "« Break the ice » signifie…", options: ["lancer la conversation dans une situation gênante", "casser quelque chose par accident", "aller patiner sur la glace", "se mettre en colère contre quelqu'un"], answer: 0, explain: "« Break the ice » signifie amorcer une conversation et mettre les gens à l'aise." },
            { q: "« Hit the books » signifie…", options: ["étudier sérieusement", "jeter des livres", "lire pour le plaisir", "acheter de nouveaux livres"], answer: 0, explain: "« Hit the books » signifie se mettre à étudier sérieusement." },
            { q: "« Once in a blue moon » signifie…", options: ["très rarement", "chaque nuit", "toujours", "jamais"], answer: 0, explain: "Une lune bleue est rare, l'expression signifie donc que quelque chose arrive très rarement." },
            { q: "Quel mot est un synonyme de « happy » ?", options: ["joyful", "angry", "tired", "quiet"], answer: 0, explain: "« Joyful » a le même sens que « happy ». Les autres sont sans rapport ou opposés." },
            { q: "Quel mot est le contraire de « ancient » ?", options: ["modern", "old", "historic", "antique"], answer: 0, explain: "« Ancient » signifie très ancien, donc « modern » (nouveau, actuel) est son contraire." }
          ]
        }
      ]
    },

    {
      id: "french",
      name: "Français",
      tagline: "Commencez à parler français : salutations et nombres.",
      color: "#2563eb",
      icon: "tower",
      lessons: [
        {
          id: "greetings",
          title: "Salutations et présentations",
          summary: "Dites bonjour, présentez-vous et dites au revoir en français.",
          minutes: 8,
          explain: {
            intro: "Les salutations françaises changent selon le degré de familiarité avec votre interlocuteur. **Bonjour** convient presque partout ; **salut** est réservé aux amis et à la famille.",
            sections: [
              { h: "Bonjour et au revoir", p: "", list: ["Bonjour — bonjour / bonne matinée (convient dans presque toutes les situations)", "Bonsoir — bonsoir / bonne soirée", "Salut — bonjour ou au revoir, mais seulement entre proches", "Au revoir — l'adieu poli et standard", "À bientôt — pour dire qu'on se reverra bientôt"] },
              { h: "Se présenter", p: "", list: ["Comment tu t'appelles ? — quelle est ton prénom ? (familier)", "Comment vous appelez-vous ? — quel est votre nom ? (formel)", "Je m'appelle… — mon nom est…", "Enchanté / Enchantée — formule de politesse quand on fait une connaissance"] },
              { h: "Comment ça va ?", p: "", list: ["Comment ça va ? / Ça va ? — pour demander des nouvelles", "Ça va bien, merci — la réponse positive", "Comme ci, comme ça — ni bien ni mal"] },
              { h: "La politesse", p: "", list: ["Merci — pour remercier", "Merci beaucoup — pour remercier chaleureusement", "S'il vous plaît — pour demander poliment (formel)", "De rien — réponse à un merci", "Excusez-moi — pour attirer l'attention poliment", "Pardon — pour s'excuser ou passer devant quelqu'un"] }
            ],
            keyPoints: [
              "« Bonjour » convient dans presque toutes les situations",
              "« Salut » est réservé aux amis et à la famille",
              "« Je m'appelle… » sert à donner son prénom",
              "« Merci » remercie et « s'il vous plaît » demande poliment"
            ],
            example: {
              title: "Une première conversation en français",
              steps: ["A: Bonjour ! Comment tu t'appelles ?", "B: Salut, je m'appelle Léa. Et toi ?", "A: Je m'appelle Sami. Enchanté !", "B: Enchantée ! Ça va ?", "A: Ça va bien, merci. Au revoir !"]
            }
          },
          questions: [
            { q: "Que signifie « Bonjour » ?", options: ["Bonjour / bonne matinée", "Au revoir", "Merci", "S'il vous plaît"], answer: 0, explain: "« Bonjour » est la salutation du matin et de la journée ; elle convient dans presque toutes les situations." },
            { q: "Quel mot sert à remercier ?", options: ["Merci", "Pardon", "Salut", "De rien"], answer: 0, explain: "« Merci » sert à remercier. « De rien » est la réponse à un merci." },
            { q: "Comment dit-on « je m'appelle… » en français ?", options: ["Je m'appelle…", "Comment tu t'appelles ?", "Ça va ?", "Au revoir"], answer: 0, explain: "« Je m'appelle… » signifie littéralement « je me nomme… ». La question correspondante est « Comment tu t'appelles ? »." },
            { q: "Quelle salutation est familière et s'emploie entre amis ?", options: ["Salut", "Bonsoir", "Bonjour", "Au revoir"], answer: 0, explain: "« Salut » est familier et sert à la fois à dire bonjour et au revoir — à réserver aux personnes que l'on connaît bien." },
            { q: "Que signifie « Comment ça va ? » ?", options: ["Pour demander comment on va", "Pour demander son nom", "Pour demander d'où l'on vient", "Pour demander son âge"], answer: 0, explain: "« Comment ça va ? » (ou simplement « Ça va ? ») sert à demander des nouvelles de quelqu'un." },
            { q: "Quelle expression sert à demander poliment ?", options: ["S'il vous plaît", "Merci", "De rien", "Excusez-moi"], answer: 0, explain: "« S'il vous plaît » sert à demander poliment. Avec un proche, on dit « s'il te plaît »." },
            { q: "Que signifie « Au revoir » ?", options: ["Au revoir", "Bonjour", "Bienvenue", "Bonsoir"], answer: 0, explain: "« Au revoir » est la formule d'adieu. « À bientôt » signifie qu'on se reverra bientôt." }
          ]
        },
        {
          id: "numbers",
          title: "Les nombres de 1 à 10",
          summary: "Comptez de un à dix en français et apprenez à dire votre âge.",
          minutes: 6,
          explain: {
            intro: "Les nombres français de **un** à **dix**. Attention à **un** et **une** — en français, les noms ont un genre, et le nombre doit s'accorder.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 un / une", "2 deux", "3 trois", "4 quatre", "5 cinq"] },
              { h: "6 – 10", p: "", list: ["6 six", "7 sept", "8 huit", "9 neuf", "10 dix"] },
              { h: "Phrases utiles", p: "", list: ["Combien ? — combien / quelle quantité ?", "J'ai dix ans — sert à donner son âge (littéralement : j'ai dix années)", "Il y a trois livres — il existe trois livres"] }
            ],
            keyPoints: [
              "un, deux, trois, quatre, cinq",
              "six, sept, huit, neuf, dix",
              "L'âge se dit avec le verbe avoir : J'ai dix ans",
              "La dernière lettre de cinq, huit et dix est souvent muette"
            ],
            example: {
              title: "Compter à voix haute",
              steps: ["un, deux, trois…", "quatre, cinq, six…", "sept, huit, neuf, dix !"]
            }
          },
          questions: [
            { q: "Quel nombre correspond à « trois » ?", options: ["3", "2", "4", "10"], answer: 0, explain: "« trois » = 3. « deux » = 2 et « quatre » = 4." },
            { q: "Comment dit-on 5 en français ?", options: ["cinq", "six", "sept", "quatre"], answer: 0, explain: "5 se dit « cinq ». 6 se dit « six »." },
            { q: "Que signifie « dix » ?", options: ["10", "8", "6", "2"], answer: 0, explain: "« dix » = 10. « huit » = 8 et « six » = 6." },
            { q: "Quel mot français désigne 8 ?", options: ["huit", "neuf", "sept", "six"], answer: 0, explain: "« huit » = 8. « neuf » = 9." },
            { q: "Que signifient « un / une » ?", options: ["1", "9", "11", "0"], answer: 0, explain: "« un » (masculin) et « une » (féminin) signifient tous deux 1." },
            { q: "Quelle phrase est correcte pour dire son âge ?", options: ["J'ai dix ans", "Je suis dix ans", "J'ai dix", "J'ai ans dix"], answer: 0, explain: "Le français emploie le verbe avoir pour l'âge : « J'ai dix ans » — littéralement « j'ai dix années »." }
          ]
        }
      ]
    },

    {
      id: "german",
      name: "Allemand",
      tagline: "Commencez à parler allemand : salutations et nombres.",
      color: "#7c3aed",
      icon: "flag",
      lessons: [
        {
          id: "greetings",
          title: "Salutations et présentations",
          summary: "Dites bonjour, présentez-vous et dites au revoir en allemand.",
          minutes: 8,
          explain: {
            intro: "L'allemand a une manière formelle et une manière familière de dire **vous** : **du** pour les amis et la famille, **Sie** pour tout le monde d'autre. Bien choisir compte.",
            sections: [
              { h: "Bonjour et au revoir", p: "", list: ["Hallo — bonjour", "Guten Morgen — bonjour (le matin)", "Guten Tag — bonjour (une grande partie de la journée)", "Guten Abend — bonsoir", "Gute Nacht — bonne nuit (avant de dormir)", "Tschüss — salut / bye (familier)", "Auf Wiedersehen — au revoir (formel)"] },
              { h: "Se présenter", p: "", list: ["Wie heißt du? — comment t'appelles-tu ? (familier)", "Wie heißen Sie? — comment vous appelez-vous ? (formel)", "Ich heiße… — je m'appelle…", "Ich bin… — je suis…", "Freut mich — enchanté"] },
              { h: "Comment ça va ?", p: "", list: ["Wie geht es dir? — comment vas-tu ? (familier)", "Wie geht es Ihnen? — comment allez-vous ? (formel)", "Mir geht es gut — je vais bien", "Es geht — ça va"] },
              { h: "Mots de politesse", p: "", list: ["Danke — merci", "Vielen Dank — merci beaucoup", "Bitte — s'il vous plaît / de rien", "Entschuldigung — excusez-moi / pardon", "Ja / Nein — oui / non"] }
            ],
            keyPoints: [
              "du = tu (familier), Sie = vous (formel)",
              "« Ich heiße… » signifie je m'appelle…",
              "« Bitte » signifie à la fois s'il vous plaît et de rien",
              "Tous les noms allemands s'écrivent avec une majuscule"
            ],
            example: {
              title: "Une première conversation en allemand",
              steps: ["A: Hallo! Wie heißt du?", "B: Ich heiße Anna. Und du?", "A: Ich bin Jonas. Freut mich!", "B: Freut mich. Wie geht es dir?", "A: Mir geht es gut, danke. Tschüss!"]
            }
          },
          questions: [
            { q: "Que signifie « Guten Morgen » ?", options: ["Bonjour (le matin)", "Bonne nuit", "Au revoir", "Merci"], answer: 0, explain: "« Guten Morgen » signifie bonjour le matin. « Gute Nacht » signifie bonne nuit." },
            { q: "Quel mot signifie « merci » ?", options: ["Danke", "Bitte", "Tschüss", "Hallo"], answer: 0, explain: "« Danke » signifie merci. « Bitte » signifie s'il vous plaît ou de rien." },
            { q: "Comment dit-on « je m'appelle… » ?", options: ["Ich heiße…", "Wie heißt du?", "Mir geht es gut", "Freut mich"], answer: 0, explain: "« Ich heiße… » signifie je m'appelle… ; « Wie heißt du? » est la question." },
            { q: "Quelle forme de « vous » emploie-t-on avec son professeur ?", options: ["Sie", "du", "dich", "dir"], answer: 0, explain: "On emploie « Sie » avec les personnes que l'on connaît peu, et « du » avec les amis et la famille." },
            { q: "Que signifie « Tschüss » ?", options: ["Au revoir (familier)", "Bonjour", "S'il vous plaît", "Pardon"], answer: 0, explain: "« Tschüss » est la façon familière de dire au revoir. « Auf Wiedersehen » est la forme formelle." },
            { q: "Que signifie « Bitte » ?", options: ["S'il vous plaît / de rien", "Merci", "Bonsoir", "Oui"], answer: 0, explain: "« Bitte » a un double emploi : s'il vous plaît quand on demande, et de rien quand on répond." }
          ]
        },
        {
          id: "numbers",
          title: "Les nombres de 1 à 10",
          summary: "Comptez de un à dix en allemand et apprenez à dire votre âge.",
          minutes: 6,
          explain: {
            intro: "Les nombres allemands de **eins** à **zehn**. L'allemand dit son âge avec le verbe **sein** : Ich bin zehn Jahre alt.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 eins", "2 zwei", "3 drei", "4 vier", "5 fünf"] },
              { h: "6 – 10", p: "", list: ["6 sechs", "7 sieben", "8 acht", "9 neun", "10 zehn"] },
              { h: "Un petit conseil", p: "Au téléphone, on dit souvent **zwo** à la place de **zwei**, afin de ne pas le confondre avec **drei**. Les deux signifient deux." },
              { h: "Phrases utiles", p: "", list: ["Wie viele? — combien ?", "Ich bin zehn Jahre alt — j'ai dix ans", "Ich habe drei Bücher — j'ai trois livres"] }
            ],
            keyPoints: [
              "eins, zwei, drei, vier, fünf",
              "sechs, sieben, acht, neun, zehn",
              "L'âge se dit avec sein : Ich bin zehn Jahre alt",
              "Après 20, l'allemand dit les unités avant les dizaines : einundzwanzig = un-et-vingt"
            ],
            example: {
              title: "Compter à voix haute",
              steps: ["eins, zwei, drei…", "vier, fünf, sechs…", "sieben, acht, neun, zehn !"]
            }
          },
          questions: [
            { q: "Que signifie « drei » ?", options: ["3", "2", "4", "10"], answer: 0, explain: "« drei » = 3. « zwei » = 2 et « vier » = 4." },
            { q: "Comment dit-on 5 en allemand ?", options: ["fünf", "vier", "sechs", "sieben"], answer: 0, explain: "5 se dit « fünf ». 6 se dit « sechs »." },
            { q: "Que signifie « zehn » ?", options: ["10", "8", "2", "6"], answer: 0, explain: "« zehn » = 10. « acht » = 8." },
            { q: "Quel mot allemand désigne 8 ?", options: ["acht", "neun", "sieben", "sechs"], answer: 0, explain: "« acht » = 8. « neun » = 9." },
            { q: "Que signifie « eins » ?", options: ["1", "9", "11", "0"], answer: 0, explain: "« eins » = 1." },
            { q: "Comment dit-on « j'ai dix ans » en allemand ?", options: ["Ich bin zehn Jahre alt", "Ich heiße zehn", "Mir geht es zehn", "Ich habe zehn"], answer: 0, explain: "L'allemand emploie le verbe « sein » (être) pour l'âge : Ich bin zehn Jahre alt." }
          ]
        }
      ]
    },

    {
      id: "spanish",
      name: "Espagnol",
      tagline: "Commencez à parler espagnol : salutations et nombres.",
      color: "#f59e0b",
      icon: "chat",
      lessons: [
        {
          id: "greetings",
          title: "Salutations et présentations",
          summary: "Dites bonjour, présentez-vous et dites au revoir en espagnol.",
          minutes: 8,
          explain: {
            intro: "Les salutations espagnoles sont chaleureuses et rapides. **¡Hola!** convient à tout le monde, partout, à toute heure de la journée.",
            sections: [
              { h: "Bonjour et au revoir", p: "", list: ["¡Hola! — bonjour / salut", "Buenos días — bonjour (le matin)", "Buenas tardes — bonjour (l'après-midi)", "Buenas noches — bonsoir / bonne nuit", "Adiós — au revoir", "Hasta luego — à plus tard", "Hasta mañana — à demain"] },
              { h: "Se présenter", p: "", list: ["¿Cómo te llamas? — comment t'appelles-tu ? (familier)", "¿Cómo se llama? — comment vous appelez-vous ? (formel)", "Me llamo… — je m'appelle…", "Mucho gusto — enchanté"] },
              { h: "Comment ça va ?", p: "", list: ["¿Cómo estás? — comment vas-tu ? (familier)", "¿Cómo está usted? — comment allez-vous ? (formel)", "Estoy bien, gracias — je vais bien, merci", "Más o menos — comme ci, comme ça"] },
              { h: "La politesse", p: "", list: ["Gracias — merci", "Muchas gracias — merci beaucoup", "Por favor — s'il vous plaît", "De nada — de rien", "Perdón — pardon", "Lo siento — je suis désolé"] }
            ],
            keyPoints: [
              "« ¡Hola! » convient dans toutes les situations",
              "¿Cómo te llamas? → Me llamo…",
              "gracias = merci, por favor = s'il vous plaît",
              "Les ¿ et ¡ inversés ouvrent une question ou une exclamation"
            ],
            example: {
              title: "Une première conversation en espagnol",
              steps: ["A: ¡Hola! ¿Cómo te llamas?", "B: Me llamo Lucía. ¿Y tú?", "A: Me llamo Diego. Mucho gusto.", "B: ¿Cómo estás?", "A: Estoy bien, gracias. ¡Hasta luego!"]
            }
          },
          questions: [
            { q: "Que signifie « ¡Hola! » ?", options: ["Bonjour / salut", "Au revoir", "Merci", "S'il vous plaît"], answer: 0, explain: "« ¡Hola! » signifie bonjour et peut s'employer à toute heure de la journée." },
            { q: "Quel mot espagnol signifie « merci » ?", options: ["Gracias", "Por favor", "De nada", "Perdón"], answer: 0, explain: "« Gracias » signifie merci. « De nada » signifie de rien." },
            { q: "Comment dit-on « je m'appelle… » en espagnol ?", options: ["Me llamo…", "¿Cómo te llamas?", "Estoy bien", "Mucho gusto"], answer: 0, explain: "« Me llamo… » signifie littéralement « je m'appelle… ». La question est « ¿Cómo te llamas? »." },
            { q: "Que signifie « Buenos días » ?", options: ["Bonjour (le matin)", "Bonne nuit", "À plus tard", "De rien"], answer: 0, explain: "« Buenos días » signifie bonjour le matin ; « buenas noches » signifie bonne nuit." },
            { q: "Que signifie « ¿Cómo estás? » ?", options: ["Comment vas-tu ?", "Comment t'appelles-tu ?", "Où es-tu ?", "Quel âge as-tu ?"], answer: 0, explain: "« ¿Cómo estás? » demande comment va quelqu'un. La version formelle est « ¿Cómo está usted? »." },
            { q: "Quel signe ouvre une question en espagnol ?", options: ["¿", "¡", "?", "!"], answer: 0, explain: "L'espagnol emploie « ¿ » au début d'une question et « ¡ » au début d'une exclamation, en plus des signes de fermeture habituels." },
            { q: "Que signifie « Hasta luego » ?", options: ["À plus tard", "Bonjour (le matin)", "Enchanté", "S'il vous plaît"], answer: 0, explain: "« Hasta luego » signifie à plus tard. « Hasta mañana » signifie à demain." }
          ]
        },
        {
          id: "numbers",
          title: "Les nombres de 1 à 10",
          summary: "Comptez de un à dix en espagnol.",
          minutes: 6,
          explain: {
            intro: "Les nombres espagnols de **uno** à **diez**. Ils se prononcent exactement comme ils s'écrivent, ce qui les rend rapides à apprendre.",
            sections: [
              { h: "1 – 5", p: "", list: ["1 uno", "2 dos", "3 tres", "4 cuatro", "5 cinco"] },
              { h: "6 – 10", p: "", list: ["6 seis", "7 siete", "8 ocho", "9 nueve", "10 diez"] },
              { h: "Une petite règle", p: "**uno** perd le -o devant un nom masculin : un libro (un livre). Devant un nom féminin, il devient **una** : una casa (une maison)." },
              { h: "Phrases utiles", p: "", list: ["¿Cuántos? — combien ?", "Tengo diez años — j'ai dix ans (littéralement : j'ai dix années)", "Hay tres libros — il y a trois livres"] }
            ],
            keyPoints: [
              "uno, dos, tres, cuatro, cinco",
              "seis, siete, ocho, nueve, diez",
              "uno → un devant un nom masculin, una devant un nom féminin",
              "L'âge se dit avec tener : Tengo diez años"
            ],
            example: {
              title: "Compter à voix haute",
              steps: ["uno, dos, tres…", "cuatro, cinco, seis…", "siete, ocho, nueve, diez !"]
            }
          },
          questions: [
            { q: "Que signifie « tres » ?", options: ["3", "2", "4", "10"], answer: 0, explain: "« tres » = 3. « dos » = 2 et « cuatro » = 4." },
            { q: "Comment dit-on 5 en espagnol ?", options: ["cinco", "cuatro", "seis", "siete"], answer: 0, explain: "5 se dit « cinco ». 6 se dit « seis »." },
            { q: "Que signifie « diez » ?", options: ["10", "8", "2", "6"], answer: 0, explain: "« diez » = 10. « ocho » = 8." },
            { q: "Quel mot espagnol désigne 8 ?", options: ["ocho", "nueve", "siete", "seis"], answer: 0, explain: "« ocho » = 8. « nueve » = 9." },
            { q: "Que signifie « uno » ?", options: ["1", "9", "11", "0"], answer: 0, explain: "« uno » = 1. Devant un nom masculin, il se raccourcit en « un »." },
            { q: "Que signifie « ¿Cuántos? » ?", options: ["Combien ?", "Comment vas-tu ?", "Où ?", "Pourquoi ?"], answer: 0, explain: "« ¿Cuántos? » demande combien. « ¿Cuánto? » demande quelle quantité." }
          ]
        }
      ]
    }
  ]
};
