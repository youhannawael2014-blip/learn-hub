/* LearnHub sound effects — generated live with the Web Audio API (no audio files needed). */
window.Sfx = (function () {
  'use strict';

  var ctx = null;
  var master = null;
  var enabled = true;

  function audio() {
    if (!ctx) {
      var Ctor = window.AudioContext || window.webkitAudioContext;
      if (!Ctor) return null;
      ctx = new Ctor();
    }
    if (ctx.state === 'suspended' && ctx.resume) ctx.resume();
    return ctx;
  }

  function output(c) {
    if (!master) {
      master = c.createGain();
      master.gain.value = 0.62;
      master.connect(c.destination);
    }
    return master;
  }

  /* One bell partial: short attack, long exponential decay. */
  function bellPartial(c, at, freq, level, dur) {
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, at);
    gain.gain.setValueAtTime(0.0001, at);
    gain.gain.linearRampToValueAtTime(level, at + 0.006);
    gain.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    osc.connect(gain);
    gain.connect(output(c));
    osc.start(at);
    osc.stop(at + dur + 0.05);
  }

  /* Correct answer: a bright rising "ting". */
  function playCorrect() {
    var c = audio();
    if (!c) return;
    var t = c.currentTime;
    bellPartial(c, t, 1567.98, 0.30, 0.85);            // G6
    bellPartial(c, t + 0.07, 2093.00, 0.22, 0.95);     // C7
    bellPartial(c, t + 0.07, 3135.96, 0.07, 0.70);     // G7 shimmer
  }

  /* One "womp": a brassy note that sags in pitch, with a wah filter sweep. */
  function womp(c, at, freq, dur) {
    var osc = c.createOscillator();
    var gain = c.createGain();
    var lp = c.createBiquadFilter();
    var lfo = c.createOscillator();
    var lfoGain = c.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq * 1.07, at);
    osc.frequency.linearRampToValueAtTime(freq, at + dur * 0.22);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.85, at + dur);

    lfo.type = 'sine';
    lfo.frequency.value = 6.5;
    lfoGain.gain.value = freq * 0.014;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    lp.type = 'lowpass';
    lp.Q.value = 7;
    lp.frequency.setValueAtTime(1400, at);
    lp.frequency.exponentialRampToValueAtTime(300, at + dur);

    gain.gain.setValueAtTime(0.0001, at);
    gain.gain.linearRampToValueAtTime(0.32, at + 0.03);
    gain.gain.setValueAtTime(0.32, at + dur * 0.55);
    gain.gain.exponentialRampToValueAtTime(0.0001, at + dur);

    osc.connect(lp);
    lp.connect(gain);
    gain.connect(output(c));

    osc.start(at);
    osc.stop(at + dur + 0.05);
    lfo.start(at);
    lfo.stop(at + dur + 0.05);
  }

  /* Wrong answer: the sad three-note "womp womp womp" descent. */
  function playWrong() {
    var c = audio();
    if (!c) return;
    var t = c.currentTime;
    var dur = 0.30;
    var notes = [233.08, 207.65, 185.00]; // Bb3, Ab3, Gb3
    for (var i = 0; i < notes.length; i++) {
      womp(c, t + i * (dur + 0.025), notes[i], dur);
    }
  }

  return {
    correct: function () { if (enabled) playCorrect(); },
    wrong: function () { if (enabled) playWrong(); },
    setEnabled: function (v) { enabled = !!v; },
    isEnabled: function () { return enabled; },
    unlock: function () { audio(); }
  };
})();
