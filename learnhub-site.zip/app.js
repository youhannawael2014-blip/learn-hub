/* LearnHub — app logic: language packs, animal-profile onboarding, routing, views, quiz flow. */
(function () {
  'use strict';

  /* ================================================================== *
   * 1. Languages, profile & progress storage
   * ================================================================== */

  var LANGS = ['en', 'ar', 'fr', 'de'];
  var DEFAULT_LANG = 'en';
  var K_PROGRESS = 'learnhub.progress.v1';
  var K_PROFILE = 'learnhub.profile.v1';

  var PACKS = window.PACKS || {};
  var progress = loadProgress();
  var profile = loadProfile();

  function loadProgress() {
    var fresh = { lessons: {}, sound: true };
    try {
      var raw = window.localStorage.getItem(K_PROGRESS);
      if (!raw) return fresh;
      var d = JSON.parse(raw);
      return { lessons: d.lessons || {}, sound: d.sound !== false };
    } catch (e) { return fresh; }
  }
  function saveProgress() {
    try { window.localStorage.setItem(K_PROGRESS, JSON.stringify(progress)); } catch (e) { /* unavailable */ }
  }

  function loadProfile() {
    var fresh = { name: '', avatar: 'cat', lang: DEFAULT_LANG };
    try {
      var raw = window.localStorage.getItem(K_PROFILE);
      if (!raw) return fresh;
      var d = JSON.parse(raw);
      return {
        name: typeof d.name === 'string' ? d.name : '',
        avatar: typeof d.avatar === 'string' ? d.avatar : 'cat',
        lang: PACKS[d.lang] ? d.lang : DEFAULT_LANG
      };
    } catch (e) { return fresh; }
  }
  function saveProfile() {
    try { window.localStorage.setItem(K_PROFILE, JSON.stringify(profile)); } catch (e) { /* unavailable */ }
  }

  var EMPTY_PACK = { ui: {}, subjects: [], avatars: {}, dir: 'ltr' };
  function pack() { return PACKS[profile.lang] || PACKS[DEFAULT_LANG] || EMPTY_PACK; }
  function enPack() { return PACKS[DEFAULT_LANG] || EMPTY_PACK; }

  /* ================================================================== *
   * 2. Translation helpers
   * ================================================================== */

  function lookup(lang, key) {
    var p = PACKS[lang];
    var u = p && p.ui;
    return (u && Object.prototype.hasOwnProperty.call(u, key)) ? u[key] : null;
  }
  function fill(str, vars) {
    return String(str).replace(/\{(\w+)\}/g, function (m, k) {
      return Object.prototype.hasOwnProperty.call(vars, k) ? String(vars[k]) : m;
    });
  }
  /* Current language first, then English, then the raw key name. */
  function t(key, vars) {
    var s = lookup(profile.lang, key);
    if (s === null || s === undefined) s = lookup(DEFAULT_LANG, key);
    if (s === null || s === undefined) s = key;
    return vars ? fill(s, vars) : s;
  }

  function subjects() { return pack().subjects || []; }
  function subjectById(id) {
    var list = subjects();
    for (var i = 0; i < list.length; i++) { if (list[i].id === id) return list[i]; }
    return null;
  }
  function lessonById(s, lessonId) {
    for (var i = 0; i < s.lessons.length; i++) { if (s.lessons[i].id === lessonId) return s.lessons[i]; }
    return null;
  }

  /* ================================================================== *
   * 3. Icons & animal avatars
   * ================================================================== */

  var ICONS = {
    calculator: '<rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7.5h7"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/>',
    flask: '<path d="M9 3h6"/><path d="M10 3v6.2L5.6 17.4A2 2 0 0 0 7.4 20.5h9.2a2 2 0 0 0 1.8-3.1L14 9.2V3"/><path d="M7.6 14.5h8.8"/>',
    book: '<path d="M4.5 5.2A2 2 0 0 1 6.5 3.2H19v17.6H6.5a2 2 0 0 0-2 2z"/><path d="M9 3.2v17.6"/>',
    "letter-a": '<path d="M5 20 12 4l7 16"/><path d="M8.2 14.2h7.6"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.6 3.1 2.6 14.9 0 18"/><path d="M12 3c-2.6 3.1-2.6 14.9 0 18"/>',
    monitor: '<rect x="3" y="4" width="18" height="12.5" rx="2.2"/><path d="M8.5 20.5h7"/><path d="M12 16.5v4"/>',
    tower: '<path d="M12 3v2.5"/><path d="M8.8 5.5h6.4"/><path d="M8 5.5 5.8 21M16 5.5 18.2 21"/><path d="M7.2 13h9.6"/><path d="M6.6 17.2h10.8"/>',
    flag: '<path d="M6.5 21.5V3"/><path d="M6.5 4.4h12.2l-2.2 4.2 2.2 4.2H6.5"/>',
    chat: '<path d="M20 14.2a1.8 1.8 0 0 1-1.8 1.8H10l-6 4.2V5.8A1.8 1.8 0 0 1 5.8 4h12.4A1.8 1.8 0 0 1 20 5.8Z"/>'
  };
  var STAR = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2.6l2.9 5.9 6.5.95-4.7 4.6 1.1 6.5L12 17.5 6.2 20.5l1.1-6.5-4.7-4.6 6.5-.95L12 2.6z"/></svg>';
  var ARROW_LEFT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>';
  var BRAND_MARK = '<span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 7.5 12 12l9.5-4.5L12 3Z"/><path d="M6 10.2V15c0 1.6 2.7 3 6 3s6-1.4 6-3v-4.8"/></svg></span>';

  function icon(name) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      (ICONS[name] || ICONS.book) + '</svg>';
  }

  /* Twelve petals of mane, generated once. */
  function lionMane() {
    var out = '';
    for (var i = 0; i < 12; i++) {
      var a = (i / 12) * Math.PI * 2;
      out += '<circle cx="' + (32 + Math.cos(a) * 19).toFixed(1) +
        '" cy="' + (34 + Math.sin(a) * 19).toFixed(1) + '" r="7.5" fill="#b45309"/>';
    }
    return out;
  }

  var AVATARS = {
    cat: '<path d="M13 25 L16.5 7 L32 18.5 Z" fill="#f59e0b"/>' +
      '<path d="M51 25 L47.5 7 L32 18.5 Z" fill="#f59e0b"/>' +
      '<path d="M17.5 22 L19.5 12 L28 18 Z" fill="#fde68a"/>' +
      '<path d="M46.5 22 L44.5 12 L36 18 Z" fill="#fde68a"/>' +
      '<path d="M6 37h8M6 42.5h8M50 37h8M50 42.5h8" stroke="#e0a24a" stroke-width="1.7" stroke-linecap="round"/>' +
      '<circle cx="32" cy="37" r="19" fill="#f59e0b"/>' +
      '<circle cx="25" cy="34.5" r="3.4" fill="#3b2314"/>' +
      '<circle cx="39" cy="34.5" r="3.4" fill="#3b2314"/>' +
      '<circle cx="26.1" cy="33.4" r="1.1" fill="#fff"/>' +
      '<circle cx="40.1" cy="33.4" r="1.1" fill="#fff"/>' +
      '<path d="M32 42.5l2.9 2.6-2.9 2.6-2.9-2.6Z" fill="#f472b6"/>' +
      '<path d="M32 47.7v2.6" stroke="#3b2314" stroke-width="1.8" stroke-linecap="round"/>' +
      '<path d="M32 50.3q-4 3.4-6.6.4M32 50.3q4 3.4 6.6.4" fill="none" stroke="#3b2314" stroke-width="1.8" stroke-linecap="round"/>',

    dog: '<ellipse cx="12.5" cy="31" rx="7.5" ry="14" fill="#92400e"/>' +
      '<ellipse cx="51.5" cy="31" rx="7.5" ry="14" fill="#92400e"/>' +
      '<ellipse cx="32" cy="35" rx="19" ry="18" fill="#d97706"/>' +
      '<ellipse cx="32" cy="43" rx="13" ry="11" fill="#fde68a"/>' +
      '<ellipse cx="32" cy="37.5" rx="5" ry="3.8" fill="#3b2314"/>' +
      '<path d="M32 41.5v3.4" stroke="#3b2314" stroke-width="1.8" stroke-linecap="round"/>' +
      '<path d="M32 45q-4.6 4.4-8 .6M32 45q4.6 4.4 8 .6" fill="none" stroke="#3b2314" stroke-width="1.8" stroke-linecap="round"/>' +
      '<circle cx="23" cy="30" r="3.3" fill="#2b1a0e"/>' +
      '<circle cx="41" cy="30" r="3.3" fill="#2b1a0e"/>' +
      '<circle cx="24" cy="29" r="1.1" fill="#fff"/>' +
      '<circle cx="42" cy="29" r="1.1" fill="#fff"/>',

    fox: '<path d="M12.5 21 L16 4 L34 16 Z" fill="#ea580c"/>' +
      '<path d="M51.5 21 L48 4 L30 16 Z" fill="#ea580c"/>' +
      '<path d="M17 19 L18.8 9 L28.5 15.6 Z" fill="#7c2d12"/>' +
      '<path d="M47 19 L45.2 9 L35.5 15.6 Z" fill="#7c2d12"/>' +
      '<circle cx="32" cy="36" r="18.5" fill="#ea580c"/>' +
      '<ellipse cx="32" cy="45" rx="10.5" ry="8.5" fill="#fff7ed"/>' +
      '<ellipse cx="32" cy="42" rx="3.4" ry="2.6" fill="#3b2314"/>' +
      '<path d="M32 44.6v2.8" stroke="#3b2314" stroke-width="1.7" stroke-linecap="round"/>' +
      '<path d="M32 47.4q-3.6 3-6.2.4M32 47.4q3.6 3 6.2.4" fill="none" stroke="#3b2314" stroke-width="1.7" stroke-linecap="round"/>' +
      '<circle cx="24" cy="32" r="3.2" fill="#2b1a0e"/>' +
      '<circle cx="40" cy="32" r="3.2" fill="#2b1a0e"/>',

    panda: '<circle cx="15" cy="17" r="9" fill="#1f2937"/>' +
      '<circle cx="49" cy="17" r="9" fill="#1f2937"/>' +
      '<circle cx="32" cy="35" r="19.5" fill="#ffffff"/>' +
      '<circle cx="32" cy="35" r="19.5" fill="none" stroke="#e5e7eb" stroke-width="1.5"/>' +
      '<ellipse cx="23" cy="33" rx="6.6" ry="8.2" fill="#1f2937" transform="rotate(-20 23 33)"/>' +
      '<ellipse cx="41" cy="33" rx="6.6" ry="8.2" fill="#1f2937" transform="rotate(20 41 33)"/>' +
      '<circle cx="23.5" cy="32.5" r="2.7" fill="#fff"/>' +
      '<circle cx="40.5" cy="32.5" r="2.7" fill="#fff"/>' +
      '<ellipse cx="32" cy="43" rx="3.4" ry="2.5" fill="#1f2937"/>' +
      '<path d="M32 45.6v2.2M32 47.8q-3.4 3-5.8.5M32 47.8q3.4 3 5.8.5" fill="none" stroke="#1f2937" stroke-width="1.7" stroke-linecap="round"/>',

    owl: '<path d="M13.5 21 L11 7.5 L26 14.5 Z" fill="#a16207"/>' +
      '<path d="M50.5 21 L53 7.5 L38 14.5 Z" fill="#a16207"/>' +
      '<circle cx="32" cy="35" r="19.5" fill="#a16207"/>' +
      '<ellipse cx="32" cy="53" rx="10" ry="5.5" fill="#ca8a04"/>' +
      '<circle cx="24" cy="32.5" r="9" fill="#fffbeb"/>' +
      '<circle cx="40" cy="32.5" r="9" fill="#fffbeb"/>' +
      '<circle cx="24" cy="32.5" r="4.3" fill="#2b1a0e"/>' +
      '<circle cx="40" cy="32.5" r="4.3" fill="#2b1a0e"/>' +
      '<circle cx="25.3" cy="31.2" r="1.3" fill="#fff"/>' +
      '<circle cx="41.3" cy="31.2" r="1.3" fill="#fff"/>' +
      '<path d="M32 36.5l3.8 4.6-3.8 4.6-3.8-4.6Z" fill="#f59e0b"/>',

    lion: lionMane() +
      '<circle cx="32" cy="35" r="17.5" fill="#fbbf24"/>' +
      '<circle cx="25" cy="31.5" r="3.2" fill="#2b1a0e"/>' +
      '<circle cx="39" cy="31.5" r="3.2" fill="#2b1a0e"/>' +
      '<ellipse cx="32" cy="42" rx="9" ry="7" fill="#fef3c7"/>' +
      '<path d="M32 39l3.2 2.8-3.2 2.8-3.2-2.8Z" fill="#7c2d12"/>' +
      '<path d="M32 44.4v2.6M32 47q-3.6 3-6.2.5M32 47q3.6 3 6.2.5" fill="none" stroke="#7c2d12" stroke-width="1.7" stroke-linecap="round"/>',

    frog: '<circle cx="20" cy="21" r="9.5" fill="#22c55e"/>' +
      '<circle cx="44" cy="21" r="9.5" fill="#22c55e"/>' +
      '<circle cx="20" cy="20" r="6.2" fill="#fff"/>' +
      '<circle cx="44" cy="20" r="6.2" fill="#fff"/>' +
      '<circle cx="20" cy="20" r="3" fill="#1f2937"/>' +
      '<circle cx="44" cy="20" r="3" fill="#1f2937"/>' +
      '<ellipse cx="32" cy="41" rx="19.5" ry="15.5" fill="#22c55e"/>' +
      '<path d="M18 38.5q14 15 28 0" fill="none" stroke="#166534" stroke-width="2.4" stroke-linecap="round"/>' +
      '<circle cx="28" cy="35" r="1.3" fill="#166534"/>' +
      '<circle cx="36" cy="35" r="1.3" fill="#166534"/>',

    penguin: '<ellipse cx="23.5" cy="56" rx="6" ry="3.6" fill="#f59e0b" transform="rotate(-18 23.5 56)"/>' +
      '<ellipse cx="40.5" cy="56" rx="6" ry="3.6" fill="#f59e0b" transform="rotate(18 40.5 56)"/>' +
      '<ellipse cx="32" cy="35" rx="18.5" ry="21.5" fill="#1e293b"/>' +
      '<ellipse cx="32" cy="36" rx="13" ry="17" fill="#f8fafc"/>' +
      '<circle cx="26" cy="28" r="2.9" fill="#0f172a"/>' +
      '<circle cx="38" cy="28" r="2.9" fill="#0f172a"/>' +
      '<path d="M32 32.5l5.2 4-5.2 4-5.2-4Z" fill="#f59e0b"/>'
  };

  var AVATAR_ORDER = ['cat', 'dog', 'fox', 'panda', 'owl', 'lion', 'frog', 'penguin'];

  function avatarSVG(key) {
    return '<svg class="avt" viewBox="0 0 64 64" aria-hidden="true">' + (AVATARS[key] || AVATARS.cat) + '</svg>';
  }
  function avatarNames() {
    return pack().avatars || enPack().avatars || {};
  }
  function avatarKeys() {
    var names = avatarNames();
    var keys = AVATAR_ORDER.filter(function (k) { return names[k]; });
    Object.keys(names).forEach(function (k) { if (keys.indexOf(k) === -1) keys.push(k); });
    return keys;
  }
  function avatarName(key) {
    var names = avatarNames();
    var en = enPack().avatars || {};
    return names[key] || en[key] || key;
  }

  /* ================================================================== *
   * 4. Text helpers
   * ================================================================== */

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var AR_RUN = /([\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+(?:[ \u060C\u061B\u061F]+[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+)*)/g;

  /* Escapes, then applies **bold** and wraps Arabic runs so they render right-to-left. */
  function fmt(text) {
    var s = esc(text || '');
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(AR_RUN, function (m) { return '<span class="ar" lang="ar">' + m + '</span>'; });
    return s;
  }

  /* ================================================================== *
   * 5. Progress maths
   * ================================================================== */

  function keyOf(subjectId, lessonId) { return subjectId + '/' + lessonId; }
  function recordOf(subjectId, lessonId) { return progress.lessons[keyOf(subjectId, lessonId)] || null; }
  function starsFor(pct) { return pct >= 0.9 ? 3 : pct >= 0.7 ? 2 : pct >= 0.5 ? 1 : 0; }

  function starsHTML(n, big) {
    var out = '<span class="stars' + (big ? ' big' : '') + '">';
    for (var i = 1; i <= 3; i++) out += STAR.replace('<svg ', '<svg class="' + (i <= n ? 'on' : '') + '" ');
    return out + '</span>';
  }

  function subjectStats(s) {
    var done = 0;
    s.lessons.forEach(function (l) { if (recordOf(s.id, l.id)) done++; });
    return { done: done, total: s.lessons.length, pct: s.lessons.length ? done / s.lessons.length : 0 };
  }

  function overallStats() {
    var total = 0, done = 0, stars = 0, bestSum = 0;
    subjects().forEach(function (s) {
      total += s.lessons.length;
      s.lessons.forEach(function (l) {
        var r = recordOf(s.id, l.id);
        if (r) { done++; stars += r.stars; bestSum += r.total ? r.best / r.total : 0; }
      });
    });
    return { total: total, done: done, stars: stars, maxStars: total * 3, avg: done ? bestSum / done : 0 };
  }

  function nextLessonToStudy() {
    var list = subjects();
    for (var i = 0; i < list.length; i++) {
      var s = list[i];
      for (var j = 0; j < s.lessons.length; j++) {
        if (!recordOf(s.id, s.lessons[j].id)) return { subject: s, lesson: s.lessons[j] };
      }
    }
    return null;
  }

  /* ================================================================== *
   * 6. Routing
   * ================================================================== */

  var app = document.getElementById('app');
  var overlay = document.getElementById('onboarding');
  var quiz = null;
  var firstRun = !profile.name;

  function route() {
    var parts = (window.location.hash || '').replace(/^#\/?/, '').split('/').filter(Boolean);
    quiz = null;
    var s = parts[0] === 'l' || parts[0] === 's' ? subjectById(parts[1]) : null;
    if (parts[0] === 'l' && s && lessonById(s, parts[2])) renderLesson(s, lessonById(s, parts[2]));
    else if (parts[0] === 's' && s) renderSubject(s);
    else renderHome();
    window.scrollTo(0, 0);
    app.focus({ preventScroll: true });
  }

  /* ================================================================== *
   * 7. Home
   * ================================================================== */

  function renderHome() {
    document.title = t('appName') + ' — ' + t('taglineShort');
    app.style.setProperty('--accent', '#4f46e5');

    var list = subjects();
    var ov = overallStats();
    var next = nextLessonToStudy();
    var html = '';

    /* Greeting with the learner's animal */
    html += '<div class="profile-strip">' +
      '<span class="pfp-lg">' + avatarSVG(profile.avatar) + '</span>' +
      '<div class="who"><h2>' + esc(t('welcomeBack', { name: profile.name })) + '</h2>' +
      '<p>' + esc(avatarName(profile.avatar)) + ' &middot; ' + esc(pack().name || '') + '</p></div>' +
      '<button class="btn" id="editProfileTop" type="button">' + esc(t('editProfile')) + '</button></div>';

    html += '<section class="hero">';
    html += '<h1>' + esc(t('heroTitle')) + '</h1>';
    html += '<p>' + esc(t('heroLead')) + '</p>';
    html += '<div class="hero-tags">' + list.map(function (s) { return '<span class="tag">' + esc(s.name) + '</span>'; }).join('') + '</div>';
    html += '</section>';

    html += '<div class="stats">';
    html += '<div class="stat"><b>' + ov.done + ' / ' + ov.total + '</b><span>' + esc(t('lessonsDone')) + '</span></div>';
    html += '<div class="stat"><b>' + ov.stars + ' / ' + ov.maxStars + '</b><span>' + esc(t('starsEarned')) + '</span></div>';
    html += '<div class="stat"><b>' + Math.round(ov.avg * 100) + '%</b><span>' + esc(t('avgScore')) + '</span></div>';
    html += '</div>';

    if (next) {
      html += '<a class="continue" href="#/l/' + next.subject.id + '/' + next.lesson.id + '">' +
        '<div><div class="k">' + esc(t('continueLearning')) + '</div><h3>' + esc(next.lesson.title) + '</h3>' +
        '<p>' + esc(next.subject.name) + ' &middot; ' + esc(t('minRead', { n: next.lesson.minutes })) + ' &middot; ' +
        esc(t('questionsCount', { n: next.lesson.questions.length })) + '</p></div>' +
        '<div class="spacer"></div>' +
        '<span class="btn btn-invert">' + esc(t('startLesson')) + '</span></a>';
    } else {
      html += '<div class="continue"><div><div class="k">' + esc(t('allCaughtUp')) + '</div>' +
        '<h3>' + esc(t('appName')) + '</h3><p>' + esc(t('allCaughtUpBody')) + '</p></div></div>';
    }

    html += '<div class="sec-title"><h2>' + esc(t('chooseSubject')) + '</h2>' +
      '<span>' + esc(t('subjectsCount', { n: list.length })) + ' &middot; ' + esc(t('lessonsCount', { n: ov.total })) + '</span></div>';
    html += '<div class="grid">';
    list.forEach(function (s) {
      var st = subjectStats(s);
      html += '<a class="subject-card" href="#/s/' + s.id + '" style="--accent:' + s.color + '">' +
        '<div class="subject-head"><span class="subject-icon">' + icon(s.icon) + '</span>' +
        '<div><h3>' + esc(s.name) + '</h3><span class="tagline">' + esc(t('lessonsCount', { n: s.lessons.length })) + '</span></div></div>' +
        '<p class="tagline">' + esc(s.tagline) + '</p>' +
        '<div class="bar"><i style="width:' + Math.round(st.pct * 100) + '%"></i></div>' +
        '<div class="subject-meta"><span>' + esc(t('ofComplete', { done: st.done, total: st.total })) + '</span>' +
        '<span class="badge' + (st.done === st.total ? ' done' : '') + '">' + Math.round(st.pct * 100) + '%</span></div>' +
        '</a>';
    });
    html += '</div>';

    app.innerHTML = html;
    document.getElementById('editProfileTop').addEventListener('click', function () { openOverlay(false); });
  }

  /* ================================================================== *
   * 8. Subject
   * ================================================================== */

  function renderSubject(s) {
    document.title = s.name + ' — ' + t('appName');
    app.style.setProperty('--accent', s.color);
    var st = subjectStats(s);

    var html = '<a class="backlink" href="#/">' + ARROW_LEFT + ' ' + esc(t('allSubjects')) + '</a>';
    html += '<div class="page-head">' +
      '<span class="subject-icon">' + icon(s.icon) + '</span>' +
      '<div><h1>' + esc(s.name) + '</h1><p class="sub">' + esc(s.tagline) + '</p></div>' +
      '<div class="meter"><div class="lbl"><span>' + esc(t('progressLabel')) + '</span><span>' + st.done + ' / ' + st.total + '</span></div>' +
      '<div class="bar"><i style="width:' + Math.round(st.pct * 100) + '%"></i></div></div>' +
      '</div>';

    html += '<div class="lessons">';
    s.lessons.forEach(function (l, i) {
      var r = recordOf(s.id, l.id);
      html += '<a class="lesson-row" href="#/l/' + s.id + '/' + l.id + '" style="--accent:' + s.color + '">' +
        '<span class="lesson-num">' + (i + 1) + '</span>' +
        '<span class="txt"><h3>' + esc(l.title) + '</h3>' +
        '<span class="sub">' + esc(t('minRead', { n: l.minutes })) + ' &middot; ' + esc(t('questionsCount', { n: l.questions.length })) + '</span></span>' +
        '<span class="right">' + (r ? starsHTML(r.stars) : '') +
        '<span class="badge ' + (r ? 'done' : 'todo') + '">' + (r ? r.best + '/' + r.total : esc(t('notStarted'))) + '</span></span>' +
        '</a>';
    });
    html += '</div>';

    app.innerHTML = html;
  }

  /* ================================================================== *
   * 9. Lesson — explanation first, then practice
   * ================================================================== */

  function renderLesson(s, l) {
    document.title = l.title + ' — ' + s.name + ' — ' + t('appName');
    app.style.setProperty('--accent', s.color);

    var html = '<a class="backlink" href="#/s/' + s.id + '">' + ARROW_LEFT + ' ' + esc(s.name) + '</a>';
    html += '<div class="page-head" style="margin-bottom:14px">' +
      '<div><h1>' + esc(l.title) + '</h1>' +
      '<p class="sub">' + esc(t('minRead', { n: l.minutes })) + ' &middot; ' + esc(t('questionsCount', { n: l.questions.length })) + '</p></div></div>';
    html += '<div id="steps" class="steps"></div>';
    html += '<div id="stage"></div>';

    app.innerHTML = html;

    quiz = { subject: s, lesson: l, i: 0, score: 0, streak: 0, bestStreak: 0, locked: false, answers: [] };
    showExplain();
  }

  function stepsHTML(active) {
    var one = active === 'explain' ? 'active' : 'done';
    var two = active === 'quiz' ? 'active' : (active === 'results' ? 'done' : '');
    return '<span class="step ' + one + '"><i>1</i>' + esc(t('stepExplain')) + '</span>' +
      '<span class="step-line"></span>' +
      '<span class="step ' + two + '"><i>2</i>' + esc(t('stepPractice')) + '</span>';
  }

  function stage() { return document.getElementById('stage'); }
  function stepsEl() { return document.getElementById('steps'); }

  /* ---- stage 1: the explanation, always shown before any question ---- */
  function showExplain() {
    stepsEl().innerHTML = stepsHTML('explain');
    var e = quiz.lesson.explain;
    var html = '<div class="panel">';

    html += '<p class="lead" dir="auto">' + fmt(e.intro) + '</p>';

    e.sections.forEach(function (sec) {
      html += '<div class="block"><h3>' + esc(sec.h) + '</h3>';
      if (sec.p) html += '<p dir="auto">' + fmt(sec.p) + '</p>';
      if (sec.list && sec.list.length) {
        html += '<ul dir="auto">' + sec.list.map(function (x) { return '<li>' + fmt(x) + '</li>'; }).join('') + '</ul>';
      }
      html += '</div>';
    });

    if (e.keyPoints && e.keyPoints.length) {
      html += '<div class="keypoints"><h3>' + esc(t('rememberThese')) + '</h3><ul dir="auto">' +
        e.keyPoints.map(function (x) { return '<li>' + fmt(x) + '</li>'; }).join('') + '</ul></div>';
    }

    if (e.example) {
      html += '<div class="example"><div class="hd">' + esc(e.example.title) + '</div>' +
        '<ol dir="auto">' + e.example.steps.map(function (x) { return '<li>' + fmt(x) + '</li>'; }).join('') + '</ol></div>';
    }

    html += '<div class="btn-row"><button class="btn btn-primary btn-lg" id="startQuiz" type="button">' +
      esc(t('readyButton')) + '</button><span class="hint">' + esc(t('readyHint')) + '</span></div>';
    html += '</div>';

    stage().innerHTML = html;
    document.getElementById('startQuiz').addEventListener('click', showQuestion);
  }

  /* ---- stage 2: practice questions ---- */
  function showQuestion() {
    stepsEl().innerHTML = stepsHTML('quiz');
    var q = quiz.lesson.questions[quiz.i];
    var total = quiz.lesson.questions.length;

    var html = '<div class="panel">';
    html += '<div class="qhead"><div class="info">' +
      '<span>' + esc(t('questionOf', { i: quiz.i + 1, n: total })) + '</span>' +
      '<span class="pill">' + esc(t('scoreLabel', { n: quiz.score })) + '</span>' +
      (quiz.streak >= 2 ? '<span class="pill hot">' + esc(t('streakLabel', { n: quiz.streak })) + '</span>' : '') +
      '</div></div>';
    html += '<div class="bar"><i style="width:' + Math.round((quiz.i / total) * 100) + '%"></i></div>';

    html += '<p class="question" dir="auto">' + fmt(q.q) + '</p>';
    html += '<div class="options" role="group">';
    q.options.forEach(function (opt, idx) {
      html += '<button class="option" type="button" data-i="' + idx + '">' +
        '<span class="opt-key">' + String.fromCharCode(65 + idx) + '</span>' +
        '<span class="opt-text" dir="auto">' + fmt(opt) + '</span></button>';
    });
    html += '</div>';
    html += '<div id="fb" aria-live="polite"></div>';
    html += '<div class="quizfoot"><span class="hint">' + esc(t('quizTip')) + '</span>' +
      '<button class="btn btn-primary" id="nextBtn" type="button" disabled>' +
      esc(quiz.i === total - 1 ? t('seeResults') : t('nextQuestion')) + '</button></div>';
    html += '</div>';

    stage().innerHTML = html;

    var buttons = stage().querySelectorAll('.option');
    for (var i = 0; i < buttons.length; i++) buttons[i].addEventListener('click', onChoose);
    document.getElementById('nextBtn').addEventListener('click', nextQuestion);
  }

  function onChoose(ev) {
    if (!quiz || quiz.locked) return;
    var btn = ev.currentTarget;
    var chosen = parseInt(btn.getAttribute('data-i'), 10);
    var q = quiz.lesson.questions[quiz.i];
    var correct = chosen === q.answer;

    quiz.locked = true;
    quiz.answers.push({ i: quiz.i, chosen: chosen, correct: correct });

    if (correct) {
      quiz.score++;
      quiz.streak++;
      if (quiz.streak > quiz.bestStreak) quiz.bestStreak = quiz.streak;
      window.Sfx.correct();          /* the "ting" */
    } else {
      quiz.streak = 0;
      window.Sfx.wrong();            /* "womp womp womp" */
    }

    var buttons = stage().querySelectorAll('.option');
    for (var i = 0; i < buttons.length; i++) {
      var b = buttons[i];
      var idx = parseInt(b.getAttribute('data-i'), 10);
      b.disabled = true;
      if (idx === q.answer) b.classList.add('correct');
      else if (idx === chosen) b.classList.add('wrong');
      else b.classList.add('dim');
    }

    var verdict = t(correct ? 'correctFeedback' : 'wrongFeedback');
    if (correct && quiz.streak >= 3) verdict += ' &middot; ' + esc(t('inARow', { n: quiz.streak }));

    document.getElementById('fb').innerHTML = '<div class="feedback ' + (correct ? 'good' : 'bad') + '">' +
      '<div class="verdict">' + verdict + '</div>' +
      '<p class="why" dir="auto">' + fmt(q.explain || '') + '</p></div>';

    var next = document.getElementById('nextBtn');
    next.disabled = false;
    next.focus();
  }

  function nextQuestion() {
    if (!quiz || !quiz.locked) return;
    quiz.i++;
    quiz.locked = false;
    if (quiz.i >= quiz.lesson.questions.length) showResults();
    else { showQuestion(); window.scrollTo(0, 0); }
  }

  /* ---- stage 3: results ---- */
  function showResults() {
    stepsEl().innerHTML = stepsHTML('results');
    var l = quiz.lesson;
    var total = l.questions.length;
    var pct = total ? quiz.score / total : 0;
    var stars = starsFor(pct);
    var prev = recordOf(quiz.subject.id, l.id);

    if (!prev || quiz.score > prev.best) {
      progress.lessons[keyOf(quiz.subject.id, l.id)] = { best: quiz.score, total: total, stars: stars };
      saveProgress();
    }

    var msg = pct === 1 ? t('msgPerfect') : pct >= 0.9 ? t('msgExcellent') :
      pct >= 0.7 ? t('msgGood') : pct >= 0.5 ? t('msgOk') : t('msgKeepGoing');

    var html = '<div class="panel"><div class="result-hero">' +
      '<div class="score">' + quiz.score + ' <span class="of">/ ' + total + '</span></div>' +
      '<div class="big-stars">' + starsHTML(stars, true) + '</div>' +
      '<h2>' + esc(msg) + '</h2>' +
      '<p>' + esc(t('pctCorrect', { p: Math.round(pct * 100) })) + ' &middot; ' +
      esc(t('bestStreakLabel', { n: quiz.bestStreak })) +
      (prev ? ' &middot; ' + esc(t('prevBest', { b: prev.best, t: prev.total })) : '') +
      '</p></div>';

    var wrong = quiz.answers.filter(function (a) { return !a.correct; });
    if (wrong.length) {
      html += '<div class="review"><h3>' + esc(wrong.length > 1 ? t('reviewTitle', { n: wrong.length }) : t('reviewTitleOne')) + '</h3>';
      wrong.forEach(function (a) {
        var q = l.questions[a.i];
        html += '<div class="review-item">' +
          '<p class="q" dir="auto">' + (a.i + 1) + '. ' + fmt(q.q) + '</p>' +
          '<p class="a" dir="auto"><b>' + esc(t('correctIs')) + ' ' + fmt(q.options[q.answer]) + '</b>' +
          (q.options[a.chosen] !== undefined ? ' &middot; <span class="yours">' + esc(t('youAnswered')) + ' ' + fmt(q.options[a.chosen]) + '</span>' : '') +
          '<br>' + fmt(q.explain || '') + '</p></div>';
      });
      html += '</div>';
    } else {
      html += '<div class="empty"><p style="font-size:1.05rem;color:var(--ok);font-weight:700">' + esc(t('noMistakes')) + '</p></div>';
    }

    var idxNow = quiz.subject.lessons.indexOf(quiz.lesson);
    var nextL = idxNow >= 0 ? quiz.subject.lessons[idxNow + 1] : null;

    html += '<div class="btn-row">' +
      '<button class="btn btn-primary" id="retry" type="button">' + esc(t('tryAgain')) + '</button>' +
      '<a class="btn" href="#/s/' + quiz.subject.id + '">' + esc(t('backTo', { subject: quiz.subject.name })) + '</a>' +
      (nextL ? '<a class="btn" href="#/l/' + quiz.subject.id + '/' + nextL.id + '">' + esc(t('nextLessonLabel', { title: nextL.title })) + '</a>' : '') +
      '</div></div>';

    stage().innerHTML = html;
    document.getElementById('retry').addEventListener('click', function () { renderLesson(quiz.subject, quiz.lesson); });
    window.scrollTo(0, 0);
  }

  /* ================================================================== *
   * 10. Profile / onboarding overlay
   * ================================================================== */

  function langOptions(selected) {
    return LANGS.filter(function (c) { return PACKS[c]; }).map(function (c) {
      return '<option value="' + c + '"' + (c === selected ? ' selected' : '') + '>' + esc(PACKS[c].name || c) + '</option>';
    }).join('');
  }

  function avatarOptionsHTML() {
    return avatarKeys().map(function (k) {
      return '<button class="avatar-opt' + (k === profile.avatar ? ' on' : '') + '" type="button" data-a="' + k + '">' +
        '<span class="face">' + avatarSVG(k) + '</span>' +
        '<span class="nm">' + esc(avatarName(k)) + '</span></button>';
    }).join('');
  }

  function openOverlay(isFirstRun) {
    firstRun = !!isFirstRun;
    var html = '<div class="ob-card" role="dialog" aria-modal="true" aria-labelledby="obTitle">';
    if (!firstRun) {
      html += '<button class="ob-close" id="obClose" type="button" aria-label="' + esc(t('closeLabel')) + '">&times;</button>';
    }
    html += '<div class="ob-brand">' + BRAND_MARK + '<span>' + esc(t('appName')) + '</span></div>';
    html += '<h2 id="obTitle">' + esc(t(firstRun ? 'welcomeTitle' : 'yourProfile')) + '</h2>';
    html += '<p class="ob-sub">' + esc(t(firstRun ? 'welcomeSub' : 'switchHint')) + '</p>';

    html += '<label class="field"><span class="lb">' + esc(t('pickLanguage')) + '</span>' +
      '<select id="obLang">' + langOptions(profile.lang) + '</select></label>';

    html += '<label class="field"><span class="lb">' + esc(t('yourName')) + '</span>' +
      '<input id="obName" type="text" maxlength="24" autocomplete="off" spellcheck="false" ' +
      'placeholder="' + esc(t('namePlaceholder')) + '" value="' + esc(profile.name) + '"></label>';

    html += '<div class="field"><span class="lb">' + esc(t('pickAnimal')) + '</span>' +
      '<div class="avatar-grid" id="obAvatars">' + avatarOptionsHTML() + '</div>' +
      '<span class="tip">' + esc(t('soundPreview')) + '</span></div>';

    html += '<p class="ob-error" id="obError" hidden></p>';
    html += '<div class="ob-actions"><button class="btn btn-primary btn-lg" id="obStart" type="button">' +
      esc(firstRun ? t('startLearning') : t('saveProfile')) + '</button></div>';
    html += '</div>';

    overlay.innerHTML = html;
    overlay.hidden = false;
    document.body.classList.add('modal-open');

    /* Language choice inside the overlay takes effect straight away. */
    document.getElementById('obLang').addEventListener('change', function (ev) {
      profile.lang = ev.target.value;
      profile.name = document.getElementById('obName').value;
      saveProfile();
      applyLang();
      route();
      openOverlay(false);
    });

    var grid = document.getElementById('obAvatars');
    grid.addEventListener('click', function (ev) {
      var b = ev.target.closest ? ev.target.closest('.avatar-opt') : null;
      if (!b) return;
      profile.avatar = b.getAttribute('data-a');
      saveProfile();
      var all = grid.querySelectorAll('.avatar-opt');
      for (var i = 0; i < all.length; i++) all[i].classList.toggle('on', all[i] === b);
      paintChrome();
      window.Sfx.correct();
    });

    var nameInput = document.getElementById('obName');
    nameInput.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); submitOverlay(); }
    });
    nameInput.addEventListener('input', function () {
      document.getElementById('obError').hidden = true;
    });

    if (!firstRun) {
      document.getElementById('obClose').addEventListener('click', closeOverlay);
    }
    document.getElementById('obStart').addEventListener('click', submitOverlay);

    nameInput.focus();
    if (profile.name) nameInput.select();
  }

  function submitOverlay() {
    var typed = document.getElementById('obName').value.trim();
    if (!typed) {
      document.getElementById('obError').textContent = t('needName');
      document.getElementById('obError').hidden = false;
      document.getElementById('obName').focus();
      return;
    }
    profile.name = typed;
    saveProfile();
    closeOverlay();
    applyLang();
    route();
    window.Sfx.correct();
  }

  function closeOverlay() {
    overlay.hidden = true;
    overlay.innerHTML = '';
    document.body.classList.remove('modal-open');
    firstRun = false;
  }

  /* ================================================================== *
   * 11. Chrome (top bar / footer) & language application
   * ================================================================== */

  var langSelect = document.getElementById('langSelect');
  var profileBtn = document.getElementById('profileBtn');
  var profilePfp = document.getElementById('profilePfp');
  var profileBtnText = document.getElementById('profileBtnText');
  var soundToggle = document.getElementById('soundToggle');
  var soundToggleLabel = document.getElementById('soundToggleLabel');
  var footNote = document.getElementById('footNote');

  function paintChrome() {
    langSelect.innerHTML = langOptions(profile.lang);
    profilePfp.innerHTML = avatarSVG(profile.avatar);
    profileBtnText.textContent = profile.name || t('yourProfile');
    profileBtn.setAttribute('title', t('editProfile'));
    soundToggle.setAttribute('aria-pressed', progress.sound ? 'true' : 'false');
    soundToggle.setAttribute('title', progress.sound ? t('soundOn') : t('soundOff'));
    soundToggleLabel.textContent = t('soundToggle');
    footNote.textContent = t('welcomeSub');
    window.Sfx.setEnabled(progress.sound);
  }

  function applyLang() {
    var p = pack();
    document.documentElement.lang = profile.lang;
    document.documentElement.dir = p.dir || 'ltr';
    paintChrome();
  }

  function changeLang(code) {
    if (!PACKS[code] || code === profile.lang) return;
    profile.lang = code;
    saveProfile();
    applyLang();
    route();
  }

  langSelect.addEventListener('change', function (ev) { changeLang(ev.target.value); });

  profileBtn.addEventListener('click', function () { openOverlay(false); });

  soundToggle.addEventListener('click', function () {
    progress.sound = !progress.sound;
    saveProgress();
    paintChrome();
    if (progress.sound) window.Sfx.correct();
  });

  /* ================================================================== *
   * 12. Keyboard shortcuts
   * ================================================================== */

  document.addEventListener('keydown', function (ev) {
    if (!overlay.hidden) return;
    if (!quiz) return;
    var tag = (ev.target && ev.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

    if (ev.key >= '1' && ev.key <= '4') {
      if (quiz.locked) return;
      var btn = stage().querySelector('.option[data-i="' + (parseInt(ev.key, 10) - 1) + '"]');
      if (btn) { ev.preventDefault(); btn.click(); }
      return;
    }
    if (ev.key === 'Enter') {
      if (quiz.locked) { ev.preventDefault(); nextQuestion(); }
      else if (stage().querySelector('#startQuiz')) { ev.preventDefault(); showQuestion(); }
    }
  });

  /* ================================================================== *
   * 13. Boot
   * ================================================================== */

  document.addEventListener('pointerdown', function () { window.Sfx.unlock(); }, { once: true });
  window.addEventListener('hashchange', route);

  applyLang();
  route();
  if (!profile.name) openOverlay(true);
})();
